const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  showNotification: (title, body) => ipcRenderer.send('show-notification', { title, body }),
  onBarcodeReceived: (callback) => ipcRenderer.on('barcode-received', (event, code) => callback(code)),
  platform: process.platform,
  isElectron: true,
});
