const { app, BrowserWindow, Menu, shell, ipcMain, Notification, globalShortcut } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 600,
    show: false,
    icon: path.join(__dirname, 'build/icon.png'),
    title: 'REFORM FITNESS - Enterprise Management System',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    // Additional window options for better desktop experience
    center: true,
    frame: true,
    backgroundColor: '#050A14',
  });

  // Load the built app
  const isDev = process.env.ELECTRON_IS_DEV !== undefined
    ? parseInt(process.env.ELECTRON_IS_DEV) === 1
    : !app.isPackaged;

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, 'dist/index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Open external links in default browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  // Remove menu bar for cleaner look (optional)
  Menu.setApplicationMenu(null);

  // Handle navigation within SPA
  mainWindow.webContents.on('did-navigate-in-page', () => {
    // Prevent external navigation
  });

  // Prevent new window creation from within the app
  mainWindow.webContents.on('new-window', (event, url) => {
    event.preventDefault();
    shell.openExternal(url);
  });
}

app.whenReady().then(() => {
  createWindow();

  // Register global shortcuts (optional)
  // globalShortcut.register('CommandOrControl+Shift+I', () => {
  //   if (mainWindow) mainWindow.webContents.toggleDevTools();
  // });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
    else if (mainWindow) mainWindow.focus();
  });
});

app.on('window-all-closed', () => {
  // Unregister all shortcuts
  globalShortcut.unregisterAll();

  if (process.platform !== 'darwin') app.quit();
});

// Desktop notifications
ipcMain.on('show-notification', (event, { title, body }) => {
  if (Notification.isSupported()) {
    new Notification({
      title: title || 'REFORM FITNESS',
      body: body || '',
      silent: false,
      icon: path.join(__dirname, 'build/icon.png')
    }).show();
  }
});

// Barcode scanner support via IPC
ipcMain.on('barcode-scanned', (event, code) => {
  if (mainWindow) {
    mainWindow.webContents.send('barcode-received', code);
  }
});

// Handle deep links (optional for future use)
app.setAsDefaultProtocolClient('reform-fitness');

// Handle protocol handler
app.on('open-url', (event, url) => {
  event.preventDefault();
  if (mainWindow) {
    mainWindow.focus();
    mainWindow.webContents.send('deep-link', url);
  }
});

// Quit when all windows are closed, except on macOS
app.on('before-quit', () => {
  // Cleanup before quitting
});
