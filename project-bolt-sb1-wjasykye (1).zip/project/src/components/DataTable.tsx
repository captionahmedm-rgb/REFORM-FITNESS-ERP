import { ReactNode, useState, useMemo } from 'react';
import { Search, Plus, Download, Printer, Eye, Pencil, Trash2, Inbox } from 'lucide-react';
import { Button, EmptyState, TableSkeleton, Pagination } from './ui';

export interface Column<T> {
  key: string;
  label: string;
  render?: (row: T) => ReactNode;
  width?: string;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  loading?: boolean;
  onAdd?: () => void;
  onEdit?: (row: T) => void;
  onDelete?: (row: T) => void;
  onView?: (row: T) => void;
  searchKeys?: (keyof T)[];
  pageSize?: number;
  filters?: { label: string; value: string; options?: { value: string; label: string }[]; type?: string; onChange: (v: string) => void }[];
  emptyTitle?: string;
  emptyDescription?: string;
}

export function DataTable<T extends { id?: string }>({
  data, columns, loading = false, onAdd, onEdit, onDelete, onView,
  searchKeys = [], pageSize = 10, filters = [],
  emptyTitle = 'No records yet',
  emptyDescription = 'Add your first record to get started.',
}: DataTableProps<T>) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    if (!search) return data;
    const q = search.toLowerCase();
    return data.filter(row => searchKeys.some(k => String((row as any)[k] ?? '').toLowerCase().includes(q)));
  }, [data, search, searchKeys]);

  const total = Math.ceil(filtered.length / pageSize);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const exportCSV = () => {
    const header = columns.map(c => c.label).join(',');
    const rows = filtered.map(row =>
      columns.map(c => `"${String((row as any)[c.key] ?? '').replace(/"/g,'""')}"`).join(',')
    );
    const blob = new Blob([[header, ...rows].join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `export_${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const print = () => {
    const w = window.open('', '_blank');
    if (!w) return;
    w.document.write(`<html><head><title>Print</title><style>
      body{font-family:sans-serif;padding:20px;} table{width:100%;border-collapse:collapse;}
      th,td{padding:8px 12px;text-align:left;border:1px solid #ddd;font-size:12px;}
      th{background:#f0f0f0;font-weight:700;}
    </style></head><body>
    <h2>REFORM FITNESS — Export</h2>
    <table><thead><tr>${columns.map(c => `<th>${c.label}</th>`).join('')}</tr></thead>
    <tbody>${filtered.map(row => `<tr>${columns.map(c => `<td>${String((row as any)[c.key] ?? '')}</td>`).join('')}</tr>`).join('')}
    </tbody></table></body></html>`);
    w.document.close(); w.print();
  };

  return (
    <div>
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        {searchKeys.length > 0 && (
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search size={15} className="absolute start-3 top-1/2 -translate-y-1/2"
              style={{ color: 'var(--color-text-muted)' }} />
            <input className="search-input ps-9 pe-3 py-2 h-9"
              placeholder="Search..." value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }} />
          </div>
        )}
        {filters.map(f => (
          f.type === 'date' ? (
            <input key={f.label} type="date" className="input h-9 w-auto text-sm"
              value={f.value} onChange={e => { f.onChange(e.target.value); setPage(1); }} />
          ) : (
            <select key={f.label} className="input h-9 w-auto text-sm"
              value={f.value} onChange={e => { f.onChange(e.target.value); setPage(1); }}>
              <option value="">{f.label}: All</option>
              {f.options?.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          )
        ))}
        <div className="flex gap-2 ms-auto">
          <Button variant="secondary" size="sm" icon={Download} onClick={exportCSV}>CSV</Button>
          <Button variant="secondary" size="sm" icon={Printer} onClick={print}>Print</Button>
          {onAdd && <Button size="sm" icon={Plus} onClick={onAdd}>Add New</Button>}
        </div>
      </div>

      {/* Table */}
      <div className="rf-card p-0 overflow-hidden">
        {loading ? (
          <TableSkeleton rows={5} cols={columns.length + 1} />
        ) : paged.length === 0 ? (
          <EmptyState icon={Inbox} title={emptyTitle} description={emptyDescription}
            action={onAdd ? <Button icon={Plus} size="sm" onClick={onAdd}>Add New</Button> : undefined} />
        ) : (
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  {columns.map(c => <th key={c.key} style={c.width ? { width: c.width } : undefined}>{c.label}</th>)}
                  {(onView || onEdit || onDelete) && <th style={{ width: 110 }}>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {paged.map((row, i) => (
                  <tr key={(row as any).id ?? i}>
                    {columns.map(c => (
                      <td key={c.key}>{c.render ? c.render(row) : String((row as any)[c.key] ?? '—')}</td>
                    ))}
                    {(onView || onEdit || onDelete) && (
                      <td>
                        <div className="flex gap-1">
                          {onView   && <button onClick={() => onView(row)}   className="w-7 h-7 rounded-lg flex items-center justify-center transition hover:bg-white/5" style={{ color: 'var(--color-text-secondary)' }} title="View"  ><Eye    size={14}/></button>}
                          {onEdit   && <button onClick={() => onEdit(row)}   className="w-7 h-7 rounded-lg flex items-center justify-center transition hover:bg-white/5" style={{ color: 'var(--neon)' }}             title="Edit"  ><Pencil size={14}/></button>}
                          {onDelete && <button onClick={() => onDelete(row)} className="w-7 h-7 rounded-lg flex items-center justify-center transition hover:bg-white/5" style={{ color: 'var(--color-danger)' }}       title="Delete"><Trash2 size={14}/></button>}
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {!loading && paged.length > 0 && <Pagination page={page} totalPages={total} onPageChange={setPage} />}
    </div>
  );
}
