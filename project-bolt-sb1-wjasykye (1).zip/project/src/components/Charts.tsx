import { useMemo } from 'react';

const NEON = '#00D4FF';

export function BarChart({ data, height = 200, color = NEON }: { data: { label: string; value: number }[]; height?: number; color?: string }) {
  const max = Math.max(...data.map(d => d.value), 1);
  return (
    <div className="flex items-end justify-between gap-1.5" style={{ height }}>
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-2 group" style={{ height: '100%' }}>
          <div className="flex items-end justify-center flex-1 w-full relative">
            <div className="w-full max-w-[36px] rounded-t-lg transition-all duration-700 relative"
              style={{
                height: `${(d.value / max) * 100}%`,
                background: `linear-gradient(180deg, ${color} 0%, ${color}60 100%)`,
                boxShadow: `0 0 12px ${color}40`,
                minHeight: 4,
              }}>
              <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-bold opacity-0 group-hover:opacity-100 transition whitespace-nowrap"
                style={{ color: 'var(--color-text)' }}>
                {d.value.toLocaleString()}
              </span>
            </div>
          </div>
          <span className="text-xs truncate w-full text-center"
            style={{ color: 'var(--color-text-muted)', maxWidth: '100%' }}>{d.label}</span>
        </div>
      ))}
    </div>
  );
}

export function LineChart({ data, height = 200, color = NEON }: { data: { label: string; value: number }[]; height?: number; color?: string }) {
  const max = Math.max(...data.map(d => d.value), 1);
  const min = Math.min(...data.map(d => d.value), 0);
  const range = max - min || 1;

  const points = useMemo(() => data.map((d, i) => ({
    x: (i / Math.max(data.length - 1, 1)) * 100,
    y: 100 - ((d.value - min) / range) * 100,
    ...d,
  })), [data, min, range]);

  const pathD  = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaD  = `${pathD} L 100 100 L 0 100 Z`;

  return (
    <div style={{ height }}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full" style={{ height: height - 24 }}>
        <defs>
          <linearGradient id={`lg_${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor={color} stopOpacity="0.3" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={areaD} fill={`url(#lg_${color.replace('#','')})`} />
        <path d={pathD} fill="none" stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke" />
        {points.map((p, i) => (
          <circle key={i} cx={p.x} cy={p.y} r="2.5" fill={color}
            style={{ filter: `drop-shadow(0 0 4px ${color})` }} vectorEffect="non-scaling-stroke" />
        ))}
      </svg>
      <div className="flex justify-between mt-1">
        {data.map((d, i) => (
          <span key={i} className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{d.label}</span>
        ))}
      </div>
    </div>
  );
}

export function DonutChart({ data, size = 148 }: { data: { label: string; value: number; color: string }[]; size?: number }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const r = 40; const circ = 2 * Math.PI * r; let off = 0;
  return (
    <div className="flex items-center gap-5 flex-wrap">
      <svg width={size} height={size} viewBox="0 0 100 100" className="-rotate-90" style={{ filter: 'drop-shadow(0 0 16px rgba(0,212,255,0.2))' }}>
        {data.map((d, i) => {
          const dash = (d.value / total) * circ;
          const el = (
            <circle key={i} cx="50" cy="50" r={r} fill="none"
              stroke={d.color} strokeWidth="14" strokeLinecap="butt"
              strokeDasharray={`${dash} ${circ - dash}`}
              strokeDashoffset={-off} />
          );
          off += dash; return el;
        })}
        <circle cx="50" cy="50" r="28" fill="var(--color-card-2)" />
        <text x="50" y="50" transform="rotate(90 50 50)" textAnchor="middle" dominantBaseline="middle"
          fill="var(--color-text)" fontSize="10" fontWeight="800" fontFamily="Inter,sans-serif">
          {total.toLocaleString()}
        </text>
      </svg>
      <div className="space-y-2 flex-1 min-w-[120px]">
        {data.map((d, i) => (
          <div key={i} className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: d.color }} />
            <span className="text-xs flex-1" style={{ color: 'var(--color-text-secondary)' }}>{d.label}</span>
            <span className="text-xs font-bold" style={{ color: 'var(--color-text)' }}>{d.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
