import { useState, useEffect, ReactNode } from 'react';
import {
  LayoutDashboard, Users, UserCheck, DollarSign, ShoppingBag, Package,
  BarChart3, Settings, LogOut, Bell, Search, Menu, X, ChevronDown,
  Boxes, ClipboardList, ShoppingCart, Moon, Sun, Globe, User, Dumbbell,
  Building2, Phone, CalendarOff, Share2, Download,
} from 'lucide-react';
import { useAuth }  from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { supabase } from '../lib/supabase';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { FloatingWhatsApp } from './FloatingWhatsApp';

interface NavItem {
  id: string; icon: any; en: string; ar: string; group: string; badge?: string;
}

const NAV: NavItem[] = [
  { id:'dashboard',  icon:LayoutDashboard,  en:'Dashboard',       ar:'لوحة التحكم',   group:'main' },
  { id:'employees',  icon:Users,            en:'Employees',       ar:'الموظفون',      group:'hr' },
  { id:'attendance', icon:UserCheck,        en:'Attendance',      ar:'الحضور',        group:'hr' },
  { id:'leave',      icon:CalendarOff,      en:'Leave',           ar:'الإجازات',      group:'hr' },
  { id:'payroll',    icon:DollarSign,       en:'Payroll',         ar:'الرواتب',       group:'hr' },
  { id:'customers',  icon:ShoppingBag,      en:'Customers',       ar:'العملاء',       group:'sales' },
  { id:'sales',      icon:ShoppingCart,     en:'Sales / POS',     ar:'نقطة البيع',   group:'sales' },
  { id:'orders',     icon:ClipboardList,    en:'Orders',          ar:'الطلبات',       group:'sales' },
  { id:'products',   icon:Package,          en:'Products',        ar:'المنتجات',      group:'inventory' },
  { id:'inventory',  icon:Boxes,            en:'Inventory',       ar:'المخزون',       group:'inventory' },
  { id:'reports',    icon:BarChart3,        en:'Reports',         ar:'التقارير',      group:'analytics' },
  { id:'social',     icon:Share2,           en:'Social Media',    ar:'التواصل الاجتماعي',group:'marketing' },
  { id:'about',      icon:Building2,        en:'About Company',   ar:'عن الشركة',     group:'info' },
  { id:'contact',    icon:Phone,            en:'Contact Us',      ar:'تواصل معنا',    group:'info' },
];

const GROUPS: Record<string,{en:string;ar:string}> = {
  main:      {en:'Overview',     ar:'الرئيسية'},
  hr:        {en:'HR & Staff',   ar:'الموارد البشرية'},
  sales:     {en:'Sales & CRM',  ar:'المبيعات'},
  inventory: {en:'Inventory',    ar:'المخزون'},
  analytics: {en:'Analytics',    ar:'التحليلات'},
  marketing: {en:'Marketing',    ar:'التسويق'},
  info:      {en:'Company',      ar:'الشركة'},
};

interface LayoutProps {
  currentPage: string;
  onNavigate: (p: string) => void;
  children: ReactNode;
}

export function Layout({ currentPage, onNavigate, children }: LayoutProps) {
  const { profile, roles, signOut } = useAuth();
  const { mode, toggleMode, language, setLanguage, companyName } = useTheme();
  const { canInstall, install }   = usePWAInstall();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifOpen,   setNotifOpen]   = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unread, setUnread] = useState(0);
  const [pendingLeave, setPendingLeave] = useState(0);

  const isAr = language === 'ar';

  const loadNotifications = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(10);
    if (data) { setNotifications(data); setUnread(data.filter((n:any)=>!n.is_read).length); }
    // Pending leave count for badge
    const { count } = await supabase.from('leave_requests').select('*',{count:'exact',head:true}).eq('status','pending');
    setPendingLeave(count||0);
  };

  useEffect(() => { loadNotifications(); }, [profile]);

  const markAllRead = async () => {
    if (!profile || !unread) return;
    await supabase.from('notifications').update({is_read:true}).eq('user_id',profile.id).eq('is_read',false);
    setUnread(0);
    setNotifications(n => n.map(x => ({...x, is_read:true})));
  };

  const navigate = (id: string) => { onNavigate(id); setSidebarOpen(false); };

  const grouped = NAV.reduce((acc, item) => {
    if (!acc[item.group]) acc[item.group] = [];
    acc[item.group].push(item);
    return acc;
  }, {} as Record<string, NavItem[]>);

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 flex-shrink-0">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 animate-pulse-neon"
          style={{ background:'linear-gradient(135deg,#0099BB,#00D4FF)' }}>
          <Dumbbell size={20} style={{ color:'#050A14' }} />
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="logo-text text-sm leading-tight">REFORM FITNESS</h1>
          <p className="logo-sub">ENTERPRISE</p>
        </div>
        <button className="ms-auto lg:hidden flex-shrink-0" onClick={() => setSidebarOpen(false)}>
          <X size={18} style={{ color:'var(--color-text-muted)' }} />
        </button>
      </div>

      {/* Current user mini-card */}
      {profile && (
        <div className="mx-3 mb-2 p-3 rounded-xl" style={{background:'rgba(0,212,255,0.06)',border:'1px solid rgba(0,212,255,0.12)'}}>
          <div className="flex items-center gap-2">
            <div className="avatar w-8 h-8 avatar-neon flex-shrink-0">
              {(profile as any).avatar_url
                ? <img src={(profile as any).avatar_url} alt={profile.full_name} onError={e=>{(e.target as any).style.display='none';}}/>
                : <span className="text-xs font-bold" style={{color:'var(--neon)'}}>{profile.full_name?.charAt(0)?.toUpperCase()}</span>
              }
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold truncate" style={{color:'var(--color-text)'}}>{profile.full_name}</p>
              <p className="text-xs truncate" style={{color:'var(--neon)'}}>{roles[0]?.display_name || 'Admin'}</p>
            </div>
          </div>
          {(profile as any).employee_code && (
            <p className="text-xs mt-1 font-mono" style={{color:'var(--color-text-muted)'}}>#{(profile as any).employee_code}</p>
          )}
        </div>
      )}

      <div className="neon-divider mx-4 mb-3" />

      {/* Nav groups */}
      <nav className="flex-1 overflow-y-auto px-3 py-1 space-y-3">
        {Object.entries(grouped).map(([group, items]) => (
          <div key={group}>
            <p className="px-3 mb-1 text-xs font-bold uppercase tracking-widest"
              style={{ color:'var(--color-text-muted)' }}>
              {isAr ? GROUPS[group]?.ar : GROUPS[group]?.en}
            </p>
            {items.map(item => {
              const Icon  = item.icon;
              const active = currentPage === item.id;
              const hasBadge = item.id === 'leave' && pendingLeave > 0;
              return (
                <button key={item.id} onClick={() => navigate(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium mb-0.5 nav-item ${active ? 'nav-active' : ''}`}
                  style={{ color: active ? 'var(--neon)' : 'var(--color-text-secondary)' }}>
                  <Icon size={17} className="flex-shrink-0" />
                  <span className="flex-1 truncate text-start">{isAr ? item.ar : item.en}</span>
                  {hasBadge && (
                    <span className="w-5 h-5 rounded-full text-xs font-bold flex items-center justify-center flex-shrink-0"
                      style={{background:'var(--color-danger)',color:'white'}}>{pendingLeave}</span>
                  )}
                  {active && !hasBadge && (
                    <span className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{background:'var(--neon)',boxShadow:'0 0 6px var(--neon)'}}/>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      <div className="neon-divider mx-4 my-2" />

      {/* PWA install button */}
      {canInstall && (
        <div className="px-3 pb-2">
          <button onClick={install}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition"
            style={{background:'rgba(0,212,255,0.08)',color:'var(--neon)',border:'1px solid rgba(0,212,255,0.2)'}}>
            <Download size={17}/>
            <span>{isAr?'تثبيت التطبيق':'Install App'}</span>
          </button>
        </div>
      )}

      {/* Settings + Logout */}
      <div className="px-3 pb-4 space-y-1 flex-shrink-0">
        <button onClick={() => navigate('settings')}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium nav-item ${currentPage==='settings'?'nav-active':''}`}
          style={{ color: currentPage==='settings' ? 'var(--neon)' : 'var(--color-text-secondary)' }}>
          <Settings size={17}/><span>{isAr?'الإعدادات':'Settings'}</span>
        </button>
        <button onClick={signOut}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium nav-item"
          style={{ color:'var(--color-danger)' }}>
          <LogOut size={17}/><span>{isAr?'تسجيل الخروج':'Logout'}</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden" style={{ background:'var(--color-bg)' }}>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-64 flex-shrink-0 h-full"
        style={{ background:'var(--color-sidebar)', borderInlineEnd:'1px solid var(--color-border)' }}>
        <SidebarContent />
      </aside>

      {/* Mobile drawer */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute inset-y-0 start-0 w-72 flex flex-col animate-slide-in"
            style={{ background:'var(--color-sidebar)', borderInlineEnd:'1px solid var(--color-border)' }}>
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="h-16 flex-shrink-0 flex items-center gap-3 px-4 lg:px-6"
          style={{ background:'var(--color-topbar)', borderBottom:'1px solid var(--color-border)' }}>

          <button className="lg:hidden p-2 rounded-lg" onClick={() => setSidebarOpen(true)}
            style={{ color:'var(--color-text-secondary)' }}>
            <Menu size={22} />
          </button>

          {/* Search */}
          <div className="relative flex-1 max-w-xs hidden sm:block">
            <Search size={15} className="absolute start-3 top-1/2 -translate-y-1/2"
              style={{ color:'var(--color-text-muted)' }} />
            <input className="search-input ps-9 pe-3 py-2 h-9"
              placeholder={isAr?'بحث في النظام...':'Search system...'} />
          </div>

          <div className="flex items-center gap-1 ms-auto">
            {/* PWA install (topbar fallback) */}
            {canInstall && (
              <button onClick={install}
                className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition"
                style={{background:'rgba(0,212,255,0.1)',color:'var(--neon)',border:'1px solid rgba(0,212,255,0.2)'}}>
                <Download size={14}/>{isAr?'تثبيت':'Install'}
              </button>
            )}

            {/* Language */}
            <button onClick={() => setLanguage(isAr?'en':'ar')}
              className="w-9 h-9 rounded-lg flex items-center justify-center transition hover:bg-white/5"
              style={{ color:'var(--color-text-secondary)' }} title="Toggle Language">
              <Globe size={18} />
            </button>

            {/* Dark/Light */}
            <button onClick={toggleMode}
              className="w-9 h-9 rounded-lg flex items-center justify-center transition hover:bg-white/5"
              style={{ color:'var(--color-text-secondary)' }}>
              {mode === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {/* Notifications */}
            <div className="relative">
              <button onClick={() => { setNotifOpen(!notifOpen); setProfileOpen(false); }}
                className="w-9 h-9 rounded-lg flex items-center justify-center transition hover:bg-white/5 relative"
                style={{ color:'var(--color-text-secondary)' }}>
                <Bell size={18} />
                {unread > 0 && (
                  <span className="absolute -top-0.5 -end-0.5 w-4 h-4 rounded-full text-xs font-bold flex items-center justify-center"
                    style={{background:'var(--color-danger)',color:'white',fontSize:'9px'}}>{unread}</span>
                )}
              </button>
              {notifOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
                  <div className="absolute end-0 top-12 w-80 z-50 rounded-2xl animate-scale-in shadow-card"
                    style={{ background:'var(--color-card)', border:'1px solid var(--color-border)' }}>
                    <div className="flex items-center justify-between px-4 py-3"
                      style={{ borderBottom:'1px solid var(--color-border)' }}>
                      <h3 className="font-bold text-sm" style={{ color:'var(--color-text)' }}>
                        {isAr?'الإشعارات':'Notifications'}
                        {unread > 0 && <span className="ms-2 px-1.5 py-0.5 rounded-full text-xs" style={{background:'var(--color-danger)',color:'white'}}>{unread}</span>}
                      </h3>
                      {unread > 0 && (
                        <button className="text-xs" style={{ color:'var(--neon)' }} onClick={markAllRead}>
                          {isAr?'قراءة الكل':'Mark all read'}
                        </button>
                      )}
                    </div>
                    <div className="max-h-72 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <div className="py-8 text-center">
                          <Bell size={24} className="mx-auto mb-2" style={{color:'var(--color-text-muted)'}}/>
                          <p className="text-sm" style={{ color:'var(--color-text-muted)' }}>
                            {isAr?'لا إشعارات جديدة':'No new notifications'}
                          </p>
                        </div>
                      ) : notifications.map(n => (
                        <div key={n.id} className="px-4 py-3 flex gap-3 items-start cursor-pointer hover:bg-white/3"
                          style={{ borderBottom:'1px solid var(--color-border)', background: n.is_read ? 'transparent' : 'rgba(0,212,255,0.04)' }}>
                          <div className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                            style={{ background: n.is_read ? 'transparent' : 'var(--neon)' }} />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold truncate" style={{ color:'var(--color-text)' }}>{n.title}</p>
                            {n.message && <p className="text-xs mt-0.5 line-clamp-2" style={{ color:'var(--color-text-secondary)' }}>{n.message}</p>}
                            <p className="text-xs mt-1" style={{ color:'var(--color-text-muted)' }}>
                              {new Date(n.created_at).toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                    {/* Leave requests alert */}
                    {pendingLeave > 0 && (
                      <div className="px-4 py-3" style={{ borderTop:'1px solid var(--color-border)', background:'rgba(245,158,11,0.05)' }}>
                        <button onClick={() => { navigate('leave'); setNotifOpen(false); }}
                          className="w-full text-start text-xs font-semibold flex items-center gap-2"
                          style={{color:'#F59E0B'}}>
                          <CalendarOff size={14}/>
                          {pendingLeave} {isAr?'طلب إجازة قيد الانتظار':'pending leave request(s)'}
                        </button>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Profile */}
            <div className="relative ms-1">
              <button onClick={() => { setProfileOpen(!profileOpen); setNotifOpen(false); }}
                className="flex items-center gap-2 px-2 py-1 rounded-xl transition hover:bg-white/5">
                <div className="avatar w-8 h-8 avatar-neon flex-shrink-0">
                  {(profile as any)?.avatar_url
                    ? <img src={(profile as any).avatar_url} alt="avatar" onError={e=>{(e.target as any).style.display='none';}}/>
                    : <span className="text-xs font-bold" style={{ color:'var(--neon)' }}>
                        {profile?.full_name?.charAt(0)?.toUpperCase() ?? 'A'}
                      </span>
                  }
                </div>
                <div className="hidden sm:block text-start">
                  <p className="text-xs font-semibold leading-tight" style={{ color:'var(--color-text)' }}>
                    {profile?.full_name ?? 'Admin'}
                  </p>
                  <p className="text-xs leading-tight" style={{ color:'var(--neon)' }}>
                    {roles[0]?.display_name ?? 'Super Admin'}
                  </p>
                </div>
                <ChevronDown size={14} style={{ color:'var(--color-text-muted)' }} />
              </button>
              {profileOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setProfileOpen(false)} />
                  <div className="absolute end-0 top-12 w-64 z-50 rounded-2xl animate-scale-in shadow-card"
                    style={{ background:'var(--color-card)', border:'1px solid var(--color-border)' }}>
                    {/* Profile header */}
                    <div className="px-4 py-4" style={{ borderBottom:'1px solid var(--color-border)' }}>
                      <div className="flex items-center gap-3">
                        <div className="avatar w-12 h-12 avatar-neon flex-shrink-0">
                          {(profile as any)?.avatar_url
                            ? <img src={(profile as any).avatar_url} alt="avatar" onError={e=>{(e.target as any).style.display='none';}}/>
                            : <span className="text-xl font-bold" style={{ color:'var(--neon)' }}>
                                {profile?.full_name?.charAt(0)?.toUpperCase() ?? 'A'}
                              </span>
                          }
                        </div>
                        <div className="min-w-0">
                          <p className="font-bold text-sm truncate" style={{ color:'var(--color-text)' }}>{profile?.full_name ?? 'Admin'}</p>
                          <p className="text-xs truncate" style={{ color:'var(--color-text-secondary)' }}>{profile?.email}</p>
                          <p className="text-xs mt-0.5" style={{ color:'var(--neon)' }}>● {isAr?'متصل':'Online'}</p>
                        </div>
                      </div>
                      {(profile as any)?.employee_code && (
                        <p className="text-xs mt-2 font-mono" style={{ color:'var(--color-text-muted)' }}>
                          {isAr?'كود:':'Code:'} #{(profile as any).employee_code}
                        </p>
                      )}
                    </div>
                    <div className="py-1">
                      {[
                        { icon:User,     en:'My Profile',       ar:'ملفي الشخصي', page:'profile' },
                        { icon:Settings, en:'Settings',         ar:'الإعدادات',   page:'settings' },
                        { icon:CalendarOff, en:'Leave Request', ar:'طلب إجازة',   page:'leave' },
                      ].map(item => {
                        const Icon = item.icon;
                        return (
                          <button key={item.page} onClick={() => { navigate(item.page); setProfileOpen(false); }}
                            className="w-full flex items-center gap-3 px-4 py-2.5 text-sm transition hover:bg-white/5"
                            style={{ color:'var(--color-text-secondary)' }}>
                            <Icon size={16}/>{isAr ? item.ar : item.en}
                          </button>
                        );
                      })}
                      <div className="my-1 neon-divider mx-3" />
                      <button onClick={signOut}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-sm transition hover:bg-white/5"
                        style={{ color:'var(--color-danger)' }}>
                        <LogOut size={16}/>{isAr?'تسجيل الخروج':'Logout'}
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <div className="max-w-screen-xl mx-auto animate-fade-in">
            {children}
          </div>
        </main>

        {/* Footer */}
        <footer className="flex-shrink-0 flex items-center justify-between px-6 py-2 text-xs"
          style={{ background:'var(--color-topbar)', borderTop:'1px solid var(--color-border)', color:'var(--color-text-muted)' }}>
          <span>© 2024 {companyName} — {isAr?'القاهرة، مصر':'Cairo, Egypt'}</span>
          <span className="flex items-center gap-3">
            <a href="tel:01550098212" style={{ color:'var(--neon)' }}>01550098212</a>
            <span>·</span>
            <a href="tel:01551510427" style={{ color:'var(--neon)' }}>01551510427</a>
            <span>· v2.0.0</span>
          </span>
        </footer>
      </div>

      {/* Floating WhatsApp button — visible on all pages */}
      <FloatingWhatsApp />
    </div>
  );
}
