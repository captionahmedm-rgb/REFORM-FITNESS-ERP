import { ReactNode } from 'react';
import { Loader2, X } from 'lucide-react';

/* ─── Button ─── */
export function Button({
  children, variant = 'primary', size = 'md', loading = false, icon: Icon, className = '', ...props
}: {
  children?: ReactNode; variant?: 'primary'|'secondary'|'danger'|'ghost'; size?: 'sm'|'md'|'lg';
  loading?: boolean; icon?: any; className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const sz = { sm: 'px-3 py-1.5 text-xs', md: 'px-4 py-2 text-sm', lg: 'px-5 py-2.5 text-base' }[size];
  return (
    <button className={`btn btn-${variant} ${sz} ${className}`} disabled={loading || props.disabled} {...props}>
      {loading ? <Loader2 size={15} className="animate-spin" /> : Icon ? <Icon size={15} /> : null}
      {children}
    </button>
  );
}

/* ─── Input ─── */
export function Input({ label, error, className = '', ...props }: { label?: string; error?: string; className?: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      {label && <label className="label">{label}</label>}
      <input className={`input ${className}`} {...props} />
      {error && <p className="text-xs mt-1" style={{ color: 'var(--color-danger)' }}>{error}</p>}
    </div>
  );
}

/* ─── Select ─── */
export function Select({ label, error, children, ...props }: { label?: string; error?: string; children: ReactNode } & React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div>
      {label && <label className="label">{label}</label>}
      <select className="input" {...props}>{children}</select>
      {error && <p className="text-xs mt-1" style={{ color: 'var(--color-danger)' }}>{error}</p>}
    </div>
  );
}

/* ─── Textarea ─── */
export function Textarea({ label, error, ...props }: { label?: string; error?: string } & React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <div>
      {label && <label className="label">{label}</label>}
      <textarea className="input" rows={props.rows ?? 3} {...props} />
      {error && <p className="text-xs mt-1" style={{ color: 'var(--color-danger)' }}>{error}</p>}
    </div>
  );
}

/* ─── Badge ─── */
const BADGE_STYLES: Record<string, { bg: string; color: string }> = {
  default: { bg: 'rgba(100,130,160,0.15)',  color: 'var(--color-text-secondary)' },
  success: { bg: 'rgba(34,197,94,0.15)',    color: '#4ADE80' },
  warning: { bg: 'rgba(245,158,11,0.15)',   color: '#FCD34D' },
  danger:  { bg: 'rgba(239,68,68,0.15)',    color: '#F87171' },
  info:    { bg: 'rgba(0,212,255,0.15)',    color: 'var(--neon)' },
  primary: { bg: 'rgba(0,212,255,0.12)',    color: 'var(--neon)' },
  gold:    { bg: 'rgba(245,158,11,0.15)',   color: '#F59E0B' },
};
export function Badge({ children, color = 'default' }: { children: ReactNode; color?: keyof typeof BADGE_STYLES }) {
  const s = BADGE_STYLES[color] ?? BADGE_STYLES.default;
  return <span className="badge" style={{ background: s.bg, color: s.color }}>{children}</span>;
}

/* ─── Card ─── */
export function Card({ children, className = '', hover = false, glow = false }: { children: ReactNode; className?: string; hover?: boolean; glow?: boolean }) {
  return (
    <div className={`${glow ? 'rf-card-glow' : 'rf-card'} ${hover ? 'cursor-pointer' : ''} ${className}`} style={{ padding: className.includes('p-') ? undefined : '1.25rem' }}>
      {children}
    </div>
  );
}

/* ─── StatCard ─── */
export function StatCard({ label, value, icon: Icon, color, delta }: { label: string; value: ReactNode; icon: any; color: string; delta?: string }) {
  return (
    <div className="rf-card-glow stat-card p-5 cursor-default hover:translate-y-[-2px] transition-transform">
      <div className="flex items-start justify-between mb-4">
        <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: `${color}18`, border: `1px solid ${color}30` }}>
          <Icon size={22} style={{ color }} />
        </div>
        {delta && (
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
            style={{ background: 'rgba(34,197,94,0.12)', color: '#4ADE80' }}>
            {delta}
          </span>
        )}
      </div>
      <p className="text-2xl font-bold mb-1" style={{ color: 'var(--color-text)' }}>{value}</p>
      <p className="text-xs font-medium" style={{ color: 'var(--color-text-muted)' }}>{label}</p>
    </div>
  );
}

/* ─── Modal ─── */
export function Modal({ open, onClose, title, children, size = 'md' }: { open: boolean; onClose: () => void; title: string; children: ReactNode; size?: 'sm'|'md'|'lg'|'xl' }) {
  if (!open) return null;
  const w = { sm: 'max-w-md', md: 'max-w-2xl', lg: 'max-w-4xl', xl: 'max-w-6xl' }[size];
  return (
    <div className="modal-backdrop animate-fade-in" onClick={onClose}>
      <div className={`w-full ${w} max-h-[90vh] overflow-hidden flex flex-col rounded-2xl animate-scale-in`}
        style={{ background: 'var(--color-card)', border: '1px solid var(--color-border-bright)', boxShadow: '0 24px 64px rgba(0,0,0,0.6)' }}
        onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4"
          style={{ borderBottom: '1px solid var(--color-border)' }}>
          <h2 className="text-base font-bold" style={{ color: 'var(--color-text)' }}>{title}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center transition hover:bg-white/5"
            style={{ color: 'var(--color-text-muted)' }}>
            <X size={18} />
          </button>
        </div>
        <div className="overflow-y-auto px-6 py-5 flex-1">{children}</div>
      </div>
    </div>
  );
}

/* ─── Confirm dialog ─── */
export function ConfirmDialog({ open, onClose, onConfirm, title, message }: { open: boolean; onClose: () => void; onConfirm: () => void; title: string; message: string }) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm">
      <p className="text-sm mb-6" style={{ color: 'var(--color-text-secondary)' }}>{message}</p>
      <div className="flex justify-end gap-3">
        <Button variant="secondary" size="sm" onClick={onClose}>Cancel</Button>
        <Button variant="danger"    size="sm" onClick={() => { onConfirm(); onClose(); }}>Delete</Button>
      </div>
    </Modal>
  );
}

/* ─── Empty state ─── */
export function EmptyState({ icon: Icon, title, description, action }: { icon: any; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
        style={{ background: 'rgba(0,212,255,0.08)', border: '1px solid rgba(0,212,255,0.2)' }}>
        <Icon size={28} style={{ color: 'var(--neon)' }} />
      </div>
      <h3 className="text-sm font-bold mb-1" style={{ color: 'var(--color-text)' }}>{title}</h3>
      <p className="text-xs mb-5 max-w-xs" style={{ color: 'var(--color-text-secondary)' }}>{description}</p>
      {action}
    </div>
  );
}

/* ─── Skeleton ─── */
export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />;
}
export function TableSkeleton({ rows = 5, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="space-y-2 p-4">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-3">
          {Array.from({ length: cols }).map((_, j) => <Skeleton key={j} className="h-10 flex-1" />)}
        </div>
      ))}
    </div>
  );
}

/* ─── Page header ─── */
export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
      <div>
        <h1 className="text-2xl font-extrabold" style={{ color: 'var(--color-text)' }}>{title}</h1>
        {subtitle && <p className="text-sm mt-1" style={{ color: 'var(--color-text-muted)' }}>{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

/* ─── Pagination ─── */
export function Pagination({ page, totalPages, onPageChange }: { page: number; totalPages: number; onPageChange: (p: number) => void }) {
  if (totalPages <= 1) return null;
  return (
    <div className="flex items-center justify-between mt-4 px-1">
      <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>Page {page} / {totalPages}</p>
      <div className="flex gap-1">
        <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => onPageChange(page - 1)}>‹ Prev</Button>
        <Button variant="secondary" size="sm" disabled={page >= totalPages} onClick={() => onPageChange(page + 1)}>Next ›</Button>
      </div>
    </div>
  );
}
