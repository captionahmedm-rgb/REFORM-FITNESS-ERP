import { useState, useEffect } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

export function FloatingWhatsApp() {
  const [expanded, setExpanded] = useState(false);
  const [phone1, setPhone1] = useState('201550098212');
  const [phone2, setPhone2] = useState('201551510427');

  useEffect(() => {
    supabase.from('social_media_settings').select('key,value').in('key',['whatsapp_1','whatsapp_2']).then(({data}) => {
      if (!data) return;
      data.forEach((r: any) => {
        const num = r.value?.replace(/\D/g,'');
        if (r.key === 'whatsapp_1' && num) setPhone1(num);
        if (r.key === 'whatsapp_2' && num) setPhone2(num);
      });
    });
  }, []);

  return (
    <div className="fixed bottom-6 end-6 z-50 flex flex-col items-end gap-2">
      {expanded && (
        <div className="animate-scale-in rf-card p-4 rounded-2xl w-56 shadow-card"
          style={{ border:'1px solid rgba(37,211,102,0.3)' }}>
          <p className="text-xs font-bold mb-3" style={{ color:'var(--color-text)' }}>
            Contact REFORM FITNESS
          </p>
          <div className="space-y-2">
            {[
              { label:'WhatsApp 1', phone: phone1 },
              { label:'WhatsApp 2', phone: phone2 },
            ].map(w => (
              <a key={w.phone} href={`https://wa.me/${w.phone}`} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 p-2 rounded-xl transition hover:bg-white/5"
                style={{ background:'var(--color-bg-surface)', textDecoration:'none' }}>
                <MessageCircle size={16} style={{ color:'#25D366' }} />
                <span className="text-xs" style={{ color:'var(--color-text-secondary)' }}>{w.label}</span>
                <span className="text-xs ms-auto" style={{ color:'#25D366' }}>Chat</span>
              </a>
            ))}
          </div>
        </div>
      )}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-14 h-14 rounded-full flex items-center justify-center shadow-card transition hover:scale-110"
        style={{
          background: 'linear-gradient(135deg,#128C7E,#25D366)',
          boxShadow: '0 4px 24px rgba(37,211,102,0.5)',
        }}>
        {expanded
          ? <X size={24} color="white" />
          : <MessageCircle size={26} color="white" />
        }
      </button>
    </div>
  );
}
