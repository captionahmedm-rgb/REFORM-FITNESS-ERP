import { Component, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error caught by boundary:', error, errorInfo);
    this.setState({ errorInfo });
  }

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--color-bg)' }}>
          <div className="max-w-md w-full text-center">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6"
              style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)' }}>
              <AlertTriangle size={40} style={{ color: '#EF4444' }} />
            </div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
              Something went wrong
            </h1>
            <p className="text-sm mb-6" style={{ color: 'var(--color-text-secondary)' }}>
              An unexpected error occurred. Please try refreshing the page or contact support if the problem persists.
            </p>
            {process.env.NODE_ENV === 'development' && this.state.error && (
              <div className="mb-6 p-4 rounded-xl text-left overflow-auto max-h-48"
                style={{ background: 'var(--color-bg-surface)', border: '1px solid var(--color-border)' }}>
                <p className="text-xs font-mono" style={{ color: 'var(--color-danger)' }}>
                  {this.state.error.toString()}
                </p>
                {this.state.errorInfo && (
                  <pre className="text-xs mt-2 whitespace-pre-wrap" style={{ color: 'var(--color-text-muted)' }}>
                    {this.state.errorInfo.componentStack}
                  </pre>
                )}
              </div>
            )}
            <div className="flex gap-3 justify-center">
              <button
                onClick={this.handleGoHome}
                className="px-5 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-2 transition"
                style={{ background: 'var(--color-bg-surface)', color: 'var(--color-text)', border: '1px solid var(--color-border)' }}>
                <Home size={16} />
                Go Home
              </button>
              <button
                onClick={this.handleReload}
                className="px-5 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-2 transition"
                style={{ background: 'linear-gradient(135deg, #0099BB, #00D4FF)', color: '#050A14' }}>
                <RefreshCw size={16} />
                Refresh Page
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
