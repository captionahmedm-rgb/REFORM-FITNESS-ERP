import { useEffect, useState, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { DataTable, Column } from '../components/DataTable';
import { Button, Input, Select, Textarea, Modal, ConfirmDialog, PageHeader } from '../components/ui';
import { Plus } from 'lucide-react';

export interface FieldDef {
  key: string;
  label: string;
  labelAr: string;
  type: 'text' | 'number' | 'date' | 'select' | 'textarea' | 'email' | 'tel';
  required?: boolean;
  options?: { value: string; label: string }[];
  defaultValue?: any;
  full?: boolean;
}

export interface GenericPageProps {
  table: string;
  title: string;
  titleAr: string;
  subtitle: string;
  subtitleAr: string;
  fields: FieldDef[];
  columns: Column<any>[];
  searchKeys: string[];
  codePrefix?: string;
  codeField?: string;
  filters?: { key: string; label: string; options: { value: string; label: string }[] }[];
  extraActions?: ReactNode;
}

export function GenericPage({ table, title, titleAr, subtitle, subtitleAr, fields, columns, searchKeys, codePrefix, codeField = 'name', filters: filterDefs = [] }: GenericPageProps) {
  const { toast } = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState<any>({});
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [viewItem, setViewItem] = useState<any | null>(null);
  const [filterValues, setFilterValues] = useState<Record<string, string>>({});

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from(table).select('*').order('created_at', { ascending: false });
    setData(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const emptyForm = () => {
    const obj: any = {};
    fields.forEach((f) => { obj[f.key] = f.defaultValue ?? ''; });
    return obj;
  };

  const handleAdd = () => { setForm(emptyForm()); setEditId(null); setModalOpen(true); };
  const handleEdit = (row: any) => {
    const obj: any = {};
    fields.forEach((f) => { obj[f.key] = row[f.key] ?? ''; });
    setForm(obj); setEditId(row.id); setModalOpen(true);
  };

  const handleSave = async () => {
    const required = fields.filter((f) => f.required);
    for (const f of required) {
      if (!form[f.key]?.toString().trim()) {
        toast(`${isAr ? f.labelAr : f.label} ${isAr ? 'مطلوب' : 'is required'}`, 'warning');
        return;
      }
    }
    setSaving(true);
    const payload: any = { ...form };
    fields.forEach((f) => {
      if (f.type === 'number' && payload[f.key] !== '') payload[f.key] = parseFloat(payload[f.key]) || null;
    });

    let finalPayload = payload;
    if (!editId && codePrefix) {
      finalPayload = { ...payload, [codeField]: `${codePrefix}-${Date.now().toString().slice(-6)}` };
    }

    const { error } = editId
      ? await supabase.from(table).update(finalPayload).eq('id', editId)
      : await supabase.from(table).insert([finalPayload]);

    if (error) toast(error.message, 'error');
    else {
      toast(editId ? (isAr ? 'تم التحديث' : 'Updated') : (isAr ? 'تمت الإضافة' : 'Added'), 'success');
      setModalOpen(false);
      load();
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from(table).delete().eq('id', deleteId);
    if (error) toast(error.message, 'error');
    else { toast(isAr ? 'تم الحذف' : 'Deleted', 'success'); load(); }
    setDeleteId(null);
  };

  let filtered = data;
  filterDefs.forEach((f) => {
    const val = filterValues[f.key];
    if (val) filtered = filtered.filter((d) => d[f.key] === val);
  });

  const tableFilters = filterDefs.map((f) => ({
    label: f.label,
    value: filterValues[f.key] || '',
    onChange: (v: string) => setFilterValues({ ...filterValues, [f.key]: v }),
    options: f.options,
  }));

  return (
    <div>
      <PageHeader
        title={isAr ? titleAr : title}
        subtitle={isAr ? subtitleAr : subtitle}
        action={<Button icon={Plus} onClick={handleAdd}>{isAr ? 'إضافة' : 'Add New'}</Button>}
      />

      <DataTable
        data={filtered}
        columns={columns}
        loading={loading}
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={(r) => setDeleteId(r.id)}
        onView={(r) => setViewItem(r)}
        searchKeys={searchKeys}
        filters={tableFilters}
        emptyTitle={isAr ? 'لا توجد بيانات' : 'No records yet'}
        emptyDescription={isAr ? 'ابدأ بإضافة أول سجل' : 'Start by adding your first record'}
      />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? (isAr ? 'تعديل' : 'Edit') : (isAr ? 'إضافة' : 'Add New')} size="lg">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {fields.map((f) => (
            <div key={f.key} className={f.full ? 'md:col-span-2' : ''}>
              {f.type === 'textarea' ? (
                <Textarea label={isAr ? f.labelAr : f.label} value={form[f.key] || ''} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
              ) : f.type === 'select' ? (
                <Select label={isAr ? f.labelAr : f.label} value={form[f.key] || ''} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}>
                  <option value="">—</option>
                  {f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </Select>
              ) : (
                <Input label={isAr ? f.labelAr : f.label} type={f.type} value={form[f.key] || ''} onChange={(e) => setForm({ ...form, [f.key]: e.target.value })} />
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <Button variant="secondary" onClick={() => setModalOpen(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
          <Button onClick={handleSave} loading={saving}>{isAr ? 'حفظ' : 'Save'}</Button>
        </div>
      </Modal>

      <Modal open={!!viewItem} onClose={() => setViewItem(null)} title={isAr ? 'التفاصيل' : 'Details'} size="md">
        {viewItem && (
          <div className="space-y-3">
            {fields.map((f) => (
              <div key={f.key} className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--color-border)' }}>
                <span className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>{isAr ? f.labelAr : f.label}</span>
                <span className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>{viewItem[f.key] || '—'}</span>
              </div>
            ))}
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title={isAr ? 'تأكيد الحذف' : 'Confirm Delete'}
        message={isAr ? 'هل أنت متأكد من الحذف؟' : 'Are you sure you want to delete this record?'}
      />
    </div>
  );
}
