import { useState } from 'react';
import { Dumbbell } from 'lucide-react';
import { AuthProvider, useAuth }      from './contexts/AuthContext';
import { ThemeProvider }              from './contexts/ThemeContext';
import { ToastProvider }              from './contexts/ToastContext';
import { AuthPage }                   from './pages/AuthPage';
import { Layout }                     from './components/Layout';
import { DashboardPage }              from './pages/DashboardPage';
import { EmployeesPage }              from './pages/EmployeesPage';
import { CustomersPage }              from './pages/CustomersPage';
import { SalesPage }                  from './pages/SalesPage';
import { ReportsPage }                from './pages/ReportsPage';
import { SettingsPage }               from './pages/SettingsPage';
import { AboutPage, ContactPage }     from './pages/InfoPages';
import { ProfilePage }                from './pages/ProfilePage';
import { LeaveManagementPage }        from './pages/LeaveManagementPage';
import { SocialMediaPage }            from './pages/SocialMediaPage';
import {
  AttendancePage, PayrollPage, ProductsPage,
  InventoryPage, OrdersPage,
} from './pages/ModulePages';

function AppContent() {
  const { session, loading } = useAuth();
  const [page, setPage] = useState('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center" style={{ background:'var(--color-bg)' }}>
        <div className="relative w-24 h-24 flex items-center justify-center mb-6">
          <div className="absolute inset-0 rounded-full border-2 animate-spin-slow"
            style={{ borderColor:'rgba(0,212,255,0.2)', borderTopColor:'var(--neon)' }} />
          <div className="absolute inset-3 rounded-full border border-neon/30 animate-spin-slow"
            style={{ animationDirection:'reverse', animationDuration:'4s' }} />
          <div className="w-12 h-12 rounded-xl flex items-center justify-center"
            style={{ background:'linear-gradient(135deg,#0099BB,#00D4FF)', boxShadow:'0 0 28px rgba(0,212,255,0.5)' }}>
            <Dumbbell size={22} style={{ color:'#050A14' }} />
          </div>
        </div>
        <p className="logo-text text-2xl mb-1">REFORM FITNESS</p>
        <p className="text-xs mb-4" style={{ color:'var(--color-text-muted)' }}>Enterprise Management System v2.0</p>
        <div className="flex gap-1.5">
          {[0,1,2,3].map(i => (
            <div key={i} className="w-2 h-2 rounded-full animate-bounce"
              style={{ background:'var(--neon)', animationDelay:`${i*0.15}s`, opacity:0.7 }} />
          ))}
        </div>
      </div>
    );
  }

  if (!session) return <AuthPage />;

  const renderPage = () => {
    switch (page) {
      case 'dashboard':  return <DashboardPage />;
      case 'employees':  return <EmployeesPage />;
      case 'attendance': return <AttendancePage />;
      case 'leave':      return <LeaveManagementPage />;
      case 'payroll':    return <PayrollPage />;
      case 'customers':  return <CustomersPage />;
      case 'products':   return <ProductsPage />;
      case 'inventory':  return <InventoryPage />;
      case 'sales':      return <SalesPage />;
      case 'orders':     return <OrdersPage />;
      case 'reports':    return <ReportsPage />;
      case 'social':     return <SocialMediaPage />;
      case 'settings':   return <SettingsPage />;
      case 'about':      return <AboutPage />;
      case 'contact':    return <ContactPage />;
      case 'profile':    return <ProfilePage />;
      default:           return <DashboardPage />;
    }
  };

  return (
    <Layout currentPage={page} onNavigate={setPage}>
      {renderPage()}
    </Layout>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}
