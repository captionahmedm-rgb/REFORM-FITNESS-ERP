export interface AppUser {
  id: string;
  auth_id: string | null;
  employee_id: string | null;
  full_name: string;
  email: string | null;
  phone: string | null;
  avatar_url: string | null;
  job_title: string | null;
  department_id: string | null;
  department_name: string | null;
  branch_id: string | null;
  branch_name: string | null;
  manager_id: string | null;
  status: string;
  hire_date: string | null;
  last_login: string | null;
  created_at: string;
  updated_at: string;
  // Extended personal info
  gender: string | null;
  date_of_birth: string | null;
  national_id: string | null;
  nationality: string | null;
  marital_status: string | null;
  whatsapp_number: string | null;
  personal_email: string | null;
  company_email: string | null;
  address: string | null;
  city: string | null;
  governorate: string | null;
  postal_code: string | null;
  emergency_contact: string | null;
  emergency_phone: string | null;
  contract_type: string | null;
  employment_type: string | null;
  shift_type: string | null;
  salary: number | null;
  years_experience: number | null;
  previous_company: string | null;
  role_label: string | null;
  notes: string | null;
}

export interface Role {
  id: string;
  name: string;
  display_name: string;
  description: string | null;
  is_system: boolean;
}

export interface Branch {
  id: string;
  name: string;
  code: string | null;
  address: string | null;
  city: string | null;
  phone: string | null;
  email: string | null;
  is_active: boolean;
}

export interface ThemeSettings {
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  sidebarColor: string;
  cardColor: string;
  borderColor: string;
  textColor: string;
  secondaryTextColor: string;
  successColor: string;
  warningColor: string;
  dangerColor: string;
  borderRadius: string;
  mode: 'dark' | 'light';
  fontFamily: string;
}

export interface CompanySettings {
  name: string;
  logo: string;
  favicon: string;
  tagline: string;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string | null;
  type: 'info' | 'success' | 'warning' | 'error';
  module: string | null;
  is_read: boolean;
  link: string | null;
  created_at: string;
}

export interface Customer {
  id: string;
  customer_code: string | null;
  full_name: string;
  national_id: string | null;
  email: string | null;
  phone: string | null;
  whatsapp_number: string | null;
  address: string | null;
  city: string | null;
  country: string;
  date_of_birth: string | null;
  gender: string | null;
  occupation: string | null;
  emergency_contact: string | null;
  emergency_phone: string | null;
  profile_photo: string | null;
  height: number | null;
  weight: number | null;
  body_fat: number | null;
  muscle_mass: number | null;
  bmi: number | null;
  fitness_goal: string | null;
  activity_level: string | null;
  diseases: string | null;
  allergies: string | null;
  medications: string | null;
  injuries: string | null;
  medical_notes: string | null;
  trainer_id: string | null;
  nutritionist_id: string | null;
  doctor_id: string | null;
  subscription_status: string;
  payment_status: string;
  wallet_balance: number;
  loyalty_points: number;
  referral_code: string | null;
  branch_id: string | null;
  status: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  product_code: string | null;
  name: string;
  barcode: string | null;
  category_id: string | null;
  supplier_id: string | null;
  brand: string | null;
  description: string | null;
  unit: string;
  cost_price: number | null;
  selling_price: number | null;
  min_stock: number;
  is_active: boolean;
  image_url: string | null;
  created_at: string;
}

export interface Sale {
  id: string;
  sale_number: string | null;
  customer_id: string | null;
  branch_id: string | null;
  sale_date: string;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  payment_method: string | null;
  payment_status: string;
  status: string;
  cashier_id: string | null;
  notes: string | null;
  created_at: string;
}
