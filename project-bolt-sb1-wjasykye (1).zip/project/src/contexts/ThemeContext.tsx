import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '../lib/supabase';

interface ThemeCtx {
  mode: 'dark' | 'light';
  language: 'en' | 'ar';
  direction: 'ltr' | 'rtl';
  toggleMode: () => void;
  setLanguage: (l: 'en' | 'ar') => void;
  companyName: string;
  ownerName: string;
}

const ThemeContext = createContext<ThemeCtx | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<'dark' | 'light'>('dark');
  const [language, setLang] = useState<'en' | 'ar'>('en');

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('light', mode === 'light');
    root.classList.toggle('rtl', language === 'ar');
    root.setAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
    root.setAttribute('lang', language);
  }, [mode, language]);

  // Persist in settings
  const setLanguage = async (l: 'en' | 'ar') => {
    setLang(l);
    try { await supabase.from('settings').upsert({ key: 'language', value: { default: l } as any, category: 'general', is_public: true }, { onConflict: 'key' }); } catch {}
  };
  const toggleMode = async () => {
    const next = mode === 'dark' ? 'light' : 'dark';
    setMode(next);
    try { await supabase.from('settings').upsert({ key: 'mode', value: { mode: next } as any, category: 'theme', is_public: true }, { onConflict: 'key' }); } catch {}
  };

  // Load persisted prefs
  useEffect(() => {
    (async () => {
      try {
        const { data } = await supabase.from('settings').select('key, value').in('key', ['language', 'mode']);
        if (data) {
          data.forEach((r: any) => {
            if (r.key === 'language' && r.value?.default) setLang(r.value.default);
            if (r.key === 'mode' && r.value?.mode) setMode(r.value.mode);
          });
        }
      } catch {}
    })();
  }, []);

  const direction = language === 'ar' ? 'rtl' : 'ltr';

  return (
    <ThemeContext.Provider value={{
      mode, language, direction, toggleMode, setLanguage,
      companyName: 'REFORM FITNESS',
      ownerName: 'Captain Ahmed Mohamed',
    }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme outside provider');
  return ctx;
}
