import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import type { AppUser, Role } from '../types';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  profile: AppUser | null;
  roles: Role[];
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfile: (updates: Partial<AppUser>) => Promise<{ error: string | null }>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user,    setUser]    = useState<User | null>(null);
  const [profile, setProfile] = useState<AppUser | null>(null);
  const [roles,   setRoles]   = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);

  const loadProfile = async (authId: string) => {
    try {
      const { data: profileData } = await supabase
        .from('app_users').select('*').eq('auth_id', authId).maybeSingle();
      if (profileData) {
        setProfile(profileData as AppUser);
        const { data: roleData } = await supabase
          .from('user_roles').select('role:roles(*)').eq('user_id', (profileData as AppUser).id);
        if (roleData) setRoles(roleData.map((r: any) => r.role).filter(Boolean));
        // Update last login (fire-and-forget)
        supabase.from('app_users').update({ last_login: new Date().toISOString() }).eq('id', (profileData as AppUser).id);
      }
    } catch {}
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        (async () => {
          await loadProfile(session.user.id);
          setLoading(false);
        })();
      } else {
        setProfile(null); setRoles([]); setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { error: error.message };
    if (data.user) {
      const { error: insErr } = await supabase.from('app_users').insert({
        auth_id: data.user.id, full_name: fullName, email, status: 'active',
        employee_id: 'EMP-' + Date.now().toString().slice(-6),
      });
      if (insErr) return { error: insErr.message };
      // First user gets super_admin
      const { count } = await supabase.from('app_users').select('*', { count: 'exact', head: true });
      if (count === 1) {
        const { data: adminRole } = await supabase.from('roles').select('id').eq('name', 'super_admin').maybeSingle();
        if (adminRole) {
          const { data: newProfile } = await supabase.from('app_users').select('id').eq('auth_id', data.user.id).maybeSingle();
          if (newProfile) await supabase.from('user_roles').insert({ user_id: newProfile.id, role_id: adminRole.id });
        }
      }
    }
    return { error: null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null); setRoles([]);
  };

  const refreshProfile = async () => {
    if (user) await loadProfile(user.id);
  };

  const updateProfile = async (updates: Partial<AppUser>) => {
    if (!profile) return { error: 'Not authenticated' };
    const { error } = await supabase.from('app_users').update(updates).eq('id', profile.id);
    if (error) return { error: error.message };
    // Refresh local profile
    await loadProfile(profile.auth_id!);
    return { error: null };
  };

  const changePassword = async (_currentPassword: string, newPassword: string) => {
    if (newPassword.length < 6) return { error: 'Password must be at least 6 characters' };
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    return { error: error?.message ?? null };
  };

  return (
    <AuthContext.Provider value={{ session, user, profile, roles, loading, signIn, signUp, signOut, refreshProfile, updateProfile, changePassword }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
