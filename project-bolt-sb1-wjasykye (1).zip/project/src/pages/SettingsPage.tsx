import { useState } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../contexts/ToastContext';
import { Card, PageHeader, Button, Input, Select } from '../components/ui';
import { Palette, Globe, Moon, Sun, Save, Building2, Shield, Bell } from 'lucide-react';

export function SettingsPage() {
  const { language, setLanguage, mode, toggleMode } = useTheme();
  const { toast } = useToast();
  const isAr = language === 'ar';
  const [tab, setTab] = useState('general');

  // Theme colors - live adjustable
  const [primary, setPrimary] = useState('#00D4FF');
  const [bg, setBg]           = useState('#050A14');
  const [sidebar, setSidebar] = useState('#07101E');
  const [card, setCard]       = useState('#0D1526');
  const [radius, setRadius]   = useState('12px');

  const applyColors = () => {
    const root = document.documentElement;
    root.style.setProperty('--color-primary', primary);
    root.style.setProperty('--neon', primary);
    root.style.setProperty('--color-bg', bg);
    root.style.setProperty('--color-sidebar', sidebar);
    root.style.setProperty('--color-card', card);
    root.style.setProperty('--radius', radius);
    toast(isAr ? 'تم تطبيق الثيم' : 'Theme applied', 'success');
  };

  const resetColors = () => {
    setPrimary('#00D4FF'); setBg('#050A14'); setSidebar('#07101E'); setCard('#0D1526'); setRadius('12px');
    const root = document.documentElement;
    root.style.setProperty('--color-primary','#00D4FF');
    root.style.setProperty('--neon','#00D4FF');
    root.style.setProperty('--color-bg','#050A14');
    root.style.setProperty('--color-sidebar','#07101E');
    root.style.setProperty('--color-card','#0D1526');
    root.style.setProperty('--radius','12px');
    toast('Reset to defaults', 'success');
  };

  const tabs = [
    { id:'general',      icon: Building2, en:'General',          ar:'عام' },
    { id:'theme',        icon: Palette,   en:'Theme',            ar:'المظهر' },
    { id:'language',     icon: Globe,     en:'Language',         ar:'اللغة' },
    { id:'security',     icon: Shield,    en:'Security',         ar:'الأمان' },
    { id:'notifications',icon: Bell,      en:'Notifications',    ar:'الإشعارات' },
  ];

  const renderContent = () => {
    if (tab === 'theme') return (
      <Card>
        <h3 className="font-bold mb-5" style={{ color:'var(--color-text)' }}>{isAr?'إعدادات المظهر':'Theme & Appearance'}</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div>
            <label className="label">{isAr?'اللون الأساسي (Neon)':'Primary Color (Neon)'}</label>
            <div className="flex gap-2">
              <input type="color" value={primary} onChange={e=>setPrimary(e.target.value)} className="w-12 h-10 rounded cursor-pointer" style={{border:'1px solid var(--color-border)'}} />
              <Input value={primary} onChange={e=>setPrimary(e.target.value)} />
            </div>
          </div>
          <div>
            <label className="label">{isAr?'لون الخلفية':'Background Color'}</label>
            <div className="flex gap-2">
              <input type="color" value={bg} onChange={e=>setBg(e.target.value)} className="w-12 h-10 rounded cursor-pointer" style={{border:'1px solid var(--color-border)'}} />
              <Input value={bg} onChange={e=>setBg(e.target.value)} />
            </div>
          </div>
          <div>
            <label className="label">{isAr?'لون الشريط الجانبي':'Sidebar Color'}</label>
            <div className="flex gap-2">
              <input type="color" value={sidebar} onChange={e=>setSidebar(e.target.value)} className="w-12 h-10 rounded cursor-pointer" style={{border:'1px solid var(--color-border)'}} />
              <Input value={sidebar} onChange={e=>setSidebar(e.target.value)} />
            </div>
          </div>
          <div>
            <label className="label">{isAr?'لون البطاقات':'Card Color'}</label>
            <div className="flex gap-2">
              <input type="color" value={card} onChange={e=>setCard(e.target.value)} className="w-12 h-10 rounded cursor-pointer" style={{border:'1px solid var(--color-border)'}} />
              <Input value={card} onChange={e=>setCard(e.target.value)} />
            </div>
          </div>
          <div>
            <label className="label">{isAr?'نصف القطر':'Border Radius'}</label>
            <Select value={radius} onChange={e=>setRadius(e.target.value)}>
              <option value="8px">8px — Sharp</option>
              <option value="12px">12px — Medium</option>
              <option value="16px">16px — Rounded</option>
              <option value="20px">20px — Pill</option>
            </Select>
          </div>
          <div>
            <label className="label">{isAr?'الوضع':'Color Mode'}</label>
            <button onClick={toggleMode} className="btn btn-secondary w-full flex items-center justify-center gap-2">
              {mode === 'dark' ? <><Sun size={16}/> Light Mode</> : <><Moon size={16}/> Dark Mode</>}
            </button>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <Button icon={Save} onClick={applyColors}>{isAr?'تطبيق':'Apply'}</Button>
          <Button variant="secondary" onClick={resetColors}>{isAr?'إعادة تعيين':'Reset Defaults'}</Button>
        </div>
        <p className="text-xs mt-3" style={{ color:'var(--color-text-muted)' }}>
          {isAr ? 'التغييرات تُطبَّق فوراً على النظام' : 'Changes apply instantly without code editing.'}
        </p>
      </Card>
    );

    if (tab === 'language') return (
      <Card>
        <h3 className="font-bold mb-5" style={{ color:'var(--color-text)' }}>{isAr?'إعدادات اللغة':'Language Settings'}</h3>
        <div className="space-y-4 max-w-sm">
          <div>
            <label className="label">{isAr?'اللغة الافتراضية':'Default Language'}</label>
            <Select value={language} onChange={e=>setLanguage(e.target.value as 'en'|'ar')}>
              <option value="en">English (LTR)</option>
              <option value="ar">العربية (RTL)</option>
            </Select>
          </div>
          <div className="p-4 rounded-xl" style={{ background:'var(--color-bg-surface)' }}>
            <p className="text-sm" style={{ color:'var(--color-text-secondary)' }}>
              {isAr ? 'اللغة الحالية: ' : 'Current language: '}
              <span className="font-bold neon-text">{language === 'ar' ? 'العربية' : 'English'}</span>
            </p>
            <p className="text-xs mt-1" style={{ color:'var(--color-text-muted)' }}>
              {isAr ? 'الاتجاه: RTL' : 'Direction: LTR'}
            </p>
          </div>
        </div>
      </Card>
    );

    if (tab === 'security') return (
      <Card>
        <h3 className="font-bold mb-5" style={{ color:'var(--color-text)' }}>{isAr?'إعدادات الأمان':'Security Settings'}</h3>
        <div className="space-y-3 max-w-md">
          {['Two-Factor Authentication (2FA)','Brute Force Protection','Auto Logout After Inactivity','Login Notifications','Account Lock After Failed Attempts'].map((s,i)=>(
            <div key={i} className="flex items-center justify-between p-3 rounded-xl" style={{ background:'var(--color-bg-surface)' }}>
              <span className="text-sm" style={{ color:'var(--color-text)' }}>{s}</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked={i>0} className="sr-only peer"/>
                <div className="w-10 h-5 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:start-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"
                  style={{ background:'var(--color-border)' }}></div>
              </label>
            </div>
          ))}
          <Button onClick={()=>toast(isAr?'تم الحفظ':'Saved','success')} className="mt-2">{isAr?'حفظ':'Save'}</Button>
        </div>
      </Card>
    );

    if (tab === 'notifications') return (
      <Card>
        <h3 className="font-bold mb-5" style={{ color:'var(--color-text)' }}>{isAr?'إعدادات الإشعارات':'Notification Settings'}</h3>
        <div className="space-y-3 max-w-md">
          {['Low Stock Alerts','New Customer Registration','New Sale Completed','Employee Attendance Alert','Payroll Due Reminder','System Updates'].map((s,i)=>(
            <div key={i} className="flex items-center justify-between p-3 rounded-xl" style={{ background:'var(--color-bg-surface)' }}>
              <span className="text-sm" style={{ color:'var(--color-text)' }}>{s}</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="sr-only peer"/>
                <div className="w-10 h-5 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:start-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"
                  style={{ background:'var(--color-border)' }}></div>
              </label>
            </div>
          ))}
          <Button onClick={()=>toast(isAr?'تم الحفظ':'Saved','success')}>{isAr?'حفظ':'Save'}</Button>
        </div>
      </Card>
    );

    // General
    return (
      <Card>
        <h3 className="font-bold mb-5" style={{ color:'var(--color-text)' }}>{isAr?'الإعدادات العامة':'General Settings'}</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl">
          <Input label={isAr?'اسم الشركة':'Company Name'} defaultValue="REFORM FITNESS" />
          <Input label={isAr?'اسم المالك':'Owner Name'} defaultValue="Captain Ahmed Mohamed" />
          <Input label={isAr?'البريد الرئيسي':'Main Email'} defaultValue="captionahmedm@gmail.com" />
          <Input label={isAr?'بريد المتجر':'Store Email'} defaultValue="captainahmedstoreynutritionals@gmail.com" />
          <Input label={isAr?'الهاتف 1':'Phone 1'} defaultValue="01550098212" />
          <Input label={isAr?'الهاتف 2':'Phone 2'} defaultValue="01551510427" />
          <Input label={isAr?'الموقع':'Location'} defaultValue="Cairo, Egypt" />
          <Select label={isAr?'العملة':'Currency'} defaultValue="EGP">
            <option value="EGP">EGP — Egyptian Pound</option>
            <option value="USD">USD — US Dollar</option>
            <option value="SAR">SAR — Saudi Riyal</option>
          </Select>
        </div>
        <Button icon={Save} className="mt-5" onClick={()=>toast(isAr?'تم الحفظ':'Saved','success')}>{isAr?'حفظ':'Save Changes'}</Button>
      </Card>
    );
  };

  return (
    <div>
      <PageHeader title={isAr?'الإعدادات':'Settings'} subtitle={isAr?'تكوين النظام':'System configuration'} />
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar */}
        <div className="lg:w-52 flex-shrink-0">
          <div className="rf-card p-2 space-y-1">
            {tabs.map(t => {
              const Icon = t.icon;
              return (
                <button key={t.id} onClick={()=>setTab(t.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition nav-item ${tab===t.id?'nav-active':''}`}
                  style={{ color: tab===t.id ? 'var(--neon)' : 'var(--color-text-secondary)' }}>
                  <Icon size={16}/><span>{isAr?t.ar:t.en}</span>
                </button>
              );
            })}
          </div>
        </div>
        <div className="flex-1">{renderContent()}</div>
      </div>
    </div>
  );
}
