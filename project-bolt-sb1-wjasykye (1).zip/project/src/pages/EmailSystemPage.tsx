import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { Button, Input, Select, Textarea, Modal, PageHeader, Badge, Card } from '../components/ui';
import { Plus, Mail, Inbox, Send, FileText, Trash2, Edit, Copy, Eye, Server, FileCode } from 'lucide-react';

type Tab = 'inbox' | 'sent' | 'drafts' | 'templates' | 'accounts' | 'campaigns';

export function EmailSystemPage() {
  const { toast } = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';
  const [tab, setTab] = useState<Tab>('inbox');
  const [messages, setMessages] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [composeOpen, setComposeOpen] = useState(false);
  const [templateModal, setTemplateModal] = useState(false);
  const [accountModal, setAccountModal] = useState(false);
  const [viewMsg, setViewMsg] = useState<any | null>(null);
  const [editTemplate, setEditTemplate] = useState<any | null>(null);

  // Compose form
  const [compose, setCompose] = useState({ to: '', subject: '', body: '', template_id: '' });
  // Template form
  const [tplForm, setTplForm] = useState({ name: '', subject: '', body: '', category: 'general' });
  // Account form
  const [accForm, setAccForm] = useState({ name: '', email_address: '', provider: 'smtp', smtp_host: '', smtp_port: '587', smtp_username: '', smtp_password_encrypted: '', use_ssl: true });

  const load = async () => {
    setLoading(true);
    const folder = tab === 'inbox' ? 'inbox' : tab === 'sent' ? 'sent' : tab === 'drafts' ? 'drafts' : null;
    if (folder) {
      const { data } = await supabase.from('email_messages').select('*').eq('folder', folder).order('created_at', { ascending: false });
      setMessages(data || []);
    }
    const { data: tpls } = await supabase.from('email_templates').select('*').order('created_at', { ascending: false });
    setTemplates(tpls || []);
    const { data: accs } = await supabase.from('email_accounts').select('*').order('created_at', { ascending: false });
    setAccounts(accs || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [tab]);

  const sendEmail = async () => {
    if (!compose.to || !compose.subject) { toast(isAr ? 'يرجى ملء الحقول' : 'Please fill all fields', 'warning'); return; }
    const { error } = await supabase.from('email_messages').insert([{
      ...compose,
      folder: 'sent',
      status: 'sent',
      sent_at: new Date().toISOString(),
    }]);
    if (error) toast(error.message, 'error');
    else { toast(isAr ? 'تم إرسال البريد' : 'Email sent', 'success'); setComposeOpen(false); setCompose({ to: '', subject: '', body: '', template_id: '' }); load(); }
  };

  const saveTemplate = async () => {
    if (!tplForm.name) { toast(isAr ? 'الاسم مطلوب' : 'Name required', 'warning'); return; }
    const { error } = editTemplate
      ? await supabase.from('email_templates').update(tplForm).eq('id', editTemplate.id)
      : await supabase.from('email_templates').insert([tplForm]);
    if (error) toast(error.message, 'error');
    else { toast(isAr ? 'تم الحفظ' : 'Saved', 'success'); setTemplateModal(false); setEditTemplate(null); setTplForm({ name: '', subject: '', body: '', category: 'general' }); load(); }
  };

  const saveAccount = async () => {
    if (!accForm.name || !accForm.email_address) { toast(isAr ? 'يرجى ملء الحقول' : 'Please fill fields', 'warning'); return; }
    const { error } = await supabase.from('email_accounts').insert([{ ...accForm, smtp_port: parseInt(accForm.smtp_port) || 587 }]);
    if (error) toast(error.message, 'error');
    else { toast(isAr ? 'تم الحفظ' : 'Saved', 'success'); setAccountModal(false); setAccForm({ name: '', email_address: '', provider: 'smtp', smtp_host: '', smtp_port: '587', smtp_username: '', smtp_password_encrypted: '', use_ssl: true }); load(); }
  };

  const deleteTemplate = async (id: string) => {
    await supabase.from('email_templates').delete().eq('id', id);
    toast(isAr ? 'تم الحذف' : 'Deleted', 'success'); load();
  };

  const duplicateTemplate = async (tpl: any) => {
    await supabase.from('email_templates').insert([{ ...tpl, name: `${tpl.name} (Copy)`, id: undefined }]);
    toast(isAr ? 'تم نسخ القالب' : 'Template duplicated', 'success'); load();
  };

  const tabs: { id: Tab; label: string; labelAr: string; icon: any }[] = [
    { id: 'inbox', label: 'Inbox', labelAr: 'الوارد', icon: Inbox },
    { id: 'sent', label: 'Sent', labelAr: 'الصادر', icon: Send },
    { id: 'drafts', label: 'Drafts', labelAr: 'المسودات', icon: FileText },
    { id: 'templates', label: 'Templates', labelAr: 'القوالب', icon: FileCode },
    { id: 'accounts', label: 'SMTP Accounts', labelAr: 'حسابات SMTP', icon: Server },
    { id: 'campaigns', label: 'Campaigns', labelAr: 'الحملات', icon: Mail },
  ];

  return (
    <div>
      <PageHeader
        title={isAr ? 'نظام البريد الإلكتروني' : 'Email System'}
        subtitle={isAr ? 'إدارة البريد والقوالب والحسابات' : 'Manage emails, templates, and SMTP accounts'}
        action={<Button icon={Plus} onClick={() => setComposeOpen(true)}>{isAr ? 'بريد جديد' : 'Compose'}</Button>}
      />

      {/* Tabs */}
      <div className="flex gap-1 mb-4 overflow-x-auto pb-1">
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition whitespace-nowrap"
              style={{
                background: tab === t.id ? 'var(--color-primary)' : 'var(--color-card)',
                color: tab === t.id ? 'white' : 'var(--color-text-secondary)',
                border: '1px solid var(--color-border)',
              }}
            >
              <Icon size={16} />
              {isAr ? t.labelAr : t.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      {loading ? (
        <Card><div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="skeleton h-12" />)}</div></Card>
      ) : tab === 'templates' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates.length === 0 ? (
            <Card className="col-span-full text-center py-12">
              <FileCode size={32} className="mx-auto mb-3" style={{ color: 'var(--color-text-secondary)' }} />
              <p style={{ color: 'var(--color-text-secondary)' }}>{isAr ? 'لا توجد قوالب' : 'No templates yet'}</p>
              <Button icon={Plus} className="mt-4" onClick={() => { setEditTemplate(null); setTplForm({ name: '', subject: '', body: '', category: 'general' }); setTemplateModal(true); }}>{isAr ? 'إضافة قالب' : 'Add Template'}</Button>
            </Card>
          ) : (
            <>
              {templates.map((tpl) => (
                <Card key={tpl.id} hover>
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold" style={{ color: 'var(--color-text)' }}>{tpl.name}</h3>
                    <Badge color="info">{tpl.category}</Badge>
                  </div>
                  <p className="text-sm mb-1" style={{ color: 'var(--color-text-secondary)' }}>{tpl.subject}</p>
                  <p className="text-xs line-clamp-2 mb-3" style={{ color: 'var(--color-text-secondary)' }}>{tpl.body}</p>
                  <div className="flex gap-1">
                    <button onClick={() => setViewMsg(tpl)} className="p-1.5 rounded" style={{ color: 'var(--color-text-secondary)' }}><Eye size={16} /></button>
                    <button onClick={() => { setEditTemplate(tpl); setTplForm({ name: tpl.name, subject: tpl.subject || '', body: tpl.body || '', category: tpl.category || 'general' }); setTemplateModal(true); }} className="p-1.5 rounded" style={{ color: 'var(--color-primary)' }}><Edit size={16} /></button>
                    <button onClick={() => duplicateTemplate(tpl)} className="p-1.5 rounded" style={{ color: 'var(--color-text-secondary)' }}><Copy size={16} /></button>
                    <button onClick={() => deleteTemplate(tpl.id)} className="p-1.5 rounded" style={{ color: 'var(--color-danger)' }}><Trash2 size={16} /></button>
                  </div>
                </Card>
              ))}
              <Card className="flex items-center justify-center cursor-pointer border-dashed" hover>
                <button onClick={() => { setEditTemplate(null); setTplForm({ name: '', subject: '', body: '', category: 'general' }); setTemplateModal(true); }} className="flex flex-col items-center" style={{ color: 'var(--color-text-secondary)' }}>
                  <Plus size={24} className="mb-1" />
                  <span className="text-sm">{isAr ? 'إضافة قالب' : 'Add Template'}</span>
                </button>
              </Card>
            </>
          )}
        </div>
      ) : tab === 'accounts' ? (
        <div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {accounts.map((acc) => (
              <Card key={acc.id} hover>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'var(--color-primary)20' }}>
                      <Server size={20} style={{ color: 'var(--color-primary)' }} />
                    </div>
                    <div>
                      <h3 className="font-semibold" style={{ color: 'var(--color-text)' }}>{acc.name}</h3>
                      <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>{acc.email_address}</p>
                    </div>
                  </div>
                  <Badge color={acc.is_active ? 'success' : 'default'}>{acc.provider}</Badge>
                </div>
                <div className="mt-3 text-xs space-y-1" style={{ color: 'var(--color-text-secondary)' }}>
                  <p>SMTP: {acc.smtp_host}:{acc.smtp_port}</p>
                  <p>SSL: {acc.use_ssl ? 'Yes' : 'No'}</p>
                </div>
              </Card>
            ))}
          </div>
          <Button icon={Plus} onClick={() => setAccountModal(true)}>{isAr ? 'إضافة حساب' : 'Add Account'}</Button>
        </div>
      ) : tab === 'campaigns' ? (
        <Card className="text-center py-12">
          <Mail size={32} className="mx-auto mb-3" style={{ color: 'var(--color-text-secondary)' }} />
          <p style={{ color: 'var(--color-text-secondary)' }}>{isAr ? 'لا توجد حملات بريدية' : 'No email campaigns yet'}</p>
          <p className="text-xs mt-1" style={{ color: 'var(--color-text-secondary)' }}>{isAr ? 'سيتم إضافة الحملات قريباً' : 'Campaigns feature coming soon'}</p>
        </Card>
      ) : (
        <Card className="p-0 overflow-hidden">
          {messages.length === 0 ? (
            <div className="text-center py-12">
              <Inbox size={32} className="mx-auto mb-3" style={{ color: 'var(--color-text-secondary)' }} />
              <p style={{ color: 'var(--color-text-secondary)' }}>{isAr ? 'لا توجد رسائل' : 'No messages'}</p>
            </div>
          ) : (
            <div className="divide-y" style={{ borderColor: 'var(--color-border)' }}>
              {messages.map((msg) => (
                <div key={msg.id} className="flex items-center gap-3 p-4 cursor-pointer hover:bg-opacity-80 transition" style={{ borderBottom: '1px solid var(--color-border)' }} onClick={() => setViewMsg(msg)}>
                  <div className="w-2 h-2 rounded-full" style={{ background: msg.is_read ? 'transparent' : 'var(--color-primary)' }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: 'var(--color-text)' }}>{msg.subject || '(no subject)'}</p>
                    <p className="text-xs truncate" style={{ color: 'var(--color-text-secondary)' }}>{tab === 'inbox' ? msg.to_address : `To: ${msg.to_address}`}</p>
                  </div>
                  <Badge color={msg.status === 'sent' ? 'success' : msg.status === 'failed' ? 'danger' : 'warning'}>{msg.status}</Badge>
                  <span className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>{new Date(msg.created_at).toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {/* Compose Modal */}
      <Modal open={composeOpen} onClose={() => setComposeOpen(false)} title={isAr ? 'بريد جديد' : 'Compose Email'} size="lg">
        <div className="space-y-4">
          <div>
            <label className="label">{isAr ? 'القالب' : 'Template'}</label>
            <select className="input" value={compose.template_id} onChange={(e) => {
              const tpl = templates.find((t) => t.id === e.target.value);
              setCompose({ ...compose, template_id: e.target.value, subject: tpl?.subject || compose.subject, body: tpl?.body || compose.body });
            }}>
              <option value="">{isAr ? 'بدون قالب' : 'No template'}</option>
              {templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <Input label={isAr ? 'إلى' : 'To'} value={compose.to} onChange={(e) => setCompose({ ...compose, to: e.target.value })} placeholder="recipient@example.com" />
          <Input label={isAr ? 'الموضوع' : 'Subject'} value={compose.subject} onChange={(e) => setCompose({ ...compose, subject: e.target.value })} />
          <Textarea label={isAr ? 'المحتوى' : 'Body'} rows={8} value={compose.body} onChange={(e) => setCompose({ ...compose, body: e.target.value })} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setComposeOpen(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
            <Button icon={Send} onClick={sendEmail}>{isAr ? 'إرسال' : 'Send'}</Button>
          </div>
        </div>
      </Modal>

      {/* Template Modal */}
      <Modal open={templateModal} onClose={() => setTemplateModal(false)} title={editTemplate ? (isAr ? 'تعديل قالب' : 'Edit Template') : (isAr ? 'قالب جديد' : 'New Template')} size="lg">
        <div className="space-y-4">
          <Input label={isAr ? 'اسم القالب' : 'Template Name'} value={tplForm.name} onChange={(e) => setTplForm({ ...tplForm, name: e.target.value })} />
          <Input label={isAr ? 'الموضوع' : 'Subject'} value={tplForm.subject} onChange={(e) => setTplForm({ ...tplForm, subject: e.target.value })} />
          <Select label={isAr ? 'الفئة' : 'Category'} value={tplForm.category} onChange={(e) => setTplForm({ ...tplForm, category: e.target.value })}>
            <option value="general">General</option>
            <option value="welcome">Welcome</option>
            <option value="password_reset">Password Reset</option>
            <option value="membership_renewal">Membership Renewal</option>
            <option value="invoice">Invoice</option>
            <option value="appointment">Appointment Reminder</option>
            <option value="birthday">Birthday</option>
          </Select>
          <Textarea label={isAr ? 'المحتوى' : 'Body'} rows={8} value={tplForm.body} onChange={(e) => setTplForm({ ...tplForm, body: e.target.value })} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setTemplateModal(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
            <Button onClick={saveTemplate}>{isAr ? 'حفظ' : 'Save'}</Button>
          </div>
        </div>
      </Modal>

      {/* Account Modal */}
      <Modal open={accountModal} onClose={() => setAccountModal(false)} title={isAr ? 'إضافة حساب SMTP' : 'Add SMTP Account'} size="md">
        <div className="grid grid-cols-2 gap-4">
          <Input label={isAr ? 'الاسم' : 'Name'} value={accForm.name} onChange={(e) => setAccForm({ ...accForm, name: e.target.value })} />
          <Input label={isAr ? 'البريد' : 'Email'} value={accForm.email_address} onChange={(e) => setAccForm({ ...accForm, email_address: e.target.value })} />
          <Select label={isAr ? 'المزود' : 'Provider'} value={accForm.provider} onChange={(e) => setAccForm({ ...accForm, provider: e.target.value })}>
            <option value="smtp">Custom SMTP</option>
            <option value="gmail">Gmail</option>
            <option value="outlook">Outlook</option>
          </Select>
          <Input label={isAr ? 'مضيف SMTP' : 'SMTP Host'} value={accForm.smtp_host} onChange={(e) => setAccForm({ ...accForm, smtp_host: e.target.value })} />
          <Input label={isAr ? 'منفذ' : 'Port'} value={accForm.smtp_port} onChange={(e) => setAccForm({ ...accForm, smtp_port: e.target.value })} />
          <Input label={isAr ? 'اسم المستخدم' : 'Username'} value={accForm.smtp_username} onChange={(e) => setAccForm({ ...accForm, smtp_username: e.target.value })} />
          <div className="col-span-2"><Input label={isAr ? 'كلمة المرور' : 'Password'} type="password" value={accForm.smtp_password_encrypted} onChange={(e) => setAccForm({ ...accForm, smtp_password_encrypted: e.target.value })} /></div>
          <div className="flex justify-end gap-3 col-span-2 mt-2">
            <Button variant="secondary" onClick={() => setAccountModal(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
            <Button onClick={saveAccount}>{isAr ? 'حفظ' : 'Save'}</Button>
          </div>
        </div>
      </Modal>

      {/* View Modal */}
      <Modal open={!!viewMsg} onClose={() => setViewMsg(null)} title={viewMsg?.subject || viewMsg?.name || 'Details'} size="md">
        {viewMsg && (
          <div className="space-y-3">
            {viewMsg.to_address && <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>To: {viewMsg.to_address}</p>}
            <div className="p-4 rounded-lg" style={{ background: 'var(--color-bg-surface)' }}>
              <p className="text-sm whitespace-pre-wrap" style={{ color: 'var(--color-text)' }}>{viewMsg.body || viewMsg.message}</p>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
