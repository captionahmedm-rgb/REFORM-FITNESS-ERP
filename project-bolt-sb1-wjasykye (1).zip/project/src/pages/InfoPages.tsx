import { useState, useEffect } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../contexts/ToastContext';
import { supabase } from '../lib/supabase';
import { Card, PageHeader } from '../components/ui';
import {
  Dumbbell, Phone, Mail, MapPin, MessageCircle, Facebook, Youtube, Instagram,
  Send, Clock, Headphones, Users
} from 'lucide-react';

export function AboutPage() {
  const { language } = useTheme();
  const isAr = language === 'ar';

  const services = [
    { en: 'Nutritional Supplements', ar: 'المكملات الغذائية', icon: '💊' },
    { en: 'Fitness Coaching',         ar: 'التدريب الرياضي',    icon: '🏋️' },
    { en: 'Online Coaching',          ar: 'الكوتشينج أونلاين',  icon: '💻' },
    { en: 'Body Transformation',      ar: 'تحويل الجسم',        icon: '💪' },
  ];

  return (
    <div>
      <PageHeader title={isAr ? 'عن الشركة' : 'About Company'} />

      <div className="rf-card stat-card p-8 mb-6 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-5"
          style={{ backgroundImage:`url("https://images.pexels.com/photos/1552249/pexels-photo-1552249.jpeg?auto=compress&cs=tinysrgb&w=800")`, backgroundSize:'cover', backgroundPosition:'center' }} />
        <div className="relative z-10">
          <div className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4 animate-float"
            style={{ background:'linear-gradient(135deg,#0099BB,#00D4FF)', boxShadow:'0 0 40px rgba(0,212,255,0.5)' }}>
            <Dumbbell size={36} style={{ color:'#050A14' }} />
          </div>
          <h1 className="logo-text text-4xl mb-1">REFORM FITNESS</h1>
          <p className="text-sm mb-6" style={{ color:'var(--color-text-secondary)' }}>
            {isAr ? 'نظام إدارة اللياقة المتكامل' : 'Enterprise Fitness Management System'}
          </p>
          <div className="neon-divider w-48 mx-auto" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <Card>
          <h2 className="font-bold text-sm mb-4" style={{ color:'var(--color-text)' }}>{isAr?'معلومات الشركة':'Company Information'}</h2>
          {[
            [isAr?'الشركة':'Company',   'REFORM FITNESS'],
            [isAr?'المالك':'Owner',     'Captain Ahmed Mohamed'],
            [isAr?'الهاتف':'Phone 1',  '01550098212'],
            [isAr?'الهاتف 2':'Phone 2','01551510427'],
            [isAr?'البريد':'Email',     'captionahmedm@gmail.com'],
            [isAr?'الموقع':'Location',  isAr?'القاهرة، مصر':'Cairo, Egypt'],
          ].map(([l,v]) => (
            <div key={l as string} className="flex justify-between py-2" style={{ borderBottom:'1px solid var(--color-border)' }}>
              <span className="text-xs" style={{ color:'var(--color-text-muted)' }}>{l}</span>
              <span className="text-xs font-semibold" style={{ color:'var(--color-text)' }}>{v}</span>
            </div>
          ))}
        </Card>
        <Card>
          <h2 className="font-bold text-sm mb-4" style={{ color:'var(--color-text)' }}>{isAr?'الخدمات':'Services'}</h2>
          <div className="grid grid-cols-2 gap-3">
            {services.map((s,i) => (
              <div key={i} className="p-3 rounded-xl text-center" style={{ background:'rgba(0,212,255,0.06)', border:'1px solid rgba(0,212,255,0.15)' }}>
                <div className="text-2xl mb-2">{s.icon}</div>
                <p className="text-xs font-semibold" style={{ color:'var(--color-text)' }}>{isAr?s.ar:s.en}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <h2 className="font-bold text-sm mb-3" style={{ color:'var(--color-text)' }}>{isAr?'رؤيتنا':'Our Vision'}</h2>
        <p className="text-sm leading-relaxed" style={{ color:'var(--color-text-secondary)' }}>
          {isAr
            ? 'REFORM FITNESS منصة إدارة متكاملة للياقة البدنية والمكملات الغذائية، تهدف إلى تقديم تجربة احترافية لإدارة المراكز الرياضية، الموظفين، العملاء والمخزون. مبنية على أحدث التقنيات مع دعم كامل للغة العربية.'
            : 'REFORM FITNESS is a comprehensive fitness and supplement management platform designed to deliver a professional experience for managing sports centers, employees, customers, and inventory — built with full Arabic RTL support.'}
        </p>
      </Card>
    </div>
  );
}

export function ContactPage() {
  const { language } = useTheme();
  const { toast }    = useToast();
  const isAr = language === 'ar';
  const [form, setForm] = useState({ name:'', email:'', phone:'', type:'general', message:'' });
  const [settings, setSettings] = useState<Record<string,string>>({});

  useEffect(() => {
    const loadSettings = async () => {
      try {
        const { data } = await supabase.from('social_media_settings').select('key, value');
        const map: Record<string,string> = {};
        (data||[]).forEach((r:any) => { map[r.key] = r.value||''; });
        setSettings(map);
      } catch (e) {
        console.error('Failed to load settings');
      }
    };
    loadSettings();
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    toast(isAr ? 'تم إرسال رسالتك ✓' : 'Message sent ✓', 'success');
    setForm({ name:'', email:'', phone:'', type:'general', message:'' });
  };

  const contactMethods = [
    {
      title: isAr?'اتصل الآن':'Call Now',
      icon: Phone,
      color: '#00D4FF',
      bgColor: 'rgba(0,212,255,0.1)',
      items: [
        { label: 'Phone 1', value: settings.phone_1 || '01550098212', href: `tel:${settings.phone_1 || '01550098212'}` },
        { label: 'Phone 2', value: settings.phone_2 || '01551510427', href: `tel:${settings.phone_2 || '01551510427'}` },
      ]
    },
    {
      title: 'WhatsApp',
      icon: MessageCircle,
      color: '#25D366',
      bgColor: 'rgba(37,211,102,0.1)',
      items: [
        { label: 'WhatsApp 1', value: settings.whatsapp_1 || '01550098212', href: `https://wa.me/201550098212` },
        { label: 'WhatsApp 2', value: settings.whatsapp_2 || '01551510427', href: `https://wa.me/201551510427` },
      ]
    },
    {
      title: isAr?'البريد الإلكتروني':'Email',
      icon: Mail,
      color: '#F59E0B',
      bgColor: 'rgba(245,158,11,0.1)',
      items: [
        { label: isAr?'البريد الرئيسي':'Main Email', value: settings.email_main || 'captionahmedm@gmail.com', href: `mailto:${settings.email_main || 'captionahmedm@gmail.com'}` },
        { label: isAr?'بريد المتجر':'Store Email', value: settings.email_store || 'captainahmedstoreynutritionals@gmail.com', href: `mailto:${settings.email_store || 'captainahmedstoreynutritionals@gmail.com'}` },
      ]
    },
  ];

  const socialMedia = [
    { icon: Facebook, color: '#1877F2', label: 'Facebook', href: settings.facebook_url || '#' },
    { icon: Instagram, color: '#E1306C', label: 'Instagram', href: settings.instagram_url || '#' },
    { icon: Youtube, color: '#FF0000', label: 'YouTube', href: settings.youtube_url || '#' },
  ];

  const requestTypes = [
    { value: 'general', label: isAr?'استفسار عام':'General Inquiry' },
    { value: 'support', label: isAr?'دعم فني':'Technical Support' },
    { value: 'complaint', label: isAr?'شكوى':'Complaint' },
    { value: 'employee', label: isAr?'بوابة موظف':'Employee Portal' },
    { value: 'sales', label: isAr?'استعلام مبيعات':'Sales Inquiry' },
    { value: 'partnership', label: isAr?'شراكة تجارية':'Business Partnership' },
  ];

  return (
    <div>
      <PageHeader title={isAr?'مركز خدمة العملاء':'Customer Service Center'}
        subtitle={isAr?'نحن هنا لمساعدتك على مدار الساعة':'We\'re here to help 24/7'} />

      {/* Quick contact buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {contactMethods.map((method, i) => {
          const Icon = method.icon;
          return (
            <Card key={i} className="p-5" glow>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: method.bgColor }}>
                  <Icon size={24} style={{ color: method.color }} />
                </div>
                <h3 className="font-bold" style={{ color: method.color }}>{method.title}</h3>
              </div>
              <div className="space-y-3">
                {method.items.map((item, j) => (
                  <a key={j} href={item.href}
                    target={item.href.startsWith('http') ? '_blank' : undefined}
                    rel="noopener noreferrer"
                    className="flex items-center justify-between p-3 rounded-xl transition hover:scale-[1.02]"
                    style={{ background: 'var(--color-bg-surface)', textDecoration: 'none' }}>
                    <div>
                      <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{item.label}</p>
                      <p className="text-sm font-semibold" style={{ color: method.color }}>{item.value}</p>
                    </div>
                    <Icon size={16} style={{ color: method.color }} />
                  </a>
                ))}
              </div>
            </Card>
          );
        })}
      </div>

      {/* Working hours & location */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(34,197,94,0.12)' }}>
              <Clock size={20} style={{ color: '#22C55E' }} />
            </div>
            <h3 className="font-bold" style={{ color: 'var(--color-text)' }}>
              {isAr?'ساعات العمل':'Working Hours'}
            </h3>
          </div>
          <div className="space-y-2">
            {[
              { day: isAr?'السبت - الخميس':'Saturday - Thursday', hours: '9:00 AM - 9:00 PM' },
              { day: isAr?'الجمعة':'Friday', hours: '2:00 PM - 8:00 PM' },
              { day: isAr?'دعم الطوارئ':'Emergency Support', hours: '24/7' },
            ].map((s, i) => (
              <div key={i} className="flex justify-between items-center py-2 px-3 rounded-lg"
                style={{ background: 'var(--color-bg-surface)' }}>
                <span className="text-sm" style={{ color: 'var(--color-text)' }}>{s.day}</span>
                <span className="text-sm font-semibold" style={{ color: 'var(--neon)' }}>{s.hours}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(239,68,68,0.12)' }}>
              <MapPin size={20} style={{ color: '#EF4444' }} />
            </div>
            <h3 className="font-bold" style={{ color: 'var(--color-text)' }}>
              {isAr?'العنوان':'Address'}
            </h3>
          </div>
          <div className="p-4 rounded-xl" style={{ background: 'var(--color-bg-surface)' }}>
            <p className="text-sm font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
              REFORM FITNESS
            </p>
            <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
              {isAr?'القاهرة، مصر':'Cairo, Egypt'}
            </p>
            <p className="text-xs mt-2" style={{ color: 'var(--color-text-muted)' }}>
              {isAr?'للاستفسارات والزيارات':'For inquiries and visits'}
            </p>
          </div>
        </Card>
      </div>

      {/* Social media & contact form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Social Media */}
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(167,139,250,0.12)' }}>
              <Users size={20} style={{ color: '#A78BFA' }} />
            </div>
            <h3 className="font-bold" style={{ color: 'var(--color-text)' }}>
              {isAr?'تابعنا على':'Follow Us'}
            </h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {socialMedia.map((s, i) => {
              const Icon = s.icon;
              return (
                <a key={i} href={s.href} target="_blank" rel="noopener noreferrer"
                  className="flex flex-col items-center gap-2 p-4 rounded-xl transition hover:scale-105"
                  style={{ background: `${s.color}12`, border: `1px solid ${s.color}25`, textDecoration: 'none' }}>
                  <Icon size={28} style={{ color: s.color }} />
                  <span className="text-xs font-semibold" style={{ color: s.color }}>{s.label}</span>
                </a>
              );
            })}
          </div>

          {/* Quick actions */}
          <div className="mt-6 pt-4" style={{ borderTop: '1px solid var(--color-border)' }}>
            <h4 className="font-bold text-sm mb-3" style={{ color: 'var(--color-text)' }}>
              {isAr?'إجراءات سريعة':'Quick Actions'}
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <a href="https://wa.me/201550098212" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 p-3 rounded-xl transition"
                style={{ background: '#25D36612', textDecoration: 'none' }}>
                <MessageCircle size={18} style={{ color: '#25D366' }} />
                <span className="text-sm font-semibold" style={{ color: '#25D366' }}>
                  {isAr?'راسلنا على واتساب':'WhatsApp Us'}
                </span>
              </a>
              <a href="tel:01550098212"
                className="flex items-center gap-2 p-3 rounded-xl transition"
                style={{ background: '#00D4FF12', textDecoration: 'none' }}>
                <Phone size={18} style={{ color: '#00D4FF' }} />
                <span className="text-sm font-semibold" style={{ color: '#00D4FF' }}>
                  {isAr?'اتصل الآن':'Call Now'}
                </span>
              </a>
              <a href="mailto:captionahmedm@gmail.com"
                className="flex items-center gap-2 p-3 rounded-xl transition"
                style={{ background: '#F59E0B12', textDecoration: 'none' }}>
                <Mail size={18} style={{ color: '#F59E0B' }} />
                <span className="text-sm font-semibold" style={{ color: '#F59E0B' }}>
                  {isAr?'أرسل بريد':'Send Email'}
                </span>
              </a>
              <a href="#" onClick={() => toast(isAr?'سيتم فتح الخريطة قريباً':'Map coming soon', 'info')}
                className="flex items-center gap-2 p-3 rounded-xl transition"
                style={{ background: '#EF444412', textDecoration: 'none' }}>
                <MapPin size={18} style={{ color: '#EF4444' }} />
                <span className="text-sm font-semibold" style={{ color: '#EF4444' }}>
                  {isAr?'الموقع':'Location'}
                </span>
              </a>
            </div>
          </div>
        </Card>

        {/* Contact Form */}
        <Card>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(0,212,255,0.12)' }}>
              <Send size={20} style={{ color: '#00D4FF' }} />
            </div>
            <h3 className="font-bold" style={{ color: 'var(--color-text)' }}>
              {isAr?'أرسل رسالة':'Send a Message'}
            </h3>
          </div>
          <form onSubmit={submit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">{isAr?'الاسم':'Name'}</label>
                <input className="input" required value={form.name}
                  onChange={e=>setForm({...form,name:e.target.value})}
                  placeholder={isAr?'الاسم الكامل':'Full name'} />
              </div>
              <div>
                <label className="label">{isAr?'الهاتف':'Phone'}</label>
                <input className="input" value={form.phone}
                  onChange={e=>setForm({...form,phone:e.target.value})}
                  placeholder="+20" />
              </div>
            </div>
            <div>
              <label className="label">{isAr?'البريد الإلكتروني':'Email'}</label>
              <input type="email" className="input" value={form.email}
                onChange={e=>setForm({...form,email:e.target.value})}
                placeholder="email@example.com" />
            </div>
            <div>
              <label className="label">{isAr?'نوع الطلب':'Request Type'}</label>
              <select className="input" value={form.type}
                onChange={e=>setForm({...form,type:e.target.value})}>
                {requestTypes.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">{isAr?'الرسالة':'Message'}</label>
              <textarea className="input" rows={4} required value={form.message}
                onChange={e=>setForm({...form,message:e.target.value})}
                placeholder={isAr?'اكتب رسالتك هنا...':'Write your message here...'} />
            </div>
            <button type="submit"
              className="w-full py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition"
              style={{ background: 'linear-gradient(135deg, #0099BB, #00D4FF)', color: '#050A14' }}>
              <Send size={18} />
              {isAr?'إرسال الرسالة':'Send Message'}
            </button>
          </form>
        </Card>
      </div>

      {/* Support info */}
      <Card className="mt-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(245,158,11,0.12)' }}>
            <Headphones size={24} style={{ color: '#F59E0B' }} />
          </div>
          <div>
            <h3 className="font-bold mb-2" style={{ color: 'var(--color-text)' }}>
              {isAr?' Need Help?':'Need Help?'}
            </h3>
            <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
              {isAr
                ? 'فريق خدمة العملاء لدينا متاح على مدار الساعة لمساعدتك. يمكنك التواصل معنا عبر الهاتف، الواتساب، أو البريد الإلكتروني.'
                : 'Our customer service team is available 24/7 to help you. You can reach us via phone, WhatsApp, or email.'}
            </p>
            <div className="flex gap-4 mt-4">
              <a href="tel:01550098212" className="text-sm font-semibold" style={{ color: 'var(--neon)' }}>
                📞 01550098212
              </a>
              <a href="tel:01551510427" className="text-sm font-semibold" style={{ color: 'var(--neon)' }}>
                📞 01551510427
              </a>
              <a href="mailto:captionahmedm@gmail.com" className="text-sm font-semibold" style={{ color: 'var(--neon)' }}>
                ✉️ captionahmedm@gmail.com
              </a>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
