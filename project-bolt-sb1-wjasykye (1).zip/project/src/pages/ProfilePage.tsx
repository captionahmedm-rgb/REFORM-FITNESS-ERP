import { useState, useEffect, useRef, ChangeEvent } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { Button, Input, Select, Textarea, Card, PageHeader, Badge } from '../components/ui';
import { supabase } from '../lib/supabase';
import { Camera, Lock, Shield, Bell, User, Save, Eye, EyeOff, CheckCircle, Upload, X, Loader2 } from 'lucide-react';

type Tab = 'profile' | 'password' | 'security' | 'notifications';

const DEPTS = ['Management','Training','Nutrition','Sales','Warehouse','Accounting','Customer Service','IT','Reception','Operations'];
const GOVS  = ['Cairo','Giza','Alexandria','Dakahlia','Red Sea','Beheira','Fayoum','Gharbiya','Ismailia','Menofia','Minya','Qaliubiya','New Valley','Suez','Aswan','Assiut','Beni Suef','Port Said','Damietta','Sharqia','South Sinai','Kafr El Sheikh','Matrouh','Luxor','Qena','North Sinai','Sohag'];

export function ProfilePage() {
  const { profile, roles, updateProfile, changePassword, refreshProfile } = useAuth();
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [tab, setTab] = useState<Tab>('profile');

  /* ── Profile form ── */
  const [pForm, setPForm] = useState({
    full_name: '', phone: '', whatsapp_number: '', email: '',
    job_title: '', department_name: '', governorate: '', city: '', address: '',
    personal_email: '', avatar_url: '', national_id: '', date_of_birth: '',
    gender: 'male', marital_status: 'single', nationality: 'Egyptian', notes: '',
  });
  const [pSaving, setPSaving] = useState(false);

  /* ── Profile picture upload ── */
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  /* ── Password form ── */
  const [pwForm, setPwForm] = useState({ current: '', next: '', confirm: '' });
  const [showCur, setShowCur] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [pwSaving, setPwSaving] = useState(false);

  // Handle file selection
  const handleFileSelect = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast(isAr ? 'يرجى اختيار ملف صورة' : 'Please select an image file', 'error');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast(isAr ? 'حجم الصورة يجب أن يكون أقل من 5 ميجابايت' : 'Image size must be less than 5MB', 'error');
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (ev) => {
      setPreviewUrl(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Upload to Supabase Storage
  const uploadProfilePicture = async () => {
    const file = fileInputRef.current?.files?.[0];
    if (!file || !profile) return;

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${profile.auth_id}/${Date.now()}.${fileExt}`;

      // Try to upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, file, { upsert: true });

      let avatarUrl: string;
      if (uploadError) {
        // Fallback: use base64 data URL
        const reader = new FileReader();
        avatarUrl = await new Promise<string>((resolve) => {
          reader.onload = (ev) => resolve(ev.target?.result as string);
          reader.readAsDataURL(file);
        });
      } else {
        const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(fileName);
        avatarUrl = urlData.publicUrl;
      }

      // Update profile with new avatar URL
      const { error: updateError } = await updateProfile({ avatar_url: avatarUrl } as any);
      if (updateError) throw updateError;

      setPForm(p => ({ ...p, avatar_url: avatarUrl }));
      setPreviewUrl(null);
      toast(isAr ? 'تم رفع الصورة الشخصية ✓' : 'Profile picture uploaded ✓', 'success');
      await refreshProfile();
    } catch (err: any) {
      toast(err.message || 'Upload failed', 'error');
    }
    setUploading(false);
  };

  // Delete profile picture
  const deleteProfilePicture = async () => {
    if (!pForm.avatar_url || !profile) return;

    setUploading(true);
    try {
      await updateProfile({ avatar_url: null } as any);
      setPForm(p => ({ ...p, avatar_url: '' }));
      setPreviewUrl(null);
      toast(isAr ? 'تم حذف الصورة الشخصية' : 'Profile picture deleted', 'success');
      await refreshProfile();
    } catch (err: any) {
      toast(err.message, 'error');
    }
    setUploading(false);
  };

  // Populate form from profile
  useEffect(() => {
    if (!profile) return;
    const p = profile as any;
    setPForm({
      full_name:        p.full_name        || '',
      phone:            p.phone            || '',
      whatsapp_number:  p.whatsapp_number  || '',
      email:            p.email            || '',
      job_title:        p.job_title        || '',
      department_name:  p.department_name  || '',
      governorate:      p.governorate      || '',
      city:             p.city             || '',
      address:          p.address          || '',
      personal_email:   p.personal_email   || '',
      avatar_url:       p.avatar_url       || '',
      national_id:      p.national_id      || '',
      date_of_birth:    p.date_of_birth    || '',
      gender:           p.gender           || 'male',
      marital_status:   p.marital_status   || 'single',
      nationality:      p.nationality      || 'Egyptian',
      notes:            p.notes            || '',
    });
  }, [profile]);

  const saveProfile = async () => {
    if (!pForm.full_name.trim()) { toast(isAr ? 'الاسم مطلوب' : 'Name is required', 'warning'); return; }
    setPSaving(true);
    const { error } = await updateProfile({
      full_name:       pForm.full_name.trim(),
      phone:           pForm.phone || undefined,
      whatsapp_number: pForm.whatsapp_number || undefined,
      job_title:       pForm.job_title || undefined,
      department_name: pForm.department_name || undefined,
      governorate:     pForm.governorate || undefined,
      city:            pForm.city || undefined,
      address:         pForm.address || undefined,
      personal_email:  pForm.personal_email || undefined,
      avatar_url:      pForm.avatar_url || undefined,
      national_id:     pForm.national_id || undefined,
      date_of_birth:   pForm.date_of_birth || undefined,
      gender:          pForm.gender || undefined,
      marital_status:  pForm.marital_status || undefined,
      nationality:     pForm.nationality || undefined,
      notes:           pForm.notes || undefined,
    } as any);
    if (error) toast(error, 'error');
    else {
      toast(isAr ? 'تم حفظ الملف الشخصي ✓' : 'Profile saved ✓', 'success');
      await refreshProfile();
    }
    setPSaving(false);
  };

  const savePassword = async () => {
    if (!pwForm.current) { toast(isAr ? 'أدخل كلمة المرور الحالية' : 'Enter current password', 'warning'); return; }
    if (pwForm.next.length < 6) { toast(isAr ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' : 'Password must be at least 6 characters', 'warning'); return; }
    if (pwForm.next !== pwForm.confirm) { toast(isAr ? 'كلمتا المرور غير متطابقتين' : 'Passwords do not match', 'error'); return; }
    setPwSaving(true);
    const { error } = await changePassword(pwForm.current, pwForm.next);
    if (error) toast(error, 'error');
    else {
      toast(isAr ? 'تم تغيير كلمة المرور ✓' : 'Password changed ✓', 'success');
      setPwForm({ current: '', next: '', confirm: '' });
    }
    setPwSaving(false);
  };

  if (!profile) return (
    <div className="flex items-center justify-center h-64">
      <p style={{ color: 'var(--color-text-muted)' }}>{isAr ? 'جاري التحميل...' : 'Loading profile...'}</p>
    </div>
  );

  const TABS: { id: Tab; icon: any; en: string; ar: string }[] = [
    { id: 'profile',       icon: User,   en: 'My Profile',    ar: 'ملفي الشخصي' },
    { id: 'password',      icon: Lock,   en: 'Change Password',ar: 'تغيير كلمة المرور' },
    { id: 'security',      icon: Shield, en: 'Security',       ar: 'الأمان' },
    { id: 'notifications', icon: Bell,   en: 'Notifications',  ar: 'الإشعارات' },
  ];

  return (
    <div>
      <PageHeader title={isAr ? 'الملف الشخصي' : 'My Profile'} subtitle={isAr ? 'إدارة معلوماتك الشخصية' : 'Manage your personal information'} />

      {/* Profile hero */}
      <div className="rf-card stat-card p-6 mb-6 overflow-hidden relative">
        <div className="flex items-center gap-5 flex-wrap">
          {/* Avatar */}
          <div className="relative">
            <div className="avatar w-24 h-24" style={{ border: '3px solid var(--neon)', boxShadow: '0 0 24px rgba(0,212,255,0.4)' }}>
              {(previewUrl || pForm.avatar_url)
                ? <img src={previewUrl || pForm.avatar_url} alt={pForm.full_name} onError={e => { (e.target as any).style.display = 'none'; }} />
                : <span className="text-3xl font-bold" style={{ color: 'var(--neon)' }}>{profile.full_name?.charAt(0)?.toUpperCase()}</span>
              }
            </div>
            {(previewUrl || pForm.avatar_url) && (
              <button
                onClick={deleteProfilePicture}
                disabled={uploading}
                className="absolute -top-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center transition"
                style={{ background: 'var(--color-danger)', color: 'white' }}
              >
                <X size={12} />
              </button>
            )}
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-extrabold" style={{ color: 'var(--color-text)' }}>{profile.full_name}</h2>
            <p className="text-sm mt-0.5" style={{ color: 'var(--neon)' }}>{(profile as any).job_title || (isAr ? 'لم يحدد' : 'Not set')}</p>
            <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{profile.email}</p>
            <div className="flex gap-2 mt-2 flex-wrap">
              {roles.map(r => <Badge key={r.id} color="primary">{r.display_name}</Badge>)}
              <Badge color={(profile as any).status === 'active' ? 'success' : 'default'}>{(profile as any).status}</Badge>
            </div>
          </div>
          <div className="text-end">
            <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{isAr ? 'رقم الموظف' : 'Employee ID'}</p>
            <p className="font-mono font-bold" style={{ color: 'var(--neon)' }}>{(profile as any).employee_id || '—'}</p>
            {profile.last_login && (
              <>
                <p className="text-xs mt-2" style={{ color: 'var(--color-text-muted)' }}>{isAr ? 'آخر دخول' : 'Last login'}</p>
                <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>{new Date(profile.last_login).toLocaleString()}</p>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Tabs sidebar */}
        <div className="lg:w-52 flex-shrink-0">
          <div className="rf-card p-2 space-y-1">
            {TABS.map(t => {
              const Icon = t.icon;
              return (
                <button key={t.id} onClick={() => setTab(t.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition nav-item ${tab === t.id ? 'nav-active' : ''}`}
                  style={{ color: tab === t.id ? 'var(--neon)' : 'var(--color-text-secondary)' }}>
                  <Icon size={16} /><span>{isAr ? t.ar : t.en}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1">
          {/* ── Profile tab ── */}
          {tab === 'profile' && (
            <Card>
              <h3 className="font-bold mb-5" style={{ color: 'var(--color-text)' }}>{isAr ? 'تعديل الملف الشخصي' : 'Edit Profile'}</h3>

              {/* Photo Upload */}
              <div className="flex items-center gap-4 p-4 rounded-xl mb-5" style={{ background: 'var(--color-bg-surface)', border: '1px solid var(--color-border)' }}>
                <div className="avatar w-16 h-16 relative" style={{ border: '2px solid var(--neon)' }}>
                  {(previewUrl || pForm.avatar_url)
                    ? <img src={previewUrl || pForm.avatar_url} alt="preview" onError={e => { (e.target as any).style.display = 'none'; }} />
                    : <Camera size={22} style={{ color: 'var(--neon)' }} />
                  }
                </div>
                <div className="flex-1">
                  <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text)' }}>{isAr ? 'الصورة الشخصية' : 'Profile Picture'}</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <div className="flex gap-2 flex-wrap">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploading}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition"
                      style={{ background: 'var(--color-border)', color: 'var(--color-text-secondary)' }}
                    >
                      <Upload size={14} />
                      {isAr ? 'اختر صورة' : 'Choose Image'}
                    </button>
                    {previewUrl && previewUrl !== pForm.avatar_url && (
                      <button
                        onClick={uploadProfilePicture}
                        disabled={uploading}
                        className="px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition"
                        style={{ background: 'linear-gradient(135deg, #0099BB, #00D4FF)', color: '#050A14' }}>
                        {uploading ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />}
                        {isAr ? 'حفظ الصورة' : 'Save Photo'}
                      </button>
                    )}
                  </div>
                  <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>
                    {isAr ? 'PNG, JPG بحد أقصى 5MB' : 'PNG, JPG up to 5MB'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label={isAr ? 'الاسم الكامل *' : 'Full Name *'} value={pForm.full_name}
                  onChange={e => setPForm(p => ({ ...p, full_name: e.target.value }))} />
                <Input label={isAr ? 'المسمى الوظيفي' : 'Job Title'} value={pForm.job_title}
                  onChange={e => setPForm(p => ({ ...p, job_title: e.target.value }))} />
                <Input label={isAr ? 'رقم الهاتف' : 'Phone'} value={pForm.phone}
                  onChange={e => setPForm(p => ({ ...p, phone: e.target.value }))} />
                <Input label={isAr ? 'واتساب' : 'WhatsApp'} value={pForm.whatsapp_number}
                  onChange={e => setPForm(p => ({ ...p, whatsapp_number: e.target.value }))} />
                <Input label={isAr ? 'البريد الشخصي' : 'Personal Email'} type="email" value={pForm.personal_email}
                  onChange={e => setPForm(p => ({ ...p, personal_email: e.target.value }))} />
                <Select label={isAr ? 'القسم' : 'Department'} value={pForm.department_name}
                  onChange={e => setPForm(p => ({ ...p, department_name: e.target.value }))}>
                  <option value="">—</option>
                  {DEPTS.map(d => <option key={d} value={d}>{d}</option>)}
                </Select>
                <Select label={isAr ? 'الجنس' : 'Gender'} value={pForm.gender}
                  onChange={e => setPForm(p => ({ ...p, gender: e.target.value }))}>
                  <option value="male">{isAr ? 'ذكر' : 'Male'}</option>
                  <option value="female">{isAr ? 'أنثى' : 'Female'}</option>
                  <option value="other">{isAr ? 'آخر' : 'Other'}</option>
                </Select>
                <Input label={isAr ? 'تاريخ الميلاد' : 'Date of Birth'} type="date" value={pForm.date_of_birth}
                  onChange={e => setPForm(p => ({ ...p, date_of_birth: e.target.value }))} />
                <Input label={isAr ? 'الرقم القومي' : 'National ID'} value={pForm.national_id}
                  onChange={e => setPForm(p => ({ ...p, national_id: e.target.value }))} maxLength={14} />
                <Select label={isAr ? 'المحافظة' : 'Governorate'} value={pForm.governorate}
                  onChange={e => setPForm(p => ({ ...p, governorate: e.target.value }))}>
                  <option value="">—</option>
                  {GOVS.map(g => <option key={g} value={g}>{g}</option>)}
                </Select>
                <Input label={isAr ? 'المدينة' : 'City'} value={pForm.city}
                  onChange={e => setPForm(p => ({ ...p, city: e.target.value }))} />
                <Input label={isAr ? 'الجنسية' : 'Nationality'} value={pForm.nationality}
                  onChange={e => setPForm(p => ({ ...p, nationality: e.target.value }))} />
              </div>
              <div className="mt-4">
                <Textarea label={isAr ? 'العنوان الكامل' : 'Full Address'} value={pForm.address} rows={2}
                  onChange={e => setPForm(p => ({ ...p, address: e.target.value }))} />
              </div>
              <div className="mt-4">
                <Textarea label={isAr ? 'ملاحظات' : 'Notes'} value={pForm.notes} rows={2}
                  onChange={e => setPForm(p => ({ ...p, notes: e.target.value }))} />
              </div>
              <div className="flex justify-end mt-5">
                <Button icon={Save} onClick={saveProfile} loading={pSaving}>
                  {isAr ? 'حفظ التغييرات' : 'Save Changes'}
                </Button>
              </div>
            </Card>
          )}

          {/* ── Password tab ── */}
          {tab === 'password' && (
            <Card>
              <h3 className="font-bold mb-5" style={{ color: 'var(--color-text)' }}>{isAr ? 'تغيير كلمة المرور' : 'Change Password'}</h3>
              <div className="space-y-4 max-w-sm">
                <div>
                  <label className="label">{isAr ? 'كلمة المرور الحالية' : 'Current Password'}</label>
                  <div className="relative">
                    <input type={showCur ? 'text' : 'password'} className="input pr-10"
                      value={pwForm.current} onChange={e => setPwForm(p => ({ ...p, current: e.target.value }))}
                      placeholder="••••••••" />
                    <button type="button" onClick={() => setShowCur(!showCur)}
                      className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--color-text-muted)' }}>
                      {showCur ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="label">{isAr ? 'كلمة المرور الجديدة' : 'New Password'}</label>
                  <div className="relative">
                    <input type={showNew ? 'text' : 'password'} className="input pr-10"
                      value={pwForm.next} onChange={e => setPwForm(p => ({ ...p, next: e.target.value }))}
                      placeholder="••••••••" minLength={6} />
                    <button type="button" onClick={() => setShowNew(!showNew)}
                      className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--color-text-muted)' }}>
                      {showNew ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {/* Strength indicator */}
                  {pwForm.next && (
                    <div className="mt-2">
                      <div className="progress-bar"><div className="progress-fill" style={{ width: pwForm.next.length >= 12 ? '100%' : pwForm.next.length >= 8 ? '66%' : '33%' }} /></div>
                      <p className="text-xs mt-1" style={{ color: pwForm.next.length >= 8 ? 'var(--color-success)' : 'var(--color-warning)' }}>
                        {pwForm.next.length >= 12 ? (isAr?'قوية':'Strong') : pwForm.next.length >= 8 ? (isAr?'متوسطة':'Medium') : (isAr?'ضعيفة':'Weak')}
                      </p>
                    </div>
                  )}
                </div>
                <div>
                  <label className="label">{isAr ? 'تأكيد كلمة المرور' : 'Confirm New Password'}</label>
                  <div className="relative">
                    <input type="password" className="input pr-10"
                      value={pwForm.confirm} onChange={e => setPwForm(p => ({ ...p, confirm: e.target.value }))}
                      placeholder="••••••••" />
                    {pwForm.confirm && pwForm.next === pwForm.confirm && (
                      <CheckCircle size={16} className="absolute right-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--color-success)' }} />
                    )}
                  </div>
                </div>
                <Button icon={Lock} onClick={savePassword} loading={pwSaving}>
                  {isAr ? 'تغيير كلمة المرور' : 'Change Password'}
                </Button>
              </div>
            </Card>
          )}

          {/* ── Security tab ── */}
          {tab === 'security' && (
            <Card>
              <h3 className="font-bold mb-5" style={{ color: 'var(--color-text)' }}>{isAr ? 'إعدادات الأمان' : 'Security Settings'}</h3>
              <div className="space-y-3 max-w-md">
                {[
                  { label: isAr?'المصادقة الثنائية (2FA)':'Two-Factor Authentication', checked: false },
                  { label: isAr?'تنبيهات تسجيل الدخول':'Login Alerts', checked: true },
                  { label: isAr?'تسجيل خروج تلقائي بعد عدم النشاط':'Auto Logout on Inactivity', checked: true },
                ].map((s, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-xl" style={{ background: 'var(--color-bg-surface)' }}>
                    <span className="text-sm" style={{ color: 'var(--color-text)' }}>{s.label}</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked={s.checked} className="sr-only peer" />
                      <div className="w-10 h-5 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:start-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"
                        style={{ background: 'var(--color-border)' }}></div>
                    </label>
                  </div>
                ))}
                <div className="p-3 rounded-xl mt-3" style={{ background: 'var(--color-bg-surface)' }}>
                  <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text)' }}>{isAr ? 'معرف المستخدم' : 'User ID'}</p>
                  <p className="text-xs font-mono" style={{ color: 'var(--neon)' }}>{profile.auth_id}</p>
                </div>
                <div className="p-3 rounded-xl" style={{ background: 'var(--color-bg-surface)' }}>
                  <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text)' }}>{isAr ? 'آخر تسجيل دخول' : 'Last Login'}</p>
                  <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>{profile.last_login ? new Date(profile.last_login).toLocaleString() : '—'}</p>
                </div>
              </div>
            </Card>
          )}

          {/* ── Notifications tab ── */}
          {tab === 'notifications' && (
            <Card>
              <h3 className="font-bold mb-5" style={{ color: 'var(--color-text)' }}>{isAr ? 'تفضيلات الإشعارات' : 'Notification Preferences'}</h3>
              <div className="space-y-3 max-w-md">
                {[
                  { label: isAr?'إشعارات البريد الإلكتروني':'Email Notifications', checked: true },
                  { label: isAr?'إشعارات الرسائل القصيرة':'SMS Notifications', checked: false },
                  { label: isAr?'إشعارات الاستحضار (Push)':'Push Notifications', checked: true },
                  { label: isAr?'تنبيهات المبيعات الجديدة':'New Sales Alerts', checked: true },
                  { label: isAr?'تنبيهات الحضور':'Attendance Alerts', checked: false },
                ].map((s, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-xl" style={{ background: 'var(--color-bg-surface)' }}>
                    <span className="text-sm" style={{ color: 'var(--color-text)' }}>{s.label}</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked={s.checked} className="sr-only peer" />
                      <div className="w-10 h-5 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:start-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"
                        style={{ background: 'var(--color-border)' }}></div>
                    </label>
                  </div>
                ))}
                <Button icon={Save} onClick={() => toast(isAr ? 'تم الحفظ ✓' : 'Saved ✓', 'success')}>
                  {isAr ? 'حفظ التفضيلات' : 'Save Preferences'}
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
