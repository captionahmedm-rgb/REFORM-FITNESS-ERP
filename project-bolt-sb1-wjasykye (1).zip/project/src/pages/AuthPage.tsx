import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { Eye, EyeOff, Loader2, Dumbbell, Globe, Moon, Sun, Zap } from 'lucide-react';

/* animated particle dot */
function Particle({ style }: { style: React.CSSProperties }) {
  return <div className="absolute rounded-full bg-neon opacity-20 animate-float" style={style} />;
}

export function AuthPage() {
  const { signIn, signUp } = useAuth();
  const { mode, toggleMode, language, setLanguage } = useTheme();
  const isAr = language === 'ar';

  const [tab, setTab] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [remember, setRemember] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [initLoading, setInitLoading] = useState(true);

  // Animated loading screen
  useEffect(() => {
    const t = setTimeout(() => setInitLoading(false), 1800);
    return () => clearTimeout(t);
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setLoading(true);
    const res = tab === 'signin'
      ? await signIn(email, password)
      : await signUp(email, password, fullName);
    if (res.error) setError(res.error);
    setLoading(false);
  };

  /* ── Loading screen ── */
  if (initLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center"
        style={{ background: 'var(--color-bg)' }}>
        {/* Animated rings */}
        <div className="relative w-28 h-28 flex items-center justify-center mb-8">
          <div className="absolute inset-0 rounded-full border-2 border-neon/20 animate-spin-slow" />
          <div className="absolute inset-3 rounded-full border border-neon/40 animate-spin-slow" style={{ animationDirection: 'reverse', animationDuration: '4s' }} />
          <div className="absolute inset-6 rounded-full border border-neon/60 animate-pulse-neon" />
          <div className="w-12 h-12 rounded-full flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg,#0099BB,#00D4FF)', boxShadow: '0 0 32px rgba(0,212,255,0.5)' }}>
            <Dumbbell size={24} className="text-navy-900" style={{ color: '#050A14' }} />
          </div>
        </div>
        <h1 className="logo-text text-3xl mb-1">REFORM FITNESS</h1>
        <p className="logo-sub tracking-widest mb-8">ENTERPRISE MANAGEMENT</p>
        <div className="flex gap-1.5">
          {[0,1,2,3].map(i => (
            <div key={i} className="w-2 h-2 rounded-full bg-neon animate-bounce"
              style={{ animationDelay: `${i * 0.15}s`, opacity: 0.7 }} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex overflow-hidden" style={{ background: 'var(--color-bg)' }}>
      {/* Left: Branding Panel */}
      <div className="hidden lg:flex flex-col flex-1 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #050A14 0%, #07101E 40%, #0D1526 100%)' }}>

        {/* Background fitness image overlay */}
        <div className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `url("https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=1200")`,
            backgroundSize: 'cover', backgroundPosition: 'center',
          }} />
        <div className="absolute inset-0"
          style={{ background: 'linear-gradient(135deg, rgba(5,10,20,0.85) 0%, rgba(5,10,20,0.6) 100%)' }} />

        {/* Animated particles */}
        {[
          { width:6, height:6, top:'15%', left:'20%', animationDelay:'0s' },
          { width:4, height:4, top:'35%', left:'70%', animationDelay:'1s' },
          { width:8, height:8, top:'60%', left:'15%', animationDelay:'2s' },
          { width:5, height:5, top:'75%', left:'60%', animationDelay:'0.5s' },
          { width:6, height:6, top:'25%', left:'85%', animationDelay:'1.5s' },
        ].map((p, i) => <Particle key={i} style={p} />)}

        {/* Neon grid */}
        <div className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: 'linear-gradient(rgba(0,212,255,1) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,1) 1px,transparent 1px)',
            backgroundSize: '60px 60px',
          }} />

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center items-center h-full px-12 text-center">
          {/* Logo */}
          <div className="w-24 h-24 rounded-2xl flex items-center justify-center mb-6 animate-float"
            style={{ background: 'linear-gradient(135deg,#0099BB,#00D4FF)', boxShadow: '0 0 48px rgba(0,212,255,0.5)' }}>
            <Dumbbell size={42} style={{ color: '#050A14' }} />
          </div>

          <h1 className="logo-text text-5xl mb-2">REFORM FITNESS</h1>
          <p className="logo-sub text-sm mb-3">ENTERPRISE MANAGEMENT SYSTEM</p>
          <div className="neon-divider w-48 mx-auto mb-8" />

          <p className="text-lg font-light mb-2" style={{ color: 'rgba(238,242,255,0.75)' }}>
            {isAr ? 'نظام إدارة متكامل لمراكز اللياقة' : 'Complete fitness center management'}
          </p>
          <p className="text-sm mb-10" style={{ color: 'var(--color-text-muted)' }}>
            {isAr ? 'الكابتن أحمد محمد — القاهرة، مصر' : 'Captain Ahmed Mohamed — Cairo, Egypt'}
          </p>

          {/* Feature pills */}
          <div className="flex flex-wrap justify-center gap-2">
            {[
              isAr ? 'إدارة الموظفين' : 'Employee Management',
              isAr ? 'نقطة البيع' : 'Sales POS',
              isAr ? 'إدارة العملاء' : 'Customer CRM',
              isAr ? 'التقارير' : 'Analytics',
              isAr ? 'المخزون' : 'Inventory',
            ].map((f, i) => (
              <span key={i} className="px-3 py-1 rounded-full text-xs font-semibold"
                style={{ background: 'rgba(0,212,255,0.12)', color: 'var(--neon)', border: '1px solid rgba(0,212,255,0.25)' }}>
                {f}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom footer */}
        <div className="relative z-10 p-6 flex justify-between items-center" style={{ borderTop: '1px solid rgba(0,212,255,0.1)' }}>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            © 2024 REFORM FITNESS. {isAr ? 'جميع الحقوق محفوظة.' : 'All rights reserved.'}
          </p>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>v1.0.0</p>
        </div>
      </div>

      {/* Right: Auth form */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 lg:p-10 lg:max-w-md xl:max-w-lg"
        style={{ background: 'var(--color-bg-2)', borderLeft: '1px solid var(--color-border)' }}>

        {/* Top controls */}
        <div className="w-full flex justify-between items-center mb-8">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg,#0099BB,#00D4FF)' }}>
              <Dumbbell size={18} style={{ color: '#050A14' }} />
            </div>
            <span className="logo-text text-base">REFORM FITNESS</span>
          </div>
          <div className="hidden lg:block" />

          <div className="flex items-center gap-2">
            <button onClick={() => setLanguage(isAr ? 'en' : 'ar')}
              className="w-9 h-9 rounded-lg flex items-center justify-center transition hover:bg-white/5"
              style={{ color: 'var(--color-text-secondary)' }}>
              <Globe size={18} />
            </button>
            <button onClick={toggleMode}
              className="w-9 h-9 rounded-lg flex items-center justify-center transition hover:bg-white/5"
              style={{ color: 'var(--color-text-secondary)' }}>
              {mode === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </div>
        </div>

        {/* Form card */}
        <div className="w-full glass-bright rounded-2xl p-8 animate-scale-in">
          {/* Header */}
          <div className="mb-7">
            <div className="flex items-center gap-2 mb-1">
              <Zap size={18} style={{ color: 'var(--neon)' }} />
              <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                {tab === 'signin'
                  ? (isAr ? 'مرحباً بعودتك' : 'Welcome Back')
                  : (isAr ? 'إنشاء حساب' : 'Create Account')}
              </h2>
            </div>
            <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
              {tab === 'signin'
                ? (isAr ? 'سجّل دخولك إلى نظام REFORM FITNESS' : 'Sign in to REFORM FITNESS system')
                : (isAr ? 'أنشئ حسابك الجديد' : 'Set up your new account')}
            </p>
          </div>

          {/* Tabs */}
          <div className="flex mb-6 p-1 rounded-xl gap-1" style={{ background: 'rgba(0,0,0,0.3)' }}>
            {(['signin', 'signup'] as const).map(t => (
              <button key={t} onClick={() => { setTab(t); setError(''); }}
                className="flex-1 py-2 rounded-lg text-sm font-semibold transition"
                style={{
                  background: tab === t ? 'linear-gradient(135deg,#0099BB,#00D4FF)' : 'transparent',
                  color: tab === t ? '#050A14' : 'var(--color-text-secondary)',
                }}>
                {t === 'signin' ? (isAr ? 'دخول' : 'Sign In') : (isAr ? 'تسجيل' : 'Sign Up')}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            {tab === 'signup' && (
              <div>
                <label className="label">{isAr ? 'الاسم الكامل' : 'Full Name'}</label>
                <input className="input" value={fullName} onChange={e => setFullName(e.target.value)}
                  required placeholder={isAr ? 'أدخل اسمك الكامل' : 'Enter full name'} />
              </div>
            )}
            <div>
              <label className="label">{isAr ? 'البريد الإلكتروني' : 'Email Address'}</label>
              <input type="email" className="input" value={email} onChange={e => setEmail(e.target.value)}
                required placeholder="email@reformfitness.com" />
            </div>
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="label" style={{ marginBottom: 0 }}>{isAr ? 'كلمة المرور' : 'Password'}</label>
                {tab === 'signin' && (
                  <button type="button" className="text-xs transition"
                    style={{ color: 'var(--neon)' }}>
                    {isAr ? 'نسيت كلمة المرور؟' : 'Forgot password?'}
                  </button>
                )}
              </div>
              <div className="relative">
                <input type={showPw ? 'text' : 'password'} className="input pr-10"
                  value={password} onChange={e => setPassword(e.target.value)}
                  required minLength={6} placeholder="••••••••" />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--color-text-muted)' }}>
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {tab === 'signin' && (
              <div className="flex items-center gap-2">
                <input type="checkbox" id="remember" checked={remember}
                  onChange={e => setRemember(e.target.checked)}
                  className="w-4 h-4 rounded accent-neon cursor-pointer" />
                <label htmlFor="remember" className="text-sm cursor-pointer"
                  style={{ color: 'var(--color-text-secondary)' }}>
                  {isAr ? 'تذكّرني' : 'Remember me'}
                </label>
              </div>
            )}

            {error && (
              <div className="rounded-xl px-4 py-3 text-sm flex items-center gap-2"
                style={{ background: 'rgba(239,68,68,0.12)', color: '#F87171', border: '1px solid rgba(239,68,68,0.25)' }}>
                <span>⚠</span>{error}
              </div>
            )}

            <button type="submit" disabled={loading}
              className="btn btn-primary w-full h-11 text-base mt-2">
              {loading
                ? <Loader2 size={20} className="animate-spin" />
                : tab === 'signin'
                  ? (isAr ? 'تسجيل الدخول' : 'Sign In')
                  : (isAr ? 'إنشاء الحساب' : 'Create Account')}
            </button>
          </form>
        </div>

        {/* Footer */}
        <p className="text-xs mt-6 text-center" style={{ color: 'var(--color-text-muted)' }}>
          © 2024 REFORM FITNESS — {isAr ? 'القاهرة، مصر' : 'Cairo, Egypt'} •{' '}
          <a href="tel:01550098212" style={{ color: 'var(--neon)' }}>01550098212</a>
        </p>
      </div>
    </div>
  );
}
