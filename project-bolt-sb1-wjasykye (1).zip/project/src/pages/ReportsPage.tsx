import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useTheme } from '../contexts/ThemeContext';
import { Card, PageHeader, Button, Skeleton } from '../components/ui';
import { BarChart, LineChart, DonutChart } from '../components/Charts';
import { Download, TrendingUp, Users, DollarSign, ShoppingCart, Package, Printer, Calendar, UserCheck, AlertTriangle, BarChart3, Clock } from 'lucide-react';

export function ReportsPage() {
  const { language } = useTheme();
  const isAr = language === 'ar';
  const [tab,     setTab]     = useState('overview');
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState({
    sales: 0, revenue: 0, expenses: 0, customers: 0, employees: 0, products: 0,
    attendance: { present: 0, absent: 0, late: 0, totalHours: 0 },
    leave: { pending: 0, approved: 0, rejected: 0 },
    payroll: { total: 0, paid: 0, pending: 0 }
  });
  const [salesChart,   setSalesChart]   = useState<any[]>([]);
  const [revenueChart, setRevenueChart] = useState<any[]>([]);
  const [reportData, setReportData] = useState<any>({
    employees: [],
    attendance: [],
    leave: [],
    payroll: [],
    sales: [],
    inventory: []
  });

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const [sal, rev, exp, cust, emp, prod, att, leave, pay, sales, inv] = await Promise.all([
          supabase.from('sales').select('total'),
          supabase.from('revenue_records').select('amount'),
          supabase.from('expenses').select('amount, status'),
          supabase.from('customers').select('*', { count:'exact', head:true }),
          supabase.from('app_users').select('*',  { count:'exact', head:true }),
          supabase.from('products').select('*',   { count:'exact', head:true }),
          supabase.from('attendance').select('*'),
          supabase.from('leave_requests').select('*'),
          supabase.from('payroll').select('*'),
          supabase.from('sales').select('*'),
          supabase.from('inventory').select('*'),
        ]);

        const salesTotal   = sal.data?.reduce((s:number,r:any)=>s+(r.total||0),0)||0;
        const revTotal     = rev.data?.reduce((s:number,r:any)=>s+(r.amount||0),0)||0;
        const expTotal     = exp.data?.filter((e:any)=>e.status==='paid').reduce((s:number,e:any)=>s+(e.amount||0),0)||0;

        const attendance = att.data || [];
        const leaveData = leave.data || [];
        const payrollData = pay.data || [];
        const salesData = sales.data || [];
        const invData = inv.data || [];

        setSummary({
          sales: salesTotal, revenue: revTotal, expenses: expTotal,
          customers: cust.count||0, employees: emp.count||0, products: prod.count||0,
          attendance: {
            present: attendance.filter((a:any)=>a.status==='present').length,
            absent: attendance.filter((a:any)=>a.status==='absent').length,
            late: attendance.filter((a:any)=>a.status==='late' || (a.late_minutes && a.late_minutes > 0)).length,
            totalHours: attendance.reduce((s:number,a:any)=>s+(a.working_hours||0),0)
          },
          leave: {
            pending: leaveData.filter((l:any)=>l.status==='pending').length,
            approved: leaveData.filter((l:any)=>l.status==='approved').length,
            rejected: leaveData.filter((l:any)=>l.status==='rejected').length
          },
          payroll: {
            total: payrollData.reduce((s:number,p:any)=>s+(p.net_salary||0),0),
            paid: payrollData.filter((p:any)=>p.status==='paid').reduce((s:number,p:any)=>s+(p.net_salary||0),0),
            pending: payrollData.filter((p:any)=>p.status==='pending').reduce((s:number,p:any)=>s+(p.net_salary||0),0)
          }
        });

        setReportData({
          employees: emp.data || [],
          attendance,
          leave: leaveData,
          payroll: payrollData,
          sales: salesData,
          inventory: invData
        });

        const mo = isAr ? ['ينا','فبر','مار','أبر','ماي','يون','يول','أغس'] : ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug'];
        setSalesChart(mo.map(m=>({ label:m, value:0 })));
        setRevenueChart(mo.map(m=>({ label:m, value:0 })));
      } catch (e) {
        console.error('Failed to load report data:', e);
      }
      setLoading(false);
    })();
  }, [isAr]);

  // Export functions
  const exportEmployeeReport = () => {
    const w = window.open('','_blank');
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Employee Report</title><style>
      body{font-family:Arial,sans-serif;padding:20px;color:#0D1526}h1{color:#0099BB;border-bottom:3px solid #00D4FF;padding-bottom:8px}
      table{width:100%;border-collapse:collapse;margin-top:16px;font-size:12px}
      th{background:#0D1526;color:white;padding:10px;text-align:left}td{padding:8px;border-bottom:1px solid #eee}
      .badge{display:inline-block;padding:2px 8px;border-radius:9999px;font-size:11px}.active{background:#dcfce7;color:#166534}.inactive{background:#fee2e2;color:#991b1b}
      @media print{body{padding:10px}}
    </style></head><body>
    <h1>REFORM FITNESS — Employee Report</h1>
    <p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString()}</p>
    <table><thead><tr><th>Code</th><th>Name</th><th>Email</th><th>Phone</th><th>Department</th><th>Job Title</th><th>Status</th></tr></thead>
    <tbody>${reportData.employees.map((e:any)=>`<tr>
      <td>${e.employee_id||''}</td><td>${e.full_name}</td><td>${e.email||''}</td><td>${e.phone||''}</td>
      <td>${e.department_name||''}</td><td>${e.job_title||''}</td><td><span class="badge ${e.status}">${e.status}</span></td>
    </tr>`).join('')}</tbody></table></body></html>`);
    w.document.close();
    w.print();
  };

  const exportAttendanceReport = () => {
    const data = reportData.attendance;
    const present = data.filter((a:any)=>a.status==='present').length;
    const absent = data.filter((a:any)=>a.status==='absent').length;
    const late = data.filter((a:any)=>a.status==='late' || (a.late_minutes && a.late_minutes > 0)).length;
    const totalHours = data.reduce((s:number,a:any)=>s+(a.working_hours||0),0);
    const totalLateMin = data.reduce((s:number,a:any)=>s+(a.late_minutes||0),0);

    const w = window.open('','_blank');
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Attendance Report</title><style>
      body{font-family:Arial,sans-serif;padding:20px;color:#0D1526}h1{color:#0099BB;border-bottom:3px solid #00D4FF;padding-bottom:8px}
      .summary{display:flex;gap:16px;margin:16px 0;flex-wrap:wrap}
      .kpi{padding:12px 20px;border-radius:8px;text-align:center;font-size:13px;flex:1;min-width:140px}
      table{width:100%;border-collapse:collapse;margin-top:16px;font-size:12px}
      th{background:#0D1526;color:white;padding:8px;text-align:left}td{padding:6px;border-bottom:1px solid #eee}
      .present{background:#dcfce7;color:#166534}.absent{background:#fee2e2;color:#991b1b}.late{background:#fef9c3;color:#854d0e}
      @media print{body{padding:10px}}
    </style></head><body>
    <h1>REFORM FITNESS — Attendance Report</h1>
    <p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString()} | Total Records: ${data.length}</p>
    <div class="summary">
      <div class="kpi present"><strong>${present}</strong><br>Present</div>
      <div class="kpi absent"><strong>${absent}</strong><br>Absent</div>
      <div class="kpi late"><strong>${late}</strong><br>Late Arrivals</div>
      <div class="kpi" style="background:#e0f2fe;color:#0369a1"><strong>${totalLateMin}</strong><br>Total Late Minutes</div>
      <div class="kpi" style="background:#f0fdf4;color:#166534"><strong>${totalHours.toFixed(1)}</strong><br>Total Working Hours</div>
    </div>
    <table><thead><tr><th>Employee</th><th>Date</th><th>Check In</th><th>Check Out</th><th>Late (min)</th><th>Hours</th><th>Status</th></tr></thead>
    <tbody>${data.map((r:any)=>`<tr>
      <td>${r.employee_name || r.employee_id}</td><td>${r.date}</td><td>${r.check_in||'—'}</td>
      <td>${r.check_out||'—'}</td><td>${r.late_minutes||0}</td><td>${r.working_hours||0}</td>
      <td>${r.status}</td>
    </tr>`).join('')}</tbody></table></body></html>`);
    w.document.close();
    w.print();
  };

  const exportLeaveReport = () => {
    const data = reportData.leave;
    const pending = data.filter((l:any)=>l.status==='pending').length;
    const approved = data.filter((l:any)=>l.status==='approved').length;
    const rejected = data.filter((l:any)=>l.status==='rejected').length;

    const w = window.open('','_blank');
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Leave Report</title><style>
      body{font-family:Arial,sans-serif;padding:20px;color:#0D1526}h1{color:#0099BB;border-bottom:3px solid #00D4FF;padding-bottom:8px}
      .summary{display:flex;gap:16px;margin:16px 0;flex-wrap:wrap}
      .kpi{padding:12px 20px;border-radius:8px;text-align:center;font-size:13px;flex:1;min-width:140px}
      table{width:100%;border-collapse:collapse;margin-top:16px;font-size:12px}
      th{background:#0D1526;color:white;padding:8px;text-align:left}td{padding:6px;border-bottom:1px solid #eee}
      .pending{background:#fef9c3;color:#854d0e}.approved{background:#dcfce7;color:#166534}.rejected{background:#fee2e2;color:#991b1b}
      @media print{body{padding:10px}}
    </style></head><body>
    <h1>REFORM FITNESS — Leave Requests Report</h1>
    <p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString()}</p>
    <div class="summary">
      <div class="kpi pending"><strong>${pending}</strong><br>Pending</div>
      <div class="kpi approved"><strong>${approved}</strong><br>Approved</div>
      <div class="kpi rejected"><strong>${rejected}</strong><br>Rejected</div>
    </div>
    <table><thead><tr><th>Employee</th><th>Type</th><th>Start</th><th>End</th><th>Days</th><th>Reason</th><th>Status</th></tr></thead>
    <tbody>${data.map((r:any)=>`<tr>
      <td>${r.employee_name || r.employee_code}</td><td>${r.leave_type}</td>
      <td>${r.start_date}</td><td>${r.end_date}</td><td>${r.total_days||'—'}</td>
      <td>${r.reason||''}</td><td><span class="${r.status}">${r.status}</span></td>
    </tr>`).join('')}</tbody></table></body></html>`);
    w.document.close();
    w.print();
  };

  const exportPayrollReport = () => {
    const data = reportData.payroll;
    const total = data.reduce((s:number,p:any)=>s+(p.net_salary||0),0);
    const totalBase = data.reduce((s:number,p:any)=>s+(p.base_salary||0),0);
    const totalPenalties = data.reduce((s:number,p:any)=>s+(p.late_deductions||0)+(p.absence_deductions||0)+(p.other_penalties||0),0);
    const totalRewards = data.reduce((s:number,p:any)=>s+(p.rewards||0)+(p.bonuses||0)+(p.commissions||0),0);
    const paid = data.filter((p:any)=>p.status==='paid').length;
    const pending = data.filter((p:any)=>p.status==='pending').length;

    const w = window.open('','_blank');
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Payroll Report</title><style>
      body{font-family:Arial,sans-serif;padding:20px;color:#0D1526}h1{color:#0099BB;border-bottom:3px solid #00D4FF;padding-bottom:8px}
      .summary{display:flex;gap:16px;margin:16px 0;flex-wrap:wrap}
      .kpi{padding:12px 20px;border-radius:8px;text-align:center;font-size:13px;flex:1;min-width:140px}
      table{width:100%;border-collapse:collapse;margin-top:16px;font-size:11px}
      th{background:#0D1526;color:white;padding:8px;text-align:left}td{padding:6px;border-bottom:1px solid #eee}
      .total{font-weight:bold;background:#f0f8ff}.paid{color:#166534}.pending{color:#854d0e}
      @media print{body{padding:10px}}
    </style></head><body>
    <h1>REFORM FITNESS — Payroll Report</h1>
    <p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString()}</p>
    <div class="summary">
      <div class="kpi" style="background:#dcfce7;color:#166534"><strong>EGP ${totalBase.toLocaleString()}</strong><br>Base Salaries</div>
      <div class="kpi" style="background:#f0fdf4;color:#166534"><strong>EGP ${totalRewards.toLocaleString()}</strong><br>Rewards & Bonuses</div>
      <div class="kpi" style="background:#fee2e2;color:#991b1b"><strong>EGP ${totalPenalties.toLocaleString()}</strong><br>Penalties & Deductions</div>
      <div class="kpi" style="background:#e0f2fe;color:#0369a1"><strong>EGP ${total.toLocaleString()}</strong><br>Net Total</div>
      <div class="kpi" style="background:#f5f5f5;color:#374151"><strong>${paid}</strong><br>Paid</div>
      <div class="kpi" style="background:#fef9c3;color:#854d0e"><strong>${pending}</strong><br>Pending</div>
    </div>
    <table><thead><tr><th>Employee</th><th>Month</th><th>Year</th><th>Base</th><th>Bonus</th><th>Late Ded.</th><th>Abs. Ded.</th><th>Net</th><th>Status</th></tr></thead>
    <tbody>${data.map((r:any)=>`<tr>
      <td>${r.employee_name || r.employee_id}</td><td>${r.period_month}</td><td>${r.period_year}</td>
      <td>EGP ${r.base_salary||0}</td><td>EGP ${r.bonuses||0}</td>
      <td>EGP ${r.late_deductions||0}</td><td>EGP ${r.absence_deductions||0}</td>
      <td class="${r.status}">EGP ${r.net_salary||0}</td><td>${r.status}</td>
    </tr>`).join('')}
    <tr class="total"><td colspan="7" style="text-align:right;padding-right:8px">Total:</td><td>EGP ${total.toLocaleString()}</td><td></td></tr>
    </tbody></table></body></html>`);
    w.document.close();
    w.print();
  };

  const exportSalesReport = () => {
    const data = reportData.sales;
    const total = data.reduce((s:number,r:any)=>s+(r.total||0),0);
    const paid = data.filter((r:any)=>r.payment_status==='paid').reduce((s:number,r:any)=>s+(r.total||0),0);
    const pending = data.filter((r:any)=>r.payment_status!=='paid').reduce((s:number,r:any)=>s+(r.total||0),0);

    const w = window.open('','_blank');
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Sales Report</title><style>
      body{font-family:Arial,sans-serif;padding:20px;color:#0D1526}h1{color:#0099BB;border-bottom:3px solid #00D4FF;padding-bottom:8px}
      .summary{display:flex;gap:16px;margin:16px 0;flex-wrap:wrap}
      .kpi{padding:12px 20px;border-radius:8px;text-align:center;font-size:13px;flex:1;min-width:140px}
      table{width:100%;border-collapse:collapse;margin-top:16px;font-size:12px}
      th{background:#0D1526;color:white;padding:8px;text-align:left}td{padding:6px;border-bottom:1px solid #eee}
      @media print{body{padding:10px}}
    </style></head><body>
    <h1>REFORM FITNESS — Sales Report</h1>
    <p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString()}</p>
    <div class="summary">
      <div class="kpi" style="background:#e0f2fe;color:#0369a1"><strong>EGP ${total.toLocaleString()}</strong><br>Total Sales</div>
      <div class="kpi" style="background:#dcfce7;color:#166534"><strong>EGP ${paid.toLocaleString()}</strong><br>Paid</div>
      <div class="kpi" style="background:#fef9c3;color:#854d0e"><strong>EGP ${pending.toLocaleString()}</strong><br>Pending</div>
      <div class="kpi" style="background:#f5f5f5;color:#374151"><strong>${data.length}</strong><br>Orders</div>
    </div>
    <table><thead><tr><th>Order #</th><th>Date</th><th>Customer</th><th>Subtotal</th><th>Discount</th><th>Total</th><th>Payment</th><th>Status</th></tr></thead>
    <tbody>${data.map((r:any)=>`<tr>
      <td>${r.sale_number||''}</td><td>${r.sale_date?new Date(r.sale_date).toLocaleDateString():''}</td>
      <td>${r.customer_name||r.customer_id||'—'}</td><td>EGP ${r.subtotal||0}</td><td>EGP ${r.discount||0}</td>
      <td>EGP ${r.total||0}</td><td>${r.payment_method}</td><td>${r.status}</td>
    </tr>`).join('')}</tbody></table></body></html>`);
    w.document.close();
    w.print();
  };

  const exportInventoryReport = () => {
    const data = reportData.inventory;
    const lowStock = data.filter((i:any)=>i.quantity <= i.min_quantity && i.min_quantity > 0).length;

    const w = window.open('','_blank');
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Inventory Report</title><style>
      body{font-family:Arial,sans-serif;padding:20px;color:#0D1526}h1{color:#0099BB;border-bottom:3px solid #00D4FF;padding-bottom:8px}
      .summary{display:flex;gap:16px;margin:16px 0;flex-wrap:wrap}
      .kpi{padding:12px 20px;border-radius:8px;text-align:center;font-size:13px;flex:1;min-width:140px}
      table{width:100%;border-collapse:collapse;margin-top:16px;font-size:12px}
      th{background:#0D1526;color:white;padding:8px;text-align:left}td{padding:6px;border-bottom:1px solid #eee}
      .low{color:#EF4444;font-weight:bold}.warning{background:#fee2e2}
      @media print{body{padding:10px}}
    </style></head><body>
    <h1>REFORM FITNESS — Inventory Report</h1>
    <p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString()}</p>
    <div class="summary">
      <div class="kpi" style="background:#e0f2fe;color:#0369a1"><strong>${data.length}</strong><br>Total Items</div>
      <div class="kpi" style="background:#fee2e2;color:#991b1b"><strong>${lowStock}</strong><br>Low Stock</div>
    </div>
    <table><thead><tr><th>Product ID</th><th>Quantity</th><th>Min Qty</th><th>Expiry</th><th>Batch</th></tr></thead>
    <tbody>${data.map((r:any)=>{
      const isLow = r.quantity <= r.min_quantity && r.min_quantity > 0;
      return `<tr class="${isLow?'warning':''}">
        <td>${r.product_id}</td><td class="${isLow?'low':''}">${r.quantity}${isLow?' ⚠':''}</td>
        <td>${r.min_quantity||0}</td><td>${r.expiry_date||'—'}</td><td>${r.batch_number||'—'}</td>
      </tr>`;
    }).join('')}</tbody></table></body></html>`);
    w.document.close();
    w.print();
  };

  const exportOverviewPDF = () => {
    const w = window.open('','_blank');
    if(!w) return;
    w.document.write(`<html><head><title>Analytics Report</title><style>
      body{font-family:sans-serif;padding:24px;color:#0D1526;}h1{color:#0099BB;font-size:22px;}h2{font-size:16px;margin-top:24px;border-bottom:2px solid #00D4FF;padding-bottom:6px;}
      table{width:100%;border-collapse:collapse;margin-top:12px;}th,td{padding:10px;border:1px solid #ddd;font-size:13px;}th{background:#0D1526;color:white;}
      .kpi{display:inline-block;margin:8px;padding:12px 20px;background:#f0f8ff;border-radius:8px;border-left:4px solid #00D4FF;}
    </style></head><body>
    <h1>REFORM FITNESS — Analytics Report</h1>
    <p style="color:#666">Generated: ${new Date().toLocaleString()} | Cairo, Egypt</p>
    <h2>Key Performance Indicators</h2>
    <div>
      <div class="kpi"><strong>Total Sales</strong><br>EGP ${summary.sales.toLocaleString()}</div>
      <div class="kpi"><strong>Revenue</strong><br>EGP ${summary.revenue.toLocaleString()}</div>
      <div class="kpi"><strong>Expenses</strong><br>EGP ${summary.expenses.toLocaleString()}</div>
      <div class="kpi"><strong>Net Profit</strong><br>EGP ${(summary.revenue - summary.expenses).toLocaleString()}</div>
      <div class="kpi"><strong>Customers</strong><br>${summary.customers}</div>
      <div class="kpi"><strong>Employees</strong><br>${summary.employees}</div>
    </div>
    <h2>Attendance Summary</h2>
    <div>
      <div class="kpi"><strong>Present</strong><br>${summary.attendance.present}</div>
      <div class="kpi"><strong>Absent</strong><br>${summary.attendance.absent}</div>
      <div class="kpi"><strong>Late</strong><br>${summary.attendance.late}</div>
      <div class="kpi"><strong>Work Hours</strong><br>${summary.attendance.totalHours.toFixed(1)}</div>
    </div>
    <h2>Payroll Summary</h2>
    <div>
      <div class="kpi"><strong>Total Net</strong><br>EGP ${summary.payroll.total.toLocaleString()}</div>
      <div class="kpi"><strong>Paid</strong><br>EGP ${summary.payroll.paid.toLocaleString()}</div>
      <div class="kpi"><strong>Pending</strong><br>EGP ${summary.payroll.pending.toLocaleString()}</div>
    </div>
    </body></html>`);
    w.document.close(); w.print();
  };

  const exportCSV = () => {
    const rows = [
      ['Metric', 'Value'],
      ['Total Sales', summary.sales],
      ['Total Revenue', summary.revenue],
      ['Total Expenses', summary.expenses],
      ['Net Profit', summary.revenue - summary.expenses],
      ['Customers', summary.customers],
      ['Employees', summary.employees],
      ['Products', summary.products],
      ['Present Days', summary.attendance.present],
      ['Absent Days', summary.attendance.absent],
      ['Late Arrivals', summary.attendance.late],
      ['Total Work Hours', summary.attendance.totalHours],
      ['Pending Leave', summary.leave.pending],
      ['Approved Leave', summary.leave.approved],
      ['Total Payroll', summary.payroll.total],
      ['Paid Payroll', summary.payroll.paid],
    ];
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `reform_fitness_report_${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const tabs = [
    { id:'overview', en:'Overview',    ar:'نظرة عامة', icon: BarChart3 },
    { id:'employees',en:'Employees',   ar:'الموظفون',   icon: Users },
    { id:'attendance',en:'Attendance',ar:'الحضور',      icon: UserCheck },
    { id:'leave',    en:'Leave',       ar:'الإجازات',   icon: Calendar },
    { id:'payroll',  en:'Payroll',     ar:'الرواتب',    icon: DollarSign },
    { id:'sales',    en:'Sales',       ar:'المبيعات',   icon: ShoppingCart },
    { id:'inventory',en:'Inventory',   ar:'المخزون',    icon: Package },
  ];

  const kpis = [
    { en:'Total Sales',   ar:'إجمالي المبيعات',   value:`EGP ${summary.sales.toLocaleString()}`,     icon: ShoppingCart, color:'#00D4FF' },
    { en:'Revenue',       ar:'الإيرادات',           value:`EGP ${summary.revenue.toLocaleString()}`,   icon: DollarSign,   color:'#22C55E' },
    { en:'Expenses',      ar:'المصروفات',           value:`EGP ${summary.expenses.toLocaleString()}`,  icon: TrendingUp,   color:'#EF4444' },
    { en:'Net Profit',    ar:'صافي الربح',          value:`EGP ${(summary.revenue-summary.expenses).toLocaleString()}`, icon: DollarSign, color:'#F59E0B' },
    { en:'Customers',     ar:'العملاء',             value: summary.customers,                          icon: Users,        color:'#A78BFA' },
    { en:'Products',      ar:'المنتجات',            value: summary.products,                           icon: Package,      color:'#FB923C' },
  ];

  return (
    <div>
      <PageHeader title={isAr?'التقارير':'Reports'} subtitle={isAr?'تقارير وتحليلات شاملة':'Comprehensive analytics and reports'}
        action={
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" icon={Download} onClick={exportCSV}>CSV</Button>
            <Button size="sm" icon={Printer} onClick={exportOverviewPDF}>{isAr?'طباعة':'Print'}</Button>
          </div>
        } />

      {/* Tabs */}
      <div className="flex gap-1 mb-6 overflow-x-auto">
        {tabs.map(t => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition whitespace-nowrap flex items-center gap-2 ${tab === t.id ? 'tab-active' : ''}`}
              style={{ color: tab === t.id ? 'var(--neon)' : 'var(--color-text-muted)', background: tab === t.id ? 'rgba(0,212,255,0.08)' : 'transparent' }}>
              <Icon size={16} />
              {isAr ? t.ar : t.en}
            </button>
          );
        })}
      </div>

      {/* Overview Tab */}
      {tab === 'overview' && (
        <>
          {/* KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 mb-6">
            {loading
              ? Array.from({length:6}).map((_,i)=><Skeleton key={i} className="h-24"/>)
              : kpis.map((k,i) => {
                  const Icon = k.icon;
                  return (
                    <div key={i} className="rf-card-glow stat-card p-4">
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3"
                        style={{ background:`${k.color}18`, border:`1px solid ${k.color}30` }}>
                        <Icon size={18} style={{ color: k.color }} />
                      </div>
                      <p className="text-lg font-extrabold" style={{ color:'var(--color-text)' }}>{k.value}</p>
                      <p className="text-xs" style={{ color:'var(--color-text-muted)' }}>{isAr?k.ar:k.en}</p>
                    </div>
                  );
                })
            }
          </div>

          {/* Attendance & Leave Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <Card>
              <h3 className="font-bold text-sm mb-4" style={{color:'var(--color-text)'}}>{isAr?'ملخص الحضور':'Attendance Summary'}</h3>
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: isAr?'حاضر':'Present', value: summary.attendance.present, color: '#22C55E' },
                  { label: isAr?'غائب':'Absent', value: summary.attendance.absent, color: '#EF4444' },
                  { label: isAr?'متأخر':'Late', value: summary.attendance.late, color: '#F59E0B' },
                  { label: isAr?'ساعات':'Hours', value: summary.attendance.totalHours.toFixed(1), color: '#00D4FF' },
                ].map((s,i) => (
                  <div key={i} className="text-center p-3 rounded-xl" style={{background:`${s.color}12`,border:`1px solid ${s.color}25`}}>
                    <p className="text-xl font-bold" style={{color:s.color}}>{s.value}</p>
                    <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
                  </div>
                ))}
              </div>
            </Card>
            <Card>
              <h3 className="font-bold text-sm mb-4" style={{color:'var(--color-text)'}}>{isAr?'ملخص الإجازات':'Leave Summary'}</h3>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: isAr?'قيد الانتظار':'Pending', value: summary.leave.pending, color: '#F59E0B' },
                  { label: isAr?'موافق عليه':'Approved', value: summary.leave.approved, color: '#22C55E' },
                  { label: isAr?'مرفوض':'Rejected', value: summary.leave.rejected, color: '#EF4444' },
                ].map((s,i) => (
                  <div key={i} className="text-center p-3 rounded-xl" style={{background:`${s.color}12`,border:`1px solid ${s.color}25`}}>
                    <p className="text-xl font-bold" style={{color:s.color}}>{s.value}</p>
                    <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Payroll Summary */}
          <Card className="mb-4">
            <h3 className="font-bold text-sm mb-4" style={{color:'var(--color-text)'}}>{isAr?'ملخص الرواتب':'Payroll Summary'}</h3>
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: isAr?'إجمالي الرواتب':'Total Net', value: `EGP ${summary.payroll.total.toLocaleString()}`, color: '#00D4FF' },
                { label: isAr?'مدفوع':'Paid', value: `EGP ${summary.payroll.paid.toLocaleString()}`, color: '#22C55E' },
                { label: isAr?'معلق':'Pending', value: `EGP ${summary.payroll.pending.toLocaleString()}`, color: '#F59E0B' },
              ].map((s,i) => (
                <div key={i} className="text-center p-4 rounded-xl" style={{background:`${s.color}12`,border:`1px solid ${s.color}25`}}>
                  <p className="text-xl font-bold" style={{color:s.color}}>{s.value}</p>
                  <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
            <Card className="lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-sm" style={{ color:'var(--color-text)' }}>{isAr?'المبيعات الشهرية':'Monthly Sales'}</h3>
                <TrendingUp size={16} style={{ color:'var(--neon)' }}/>
              </div>
              {loading ? <Skeleton className="h-48"/> : <BarChart data={salesChart} height={180}/>}
            </Card>
            <Card>
              <h3 className="font-bold text-sm mb-4" style={{ color:'var(--color-text)' }}>{isAr?'توزيع الإيرادات':'Revenue Split'}</h3>
              {loading ? <Skeleton className="h-48"/> : (
                <DonutChart data={[
                  { label: isAr?'مبيعات':'Sales',    value: summary.sales,    color:'#00D4FF' },
                  { label: isAr?'إيرادات':'Revenue', value: summary.revenue,  color:'#22C55E' },
                  { label: isAr?'مصروف':'Expenses',  value: summary.expenses, color:'#EF4444' },
                ]} />
              )}
            </Card>
          </div>
          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-sm" style={{ color:'var(--color-text)' }}>{isAr?'اتجاه الإيرادات':'Revenue Trend'}</h3>
              <DollarSign size={16} style={{ color:'#22C55E' }}/>
            </div>
            {loading ? <Skeleton className="h-44"/> : <LineChart data={revenueChart} height={160} color="#22C55E"/>}
          </Card>
        </>
      )}

      {/* Employee Report Tab */}
      {tab === 'employees' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg" style={{color:'var(--color-text)'}}>{isAr?'تقرير الموظفين':'Employee Report'}</h3>
            <Button icon={Printer} onClick={exportEmployeeReport}>{isAr?'طباعة':'Print'}</Button>
          </div>
          <Card>
            <p className="text-sm mb-2" style={{color:'var(--color-text-muted)'}}>
              {isAr?'إجمالي الموظفين':'Total Employees'}: <strong>{summary.employees}</strong>
            </p>
            <p className="text-xs" style={{color:'var(--color-text-secondary)'}}>
              {isAr?'انقر على زر الطباعة لتصدير التقرير الكامل':'Click Print to export the full report'}
            </p>
          </Card>
        </div>
      )}

      {/* Attendance Report Tab */}
      {tab === 'attendance' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg" style={{color:'var(--color-text)'}}>{isAr?'تقرير الحضور':'Attendance Report'}</h3>
            <Button icon={Printer} onClick={exportAttendanceReport}>{isAr?'طباعة':'Print'}</Button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
            {[
              { label: isAr?'حاضر':'Present', value: summary.attendance.present, color: '#22C55E' },
              { label: isAr?'غائب':'Absent', value: summary.attendance.absent, color: '#EF4444' },
              { label: isAr?'متأخر':'Late', value: summary.attendance.late, color: '#F59E0B' },
              { label: isAr?'ساعات العمل':'Work Hours', value: summary.attendance.totalHours.toFixed(1), color: '#00D4FF' },
              { label: isAr?'إجمالي السجلات':'Total Records', value: reportData.attendance.length, color: '#A78BFA' },
            ].map((s,i) => (
              <div key={i} className="rf-card-glow stat-card p-4">
                <p className="text-2xl font-bold" style={{color:s.color}}>{s.value}</p>
                <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Leave Report Tab */}
      {tab === 'leave' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg" style={{color:'var(--color-text)'}}>{isAr?'تقرير الإجازات':'Leave Report'}</h3>
            <Button icon={Printer} onClick={exportLeaveReport}>{isAr?'طباعة':'Print'}</Button>
          </div>
          <div className="grid grid-cols-3 gap-4 mb-4">
            {[
              { label: isAr?'قيد الانتظار':'Pending', value: summary.leave.pending, color: '#F59E0B', icon: Clock },
              { label: isAr?'موافق عليه':'Approved', value: summary.leave.approved, color: '#22C55E', icon: UserCheck },
              { label: isAr?'مرفوض':'Rejected', value: summary.leave.rejected, color: '#EF4444', icon: AlertTriangle },
            ].map((s,i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="rf-card-glow stat-card p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{background:`${s.color}18`}}>
                      <Icon size={16} style={{color:s.color}}/>
                    </div>
                    <span className="text-2xl font-bold" style={{color:s.color}}>{s.value}</span>
                  </div>
                  <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Payroll Report Tab */}
      {tab === 'payroll' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg" style={{color:'var(--color-text)'}}>{isAr?'تقرير الرواتب':'Payroll Report'}</h3>
            <Button icon={Printer} onClick={exportPayrollReport}>{isAr?'طباعة':'Print'}</Button>
          </div>
          <div className="grid grid-cols-3 gap-4 mb-4">
            {[
              { label: isAr?'إجمالي الرواتب':'Total Net', value: `EGP ${summary.payroll.total.toLocaleString()}`, color: '#00D4FF' },
              { label: isAr?'مدفوع':'Paid', value: `EGP ${summary.payroll.paid.toLocaleString()}`, color: '#22C55E' },
              { label: isAr?'معلق':'Pending', value: `EGP ${summary.payroll.pending.toLocaleString()}`, color: '#F59E0B' },
            ].map((s,i) => (
              <div key={i} className="rf-card-glow stat-card p-4">
                <p className="text-xl font-bold" style={{color:s.color}}>{s.value}</p>
                <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sales Report Tab */}
      {tab === 'sales' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg" style={{color:'var(--color-text)'}}>{isAr?'تقرير المبيعات':'Sales Report'}</h3>
            <Button icon={Printer} onClick={exportSalesReport}>{isAr?'طباعة':'Print'}</Button>
          </div>
          <div className="grid grid-cols-4 gap-4 mb-4">
            {[
              { label: isAr?'إجمالي المبيعات':'Total Sales', value: `EGP ${summary.sales.toLocaleString()}`, color: '#00D4FF' },
              { label: isAr?'الطلبات':'Orders', value: reportData.sales.length, color: '#A78BFA' },
              { label: isAr?'العملاء':'Customers', value: summary.customers, color: '#22C55E' },
              { label: isAr?'المنتجات':'Products', value: summary.products, color: '#FB923C' },
            ].map((s,i) => (
              <div key={i} className="rf-card-glow stat-card p-4">
                <p className="text-xl font-bold" style={{color:s.color}}>{s.value}</p>
                <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Inventory Report Tab */}
      {tab === 'inventory' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg" style={{color:'var(--color-text)'}}>{isAr?'تقرير المخزون':'Inventory Report'}</h3>
            <Button icon={Printer} onClick={exportInventoryReport}>{isAr?'طباعة':'Print'}</Button>
          </div>
          <div className="grid grid-cols-2 gap-4 mb-4">
            {[
              { label: isAr?'إجمالي العناصر':'Total Items', value: reportData.inventory.length, color: '#00D4FF' },
              { label: isAr?'مخزون منخفض':'Low Stock', value: reportData.inventory.filter((i:any)=>i.quantity <= i.min_quantity && i.min_quantity > 0).length, color: '#EF4444' },
            ].map((s,i) => (
              <div key={i} className="rf-card-glow stat-card p-4">
                <p className="text-2xl font-bold" style={{color:s.color}}>{s.value}</p>
                <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
