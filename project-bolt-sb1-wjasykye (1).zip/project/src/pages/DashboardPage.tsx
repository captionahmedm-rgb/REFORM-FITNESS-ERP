import { useEffect, useState } from 'react';
import { Users, UserCheck, DollarSign, ShoppingCart, Package, TrendingUp, Bell, Activity } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { StatCard, Card, Skeleton } from '../components/ui';
import { BarChart, DonutChart, LineChart } from '../components/Charts';
import { useTheme } from '../contexts/ThemeContext';

export function DashboardPage() {
  const { language, companyName, ownerName } = useTheme();
  const isAr = language === 'ar';
  const [stats, setStats] = useState({ customers: 0, employees: 0, revenue: 0, sales: 0, products: 0, lowStock: 0 });
  const [loading, setLoading] = useState(true);
  const [salesData, setSalesData]   = useState<{ label: string; value: number }[]>([]);
  const [revenueData, setRevenueData] = useState<{ label: string; value: number }[]>([]);
  const [donutData, setDonutData]   = useState<{ label: string; value: number; color: string }[]>([]);

  useEffect(() => {
    (async () => {
      try {
        const [cust, emp, sal, prod, inv, rev] = await Promise.all([
          supabase.from('customers').select('*', { count: 'exact', head: true }),
          supabase.from('app_users').select('*', { count: 'exact', head: true }),
          supabase.from('sales').select('total'),
          supabase.from('products').select('*', { count: 'exact', head: true }),
          supabase.from('inventory').select('quantity, min_quantity'),
          supabase.from('revenue_records').select('amount'),
        ]);
        const salTotal = sal.data?.reduce((s: number, r: any) => s + (r.total || 0), 0) || 0;
        const revTotal = rev.data?.reduce((s: number, r: any) => s + (r.amount || 0), 0) || 0;
        const low      = inv.data?.filter((i: any) => i.quantity <= i.min_quantity).length || 0;
        setStats({ customers: cust.count || 0, employees: emp.count || 0, revenue: revTotal, sales: salTotal, products: prod.count || 0, lowStock: low });
      } catch {}

      const mo = isAr
        ? ['ينا','فبر','مار','أبر','ماي','يون','يول','أغس']
        : ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug'];
      setSalesData(mo.map(m => ({ label: m, value: 0 })));
      setRevenueData(mo.map(m => ({ label: m, value: 0 })));
      setDonutData([
        { label: isAr ? 'مكملات' : 'Supplements', value: 0, color: '#00D4FF' },
        { label: isAr ? 'عضويات'  : 'Memberships', value: 0, color: '#0EA5E9' },
        { label: isAr ? 'تدريب'   : 'Coaching',    value: 0, color: '#38BDF8' },
      ]);
      setLoading(false);
    })();
  }, [isAr]);

  const statCards = [
    { label: isAr ? 'إجمالي العملاء'  : 'Total Customers',  value: stats.customers,                         icon: Users,        color: '#00D4FF' },
    { label: isAr ? 'الموظفون'         : 'Employees',         value: stats.employees,                         icon: UserCheck,    color: '#22C55E' },
    { label: isAr ? 'إجمالي الإيرادات': 'Total Revenue',     value: `EGP ${stats.revenue.toLocaleString()}`, icon: DollarSign,   color: '#F59E0B' },
    { label: isAr ? 'إجمالي المبيعات' : 'Total Sales',       value: `EGP ${stats.sales.toLocaleString()}`,   icon: ShoppingCart, color: '#EF4444' },
    { label: isAr ? 'المنتجات'         : 'Products',           value: stats.products,                          icon: Package,      color: '#A78BFA' },
    { label: isAr ? 'مخزون منخفض'     : 'Low Stock',          value: stats.lowStock,                          icon: Bell,         color: '#FB923C' },
  ];

  return (
    <div>
      {/* Welcome banner */}
      <div className="rf-card stat-card mb-6 p-6 overflow-hidden relative">
        <div className="absolute inset-0 opacity-5"
          style={{ backgroundImage: `url("https://images.pexels.com/photos/1552249/pexels-photo-1552249.jpeg?auto=compress&cs=tinysrgb&w=800")`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
        <div className="relative z-10 flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-extrabold mb-1" style={{ color: 'var(--color-text)' }}>
              {isAr ? 'مرحباً،' : 'Welcome back,'} <span className="neon-text">{ownerName.split(' ')[1]}</span> 👋
            </h1>
            <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
              {isAr ? `نظام إدارة ${companyName} — لوحة التحكم الرئيسية` : `${companyName} Enterprise Dashboard`}
            </p>
          </div>
          <div className="flex items-center gap-3 text-sm" style={{ color: 'var(--color-text-muted)' }}>
            <Activity size={16} style={{ color: 'var(--neon)' }} />
            <span>{new Date().toLocaleDateString(isAr ? 'ar-EG' : 'en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}</span>
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-28" />)
          : statCards.map((c, i) => (
              <div key={i} className="animate-slide-up" style={{ animationDelay: `${i * 0.06}s` }}>
                <StatCard {...c} />
              </div>
            ))
        }
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-sm" style={{ color: 'var(--color-text)' }}>
              {isAr ? 'المبيعات الشهرية' : 'Monthly Sales'}
            </h3>
            <TrendingUp size={16} style={{ color: 'var(--neon)' }} />
          </div>
          {loading ? <Skeleton className="h-48" /> : <BarChart data={salesData} height={180} />}
        </Card>
        <Card>
          <h3 className="font-bold text-sm mb-4" style={{ color: 'var(--color-text)' }}>
            {isAr ? 'توزيع المبيعات' : 'Sales Distribution'}
          </h3>
          {loading ? <Skeleton className="h-48" /> : <DonutChart data={donutData} />}
        </Card>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-sm" style={{ color: 'var(--color-text)' }}>
              {isAr ? 'الإيرادات' : 'Revenue Trend'}
            </h3>
            <DollarSign size={16} style={{ color: '#22C55E' }} />
          </div>
          {loading ? <Skeleton className="h-44" /> : <LineChart data={revenueData} height={160} color="#22C55E" />}
        </Card>
        <Card>
          <h3 className="font-bold text-sm mb-4" style={{ color: 'var(--color-text)' }}>
            {isAr ? 'معلومات الشركة' : 'Company Info'}
          </h3>
          <div className="space-y-3">
            {[
              { label: isAr ? 'الشركة'    : 'Company',  value: 'REFORM FITNESS' },
              { label: isAr ? 'المالك'    : 'Owner',    value: 'Captain Ahmed Mohamed' },
              { label: isAr ? 'النوع'     : 'Business', value: isAr ? 'مكملات • تدريب • كوتشينج' : 'Supplements • Coaching • Programs' },
              { label: isAr ? 'الهاتف'   : 'Phone',    value: '01550098212 / 01551510427', link: 'tel:01550098212' },
              { label: isAr ? 'الموقع'   : 'Location', value: isAr ? 'القاهرة، مصر' : 'Cairo, Egypt' },
            ].map((r, i) => (
              <div key={i} className="flex justify-between items-center py-2"
                style={{ borderBottom: '1px solid var(--color-border)' }}>
                <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{r.label}</span>
                {r.link
                  ? <a href={r.link} className="text-xs font-semibold" style={{ color: 'var(--neon)' }}>{r.value}</a>
                  : <span className="text-xs font-semibold" style={{ color: 'var(--color-text)' }}>{r.value}</span>
                }
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
