import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { DataTable, Column } from '../components/DataTable';
import { Button, Input, Select, Textarea, Modal, ConfirmDialog, PageHeader, Badge, Card } from '../components/ui';
import { Plus, ImageIcon, Download, Printer, DollarSign, AlertTriangle, Clock, Calendar, TrendingUp, Users } from 'lucide-react';

/* ══════════════════════════════════════════════════════
   PRODUCTS
══════════════════════════════════════════════════════ */
export function ProductsPage() {
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [data,    setData]    = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal,   setModal]   = useState(false);
  const [viewItem,setViewItem]= useState<any|null>(null);
  const [editId,  setEditId]  = useState<string|null>(null);
  const [delId,   setDelId]   = useState<string|null>(null);
  const [saving,  setSaving]  = useState(false);
  const [form, setForm] = useState({
    name:'', barcode:'', brand:'', description:'', unit:'piece',
    cost_price:'', selling_price:'', min_stock:'0', image_url:'',
  });

  const load = async () => {
    setLoading(true);
    try {
      const { data: rows, error } = await supabase.from('products').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      setData(rows || []);
    } catch (e: any) {
      toast(e.message || 'Failed to load products', 'error');
    }
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const emptyForm = () => setForm({ name:'', barcode:'', brand:'', description:'', unit:'piece', cost_price:'', selling_price:'', min_stock:'0', image_url:'' });

  const openAdd  = () => { emptyForm(); setEditId(null); setModal(true); };
  const openEdit = (r: any) => {
    setForm({ name:r.name||'', barcode:r.barcode||'', brand:r.brand||'', description:r.description||'', unit:r.unit||'piece', cost_price:String(r.cost_price||''), selling_price:String(r.selling_price||''), min_stock:String(r.min_stock||'0'), image_url:r.image_url||'' });
    setEditId(r.id); setModal(true);
  };

  const save = async () => {
    if (!form.name.trim()) { toast(isAr?'الاسم مطلوب':'Name is required','warning'); return; }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        barcode:        form.barcode || null,
        brand:          form.brand || null,
        description:    form.description || null,
        unit:           form.unit || 'piece',
        cost_price:     form.cost_price     ? parseFloat(form.cost_price)     : null,
        selling_price:  form.selling_price  ? parseFloat(form.selling_price)  : null,
        min_stock:      form.min_stock      ? parseInt(form.min_stock)        : 0,
        image_url:      form.image_url || null,
        ...(editId ? {} : { product_code: `PRD-${Date.now().toString().slice(-6)}` }),
      };
      const { error } = editId
        ? await supabase.from('products').update(payload).eq('id', editId)
        : await supabase.from('products').insert([payload]);
      if (error) throw error;
      toast(editId?(isAr?'تم التحديث ✓':'Updated ✓'):(isAr?'تمت الإضافة ✓':'Product added ✓'),'success');
      setModal(false); load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setSaving(false);
  };

  const del = async () => {
    if (!delId) return;
    try {
      const { error } = await supabase.from('products').delete().eq('id', delId);
      if (error) throw error;
      toast(isAr?'تم الحذف ✓':'Deleted ✓','success'); load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setDelId(null);
  };

  const cols: Column<any>[] = [
    { key:'image_url', label:isAr?'صورة':'Image', width:'60px',
      render: r => (
        <div className="w-10 h-10 rounded-lg overflow-hidden flex items-center justify-center" style={{ background:'var(--color-bg-surface)', border:'1px solid var(--color-border)' }}>
          {r.image_url
            ? <img src={r.image_url} alt={r.name} className="w-full h-full object-cover" onError={e=>{(e.target as any).style.display='none';}} />
            : <ImageIcon size={16} style={{ color:'var(--color-text-muted)' }} />
          }
        </div>
      )},
    { key:'product_code',  label:isAr?'الكود':'Code',  render:r=><span className="font-mono text-xs" style={{color:'var(--neon)'}}>{r.product_code||'—'}</span> },
    { key:'name',          label:isAr?'الاسم':'Name',   render:r=><span className="font-semibold">{r.name}</span> },
    { key:'brand',         label:isAr?'العلامة':'Brand' },
    { key:'unit',          label:isAr?'الوحدة':'Unit' },
    { key:'cost_price',    label:isAr?'سعر التكلفة':'Cost',  render:r=>`EGP ${r.cost_price||0}` },
    { key:'selling_price', label:isAr?'سعر البيع':'Price',   render:r=><span className="font-bold" style={{color:'var(--neon)'}}>EGP {r.selling_price||0}</span> },
    { key:'min_stock',     label:isAr?'الحد الأدنى':'Min Stock' },
  ];

  return (
    <div>
      <PageHeader title={isAr?'المنتجات':'Products'} subtitle={isAr?`${data.length} منتج`:`${data.length} products`}
        action={<Button icon={Plus} onClick={openAdd}>{isAr?'إضافة منتج':'Add Product'}</Button>} />
      <DataTable data={data} columns={cols} loading={loading}
        onAdd={openAdd} onEdit={openEdit} onDelete={r=>setDelId(r.id)} onView={r=>setViewItem(r)}
        searchKeys={['name','brand','barcode','product_code']}
        emptyTitle={isAr?'لا توجد منتجات':'No products yet'}
        emptyDescription={isAr?'ابدأ بإضافة أول منتج':'Add your first product'} />

      <Modal open={modal} onClose={()=>setModal(false)} size="lg"
        title={editId?(isAr?'تعديل منتج':'Edit Product'):(isAr?'إضافة منتج':'Add Product')}>
        <div className="space-y-4">
          {form.image_url && (
            <div className="w-full h-44 rounded-xl overflow-hidden" style={{background:'var(--color-bg-surface)',border:'1px solid var(--color-border)'}}>
              <img src={form.image_url} alt="preview" className="w-full h-full object-contain" onError={e=>{(e.target as any).style.display='none';}} />
            </div>
          )}
          <Input label={isAr?'رابط الصورة':'Image URL'} value={form.image_url} onChange={e=>setForm({...form,image_url:e.target.value})} placeholder="https://..." />
          <div className="grid grid-cols-2 gap-4">
            <Input label={isAr?'اسم المنتج *':'Product Name *'} value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
            <Input label={isAr?'باركود':'Barcode'} value={form.barcode} onChange={e=>setForm({...form,barcode:e.target.value})} />
            <Input label={isAr?'العلامة التجارية':'Brand'} value={form.brand} onChange={e=>setForm({...form,brand:e.target.value})} />
            <Input label={isAr?'وحدة القياس':'Unit'} value={form.unit} onChange={e=>setForm({...form,unit:e.target.value})} />
            <Input label={isAr?'سعر التكلفة (EGP)':'Cost Price (EGP)'} type="number" min="0" value={form.cost_price} onChange={e=>setForm({...form,cost_price:e.target.value})} />
            <Input label={isAr?'سعر البيع (EGP)':'Selling Price (EGP)'} type="number" min="0" value={form.selling_price} onChange={e=>setForm({...form,selling_price:e.target.value})} />
            <Input label={isAr?'الحد الأدنى للمخزون':'Min Stock Alert'} type="number" min="0" value={form.min_stock} onChange={e=>setForm({...form,min_stock:e.target.value})} />
          </div>
          <Textarea label={isAr?'وصف المنتج':'Description'} value={form.description} onChange={e=>setForm({...form,description:e.target.value})} rows={2} />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={()=>setModal(false)}>{isAr?'إلغاء':'Cancel'}</Button>
            <Button onClick={save} loading={saving}>{isAr?'حفظ':'Save'}</Button>
          </div>
        </div>
      </Modal>

      <Modal open={!!viewItem} onClose={()=>setViewItem(null)} title={isAr?'تفاصيل المنتج':'Product Details'} size="md">
        {viewItem && (
          <div>
            {viewItem.image_url && <img src={viewItem.image_url} alt={viewItem.name} className="w-full h-44 object-contain rounded-xl mb-4" style={{background:'var(--color-bg-surface)'}} onError={e=>{(e.target as any).style.display='none';}} />}
            {[['Code',viewItem.product_code],['Name',viewItem.name],['Brand',viewItem.brand],['Barcode',viewItem.barcode],['Unit',viewItem.unit],['Cost',`EGP ${viewItem.cost_price||0}`],['Price',`EGP ${viewItem.selling_price||0}`],['Min Stock',viewItem.min_stock],['Description',viewItem.description]].map(([l,v])=>v?(
              <div key={l as string} className="flex justify-between py-2" style={{borderBottom:'1px solid var(--color-border)'}}>
                <span className="text-xs" style={{color:'var(--color-text-muted)'}}>{l}</span>
                <span className="text-xs font-semibold" style={{color:'var(--color-text)'}}>{v}</span>
              </div>
            ):null)}
            <div className="flex gap-3 mt-4">
              <Button size="sm" onClick={()=>{setViewItem(null);openEdit(viewItem);}}>{isAr?'تعديل':'Edit'}</Button>
              <Button size="sm" variant="danger" onClick={()=>{setViewItem(null);setDelId(viewItem.id);}}>{isAr?'حذف':'Delete'}</Button>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog open={!!delId} onClose={()=>setDelId(null)} onConfirm={del}
        title={isAr?'حذف منتج':'Delete Product'}
        message={isAr?'هل أنت متأكد من حذف هذا المنتج؟':'Delete this product permanently?'} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   ATTENDANCE - Enhanced with Late Minutes & Working Hours
══════════════════════════════════════════════════════ */
export function AttendancePage() {
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [data,       setData]     = useState<any[]>([]);
  const [loading,   setLoading]   = useState(true);
  const [modal,      setModal]     = useState(false);
  const [editId,     setEditId]    = useState<string|null>(null);
  const [delId,      setDelId]     = useState<string|null>(null);
  const [saving,     setSaving]    = useState(false);
  const [statusF,    setStatusF]   = useState('');
  const [dateF,      setDateF]     = useState('');
  const todayStr = new Date().toISOString().split('T')[0];
  const [form, setForm] = useState({
    employee_id:'', employee_name: '', date:todayStr, check_in:'', check_out:'',
    status:'present', notes:'', shift_start: '09:00', shift_end: '17:00'
  });

  const load = async () => {
    setLoading(true);
    try {
      const attRes = await supabase.from('attendance').select('*').order('date', { ascending: false });
      if (attRes.error) throw attRes.error;
      setData(attRes.data || []);
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  // Calculate late minutes and working hours
  const calcHours = (checkIn: string, checkOut: string, shiftStart: string) => {
    if (!checkIn || !checkOut) return { lateMinutes: 0, workingHours: 0 };
    const [inH, inM] = checkIn.split(':').map(Number);
    const [outH, outM] = checkOut.split(':').map(Number);
    const [shiftH, shiftM] = shiftStart.split(':').map(Number);

    const inMinutes = inH * 60 + inM;
    const outMinutes = outH * 60 + outM;
    const shiftMinutes = shiftH * 60 + shiftM;

    const lateMinutes = Math.max(0, inMinutes - shiftMinutes);
    const workingMinutes = Math.max(0, outMinutes - inMinutes);

    return {
      lateMinutes,
      workingHours: Number((workingMinutes / 60).toFixed(2))
    };
  };

  const openAdd  = () => {
    setForm({ employee_id:'', employee_name: '', date:todayStr, check_in:'', check_out:'', status:'present', notes:'', shift_start: '09:00', shift_end: '17:00' });
    setEditId(null);
    setModal(true);
  };

  const openEdit = (r: any) => {
    setForm({
      employee_id: r.employee_id || '',
      employee_name: r.employee_name || '',
      date: r.date || todayStr,
      check_in: r.check_in || '',
      check_out: r.check_out || '',
      status: r.status || 'present',
      notes: r.notes || '',
      shift_start: r.shift_start || '09:00',
      shift_end: r.shift_end || '17:00'
    });
    setEditId(r.id);
    setModal(true);
  };

  const save = async () => {
    if (!form.employee_id.trim() && !form.employee_name.trim()) {
      toast(isAr?'رقم أو اسم الموظف مطلوب':'Employee ID or name is required','warning');
      return;
    }
    setSaving(true);

    const { lateMinutes, workingHours } = calcHours(form.check_in, form.check_out, form.shift_start);

    try {
      const payload = {
        employee_id: form.employee_id.trim() || null,
        employee_name: form.employee_name || null,
        date: form.date || todayStr,
        check_in:  form.check_in  || null,
        check_out: form.check_out || null,
        check_in_time: form.check_in || null,
        check_out_time: form.check_out || null,
        shift_start: form.shift_start || '09:00',
        shift_end: form.shift_end || '17:00',
        late_minutes: lateMinutes,
        working_hours: workingHours,
        status: form.status || 'present',
        notes: form.notes || null,
      };

      const { error } = editId
        ? await supabase.from('attendance').update(payload).eq('id', editId)
        : await supabase.from('attendance').insert([payload]);
      if (error) throw error;
      toast(isAr?'تم الحفظ ✓':'Saved ✓','success');
      setModal(false);
      load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setSaving(false);
  };

  const del = async () => {
    if (!delId) return;
    try {
      const { error } = await supabase.from('attendance').delete().eq('id', delId);
      if (error) throw error;
      toast(isAr?'تم الحذف ✓':'Deleted ✓','success');
      load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setDelId(null);
  };

  const exportReport = () => {
    const list = (statusF ? data.filter(d => d.status === statusF) : data)
      .filter(d => !dateF || d.date === dateF);
    const present  = list.filter(r => r.status==='present').length;
    const absent   = list.filter(r => r.status==='absent').length;
    const late     = list.filter(r => r.status==='late' || (r.late_minutes && r.late_minutes > 0)).length;
    const totalLateMinutes = list.reduce((s,r) => s + (r.late_minutes || 0), 0);
    const totalWorkingHours = list.reduce((s,r) => s + (r.working_hours || 0), 0);

    const w = window.open('','_blank');
    if (!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Attendance Report</title><style>
      body{font-family:Arial,sans-serif;padding:20px;color:#0D1526}h1{color:#0099BB;border-bottom:3px solid #00D4FF;padding-bottom:8px}
      .summary{display:flex;gap:16px;margin:16px 0;flex-wrap:wrap}
      .kpi{padding:12px 20px;border-radius:8px;text-align:center;font-size:13px;flex:1;min-width:120px}
      table{width:100%;border-collapse:collapse;margin-top:16px;font-size:12px}
      th{background:#0D1526;color:white;padding:10px;text-align:left}td{padding:8px;border-bottom:1px solid #eee}
      .present{background:#dcfce7;color:#166534} .absent{background:#fee2e2;color:#991b1b} .late{background:#fef9c3;color:#854d0e}
      @media print{body{padding:10px}}
    </style></head><body>
    <h1>REFORM FITNESS — Attendance Report</h1>
    <p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString()} | Total Records: ${list.length}</p>
    <div class="summary">
      <div class="kpi present"><strong>${present}</strong><br>Present</div>
      <div class="kpi absent"><strong>${absent}</strong><br>Absent</div>
      <div class="kpi late"><strong>${late}</strong><br>Late Arrivals</div>
      <div class="kpi" style="background:#e0f2fe;color:#0369a1"><strong>${totalLateMinutes}</strong><br>Total Late Minutes</div>
      <div class="kpi" style="background:#f0fdf4;color:#166534"><strong>${totalWorkingHours.toFixed(1)}</strong><br>Total Working Hours</div>
    </div>
    <table><thead><tr><th>Employee</th><th>Date</th><th>Check In</th><th>Check Out</th><th>Late (min)</th><th>Hours</th><th>Status</th><th>Notes</th></tr></thead>
    <tbody>${list.map(r=>`<tr>
      <td>${r.employee_name || r.employee_id}</td>
      <td>${r.date}</td>
      <td>${r.check_in||'—'}</td>
      <td>${r.check_out||'—'}</td>
      <td>${r.late_minutes||0}</td>
      <td>${r.working_hours||0}</td>
      <td>${r.status}</td>
      <td>${r.notes||''}</td>
    </tr>`).join('')}</tbody></table></body></html>`);
    w.document.close();
    w.print();
  };

  const exportCSV = () => {
    const list = (statusF ? data.filter(d => d.status === statusF) : data)
      .filter(d => !dateF || d.date === dateF);
    const rows = [
      ['Employee','Date','Check In','Check Out','Late Minutes','Working Hours','Status','Notes'],
      ...list.map(r => [r.employee_name || r.employee_id, r.date, r.check_in||'', r.check_out||'', r.late_minutes||0, r.working_hours||0, r.status, r.notes||''])
    ];
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance_report_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const displayed = (statusF ? data.filter(d => d.status === statusF) : data)
    .filter(d => !dateF || d.date === dateF);

  const stats = {
    present: data.filter(r => r.status === 'present').length,
    absent: data.filter(r => r.status === 'absent').length,
    late: data.filter(r => r.status === 'late' || (r.late_minutes && r.late_minutes > 0)).length,
    totalHours: data.reduce((s, r) => s + (r.working_hours || 0), 0).toFixed(1),
    totalLateMin: data.reduce((s, r) => s + (r.late_minutes || 0), 0)
  };

  const cols: Column<any>[] = [
    { key:'employee_id', label:isAr?'الموظف':'Employee',
      render: r => <div>
        <span className="font-semibold text-sm">{r.employee_name || r.employee_id}</span>
        {r.employee_name && r.employee_id && <span className="text-xs block" style={{color:'var(--color-text-muted)'}}>{r.employee_id}</span>}
      </div> },
    { key:'date',        label:isAr?'التاريخ':'Date' },
    { key:'check_in',    label:isAr?'الحضور':'Check In' },
    { key:'check_out',   label:isAr?'الانصراف':'Check Out' },
    { key:'late_minutes',label:isAr?'التأخير (دقائق)':'Late (min)',
      render: r => <span className={r.late_minutes > 0 ? 'font-bold' : ''} style={{color: r.late_minutes > 0 ? 'var(--color-danger)' : 'var(--color-text)'}}>
        {r.late_minutes || 0}
      </span> },
    { key:'working_hours', label:isAr?'ساعات العمل':'Hours',
      render: r => <span className="font-bold" style={{color:'var(--neon)'}}>{r.working_hours || 0}</span> },
    { key:'status',      label:isAr?'الحالة':'Status',
      render:r=><Badge color={r.status==='present'?'success':r.status==='absent'?'danger':r.status==='late'?'warning':'info'}>{r.status}</Badge> },
    { key:'notes',       label:isAr?'ملاحظات':'Notes', render:r=><span className="text-xs">{r.notes||'—'}</span> },
  ];

  return (
    <div>
      <PageHeader title={isAr?'الحضور والانصراف':'Attendance'}
        subtitle={isAr?`${data.length} سجل`:`${data.length} records`}
        action={<div className="flex gap-2 flex-wrap">
          <Button variant="secondary" size="sm" icon={Download} onClick={exportCSV}>{isAr?'تصدير CSV':'CSV'}</Button>
          <Button variant="secondary" size="sm" icon={Printer} onClick={exportReport}>{isAr?'طباعة':'Print'}</Button>
          <Button icon={Plus} onClick={openAdd}>{isAr?'تسجيل':'Record'}</Button>
        </div>} />

      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        {[
          { label: isAr?'حاضر':'Present', value: stats.present, color: '#22C55E', icon: Users },
          { label: isAr?'غائب':'Absent', value: stats.absent, color: '#EF4444', icon: AlertTriangle },
          { label: isAr?'متأخر':'Late', value: stats.late, color: '#F59E0B', icon: Clock },
          { label: isAr?'ساعات العمل':'Work Hours', value: stats.totalHours, color: '#00D4FF', icon: Clock },
          { label: isAr?'دقائق التأخير':'Late Min', value: stats.totalLateMin, color: '#A78BFA', icon: AlertTriangle },
        ].map((s,i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="rf-card-glow stat-card p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{ background: `${s.color}18`, border: `1px solid ${s.color}30` }}>
                  <Icon size={16} style={{ color: s.color }} />
                </div>
                <span className="text-xl font-extrabold" style={{ color: 'var(--color-text)' }}>{s.value}</span>
              </div>
              <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{s.label}</p>
            </div>
          );
        })}
      </div>

      <DataTable data={displayed} columns={cols} loading={loading}
        onAdd={openAdd} onEdit={openEdit} onDelete={r=>setDelId(r.id)}
        searchKeys={['employee_id','employee_name','date','status']}
        filters={[
          { label:'Status', value:statusF, onChange:setStatusF, options:[
            {value:'present',label:'Present'},{value:'absent',label:'Absent'},{value:'late',label:'Late'},{value:'leave',label:'Leave'},{value:'holiday',label:'Holiday'}
          ]},
          { label: 'Date', value: dateF, onChange: setDateF, type: 'date' }
        ]}
        emptyTitle={isAr?'لا سجلات حضور':'No attendance records'}
        emptyDescription={isAr?'سجّل حضور الموظفين':'Record employee attendance'} />

      <Modal open={modal} onClose={()=>setModal(false)} size="lg"
        title={editId?(isAr?'تعديل سجل الحضور':'Edit Attendance'):(isAr?'تسجيل حضور':'Record Attendance')}>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <Input label={isAr?'كود الموظف':'Employee Code'} value={form.employee_id}
              onChange={e=>setForm({...form,employee_id:e.target.value})} placeholder="EMP-00001" />
          </div>
          <Input label={isAr?'اسم الموظف':'Employee Name'} value={form.employee_name}
            onChange={e=>setForm({...form,employee_name:e.target.value})} placeholder={isAr?'الاسم الرباعي':'Full name'} />
          <Input label={isAr?'التاريخ':'Date'} type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} />
          <Input label={isAr?'وقت الحضور':'Check In'} type="time" value={form.check_in} onChange={e=>setForm({...form,check_in:e.target.value})} />
          <Input label={isAr?'وقت الانصراف':'Check Out'} type="time" value={form.check_out} onChange={e=>setForm({...form,check_out:e.target.value})} />
          <Input label={isAr?'بداية الوردية':'Shift Start'} type="time" value={form.shift_start} onChange={e=>setForm({...form,shift_start:e.target.value})} />
          <Input label={isAr?'نهاية الوردية':'Shift End'} type="time" value={form.shift_end} onChange={e=>setForm({...form,shift_end:e.target.value})} />
          <Select label={isAr?'الحالة':'Status'} value={form.status} onChange={e=>setForm({...form,status:e.target.value})}>
            <option value="present">{isAr?'حاضر':'Present'}</option>
            <option value="absent">{isAr?'غائب':'Absent'}</option>
            <option value="late">{isAr?'متأخر':'Late'}</option>
            <option value="leave">{isAr?'إجازة':'Leave'}</option>
            <option value="holiday">{isAr?'عطلة':'Holiday'}</option>
          </Select>
          {/* Calculate preview */}
          {form.check_in && form.check_out && (
            <div className="col-span-2 p-4 rounded-xl" style={{background:'rgba(0,212,255,0.08)',border:'1px solid rgba(0,212,255,0.2)'}}>
              {(() => {
                const { lateMinutes, workingHours } = calcHours(form.check_in, form.check_out, form.shift_start);
                return (
                  <div className="flex gap-6">
                    <div>
                      <span className="text-xs" style={{color:'var(--color-text-muted)'}}>{isAr?'دقائق التأخير:':'Late Minutes:'}</span>
                      <span className="font-bold ms-1" style={{color: lateMinutes > 0 ? 'var(--color-danger)' : 'var(--color-success)'}}>{lateMinutes}</span>
                    </div>
                    <div>
                      <span className="text-xs" style={{color:'var(--color-text-muted)'}}>{isAr?'ساعات العمل:':'Working Hours:'}</span>
                      <span className="font-bold ms-1" style={{color:'var(--neon)'}}>{workingHours}</span>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}
          <div className="col-span-2"><Textarea label={isAr?'ملاحظات':'Notes'} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} rows={2} /></div>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="secondary" onClick={()=>setModal(false)}>{isAr?'إلغاء':'Cancel'}</Button>
          <Button onClick={save} loading={saving}>{isAr?'حفظ':'Save'}</Button>
        </div>
      </Modal>
      <ConfirmDialog open={!!delId} onClose={()=>setDelId(null)} onConfirm={del}
        title={isAr?'حذف سجل':'Delete Record'} message={isAr?'حذف هذا السجل؟':'Delete this record?'} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   PAYROLL - Enhanced with Penalties & Exports
══════════════════════════════════════════════════════ */
export function PayrollPage() {
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [data,         setData]       = useState<any[]>([]);
  const [loading,      setLoading]    = useState(true);
  const [modal,        setModal]      = useState(false);
  const [penaltyModal, setPenaltyModal] = useState(false);
  const [editId,       setEditId]     = useState<string|null>(null);
  const [delId,        setDelId]      = useState<string|null>(null);
  const [saving,       setSaving]     = useState(false);
  const [viewItem,     setViewItem]   = useState<any|null>(null);
  const now = new Date();
  const todayStr = new Date().toISOString().split('T')[0];
  const [form, setForm] = useState({
    employee_id:'', employee_name:'', period_month: now.getMonth()+1, period_year: now.getFullYear(),
    base_salary:'', bonuses:'0', commissions:'0', deductions:'0',
    late_deductions:'0', absence_deductions:'0', other_penalties:'0', rewards:'0',
    loans:'0', advances:'0', overtime:'0', late_minutes:0, absent_days:0, working_days:22,
    net_salary:'', status:'pending', notes:'',
  });
  const [penaltyForm, setPenaltyForm] = useState({
    employee_id:'', type:'penalty', amount:'', reason:'', reference_date: todayStr, month: now.getMonth()+1, year: now.getFullYear()
  });

  const load = async () => {
    setLoading(true);
    try {
      const payRes = await supabase.from('payroll').select('*').order('created_at', { ascending: false });
      if (payRes.error) throw payRes.error;
      setData(payRes.data || []);
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const calcNet = (f: typeof form) => {
    const base   = parseFloat(String(f.base_salary))||0;
    const plus   = (parseFloat(String(f.bonuses))||0) + (parseFloat(String(f.commissions))||0) +
                   (parseFloat(String(f.overtime))||0) + (parseFloat(String(f.rewards))||0);
    const minus = (parseFloat(String(f.deductions))||0) + (parseFloat(String(f.loans))||0) +
                   (parseFloat(String(f.advances))||0) + (parseFloat(String(f.late_deductions))||0) +
                   (parseFloat(String(f.absence_deductions))||0) + (parseFloat(String(f.other_penalties))||0);
    return +(base+plus-minus).toFixed(2);
  };

  const up = (k: string, v: any) => setForm(p => {
    const next = {...p,[k]:v};
    return {...next, net_salary: String(calcNet(next))};
  });

  const openAdd  = () => {
    setForm({
      employee_id:'', employee_name:'', period_month:now.getMonth()+1, period_year:now.getFullYear(),
      base_salary:'', bonuses:'0', commissions:'0', deductions:'0',
      late_deductions:'0', absence_deductions:'0', other_penalties:'0', rewards:'0',
      loans:'0', advances:'0', overtime:'0', late_minutes:0, absent_days:0, working_days:22,
      net_salary:'0', status:'pending', notes:''
    });
    setEditId(null);
    setModal(true);
  };

  const openEdit = (r: any) => {
    setForm({
      employee_id: r.employee_id||'',
      employee_name: r.employee_name||'',
      period_month: r.period_month||now.getMonth()+1,
      period_year: r.period_year||now.getFullYear(),
      base_salary: String(r.base_salary||''),
      bonuses: String(r.bonuses||'0'),
      commissions: String(r.commissions||'0'),
      deductions: String(r.deductions||'0'),
      late_deductions: String(r.late_deductions||'0'),
      absence_deductions: String(r.absence_deductions||'0'),
      other_penalties: String(r.other_penalties||'0'),
      rewards: String(r.rewards||'0'),
      loans: String(r.loans||'0'),
      advances: String(r.advances||'0'),
      overtime: String(r.overtime||'0'),
      late_minutes: r.late_minutes||0,
      absent_days: r.absent_days||0,
      working_days: r.working_days||22,
      net_salary: String(r.net_salary||'0'),
      status: r.status||'pending',
      notes: r.notes||''
    });
    setEditId(r.id);
    setModal(true);
  };

  const save = async () => {
    if (!form.employee_id.trim() && !form.employee_name.trim()) {
      toast(isAr?'رقم أو اسم الموظف مطلوب':'Employee ID or name required','warning');
      return;
    }
    setSaving(true);
    const net = calcNet(form);
    try {
      const payload = {
        employee_id:    form.employee_id.trim() || null,
        employee_name:  form.employee_name || null,
        period_month:   Number(form.period_month),
        period_year:    Number(form.period_year),
        base_salary:    parseFloat(String(form.base_salary))||0,
        bonuses:        parseFloat(String(form.bonuses))||0,
        commissions:    parseFloat(String(form.commissions))||0,
        deductions:     parseFloat(String(form.deductions))||0,
        late_deductions: parseFloat(String(form.late_deductions))||0,
        absence_deductions: parseFloat(String(form.absence_deductions))||0,
        other_penalties: parseFloat(String(form.other_penalties))||0,
        rewards:        parseFloat(String(form.rewards))||0,
        loans:          parseFloat(String(form.loans))||0,
        advances:       parseFloat(String(form.advances))||0,
        overtime:       parseFloat(String(form.overtime))||0,
        late_minutes:   parseInt(String(form.late_minutes))||0,
        absent_days:     parseInt(String(form.absent_days))||0,
        working_days:    parseInt(String(form.working_days))||22,
        net_salary:     net,
        status:         form.status||'pending',
        notes:          form.notes||null,
      };
      const { error } = editId
        ? await supabase.from('payroll').update(payload).eq('id', editId)
        : await supabase.from('payroll').insert([payload]);
      if (error) throw error;
      toast(isAr?'تم الحفظ ✓':'Saved ✓','success');
      setModal(false);
      load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setSaving(false);
  };

  const del = async () => {
    if (!delId) return;
    try {
      const { error } = await supabase.from('payroll').delete().eq('id', delId);
      if (error) throw error;
      toast(isAr?'تم الحذف ✓':'Deleted ✓','success');
      load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setDelId(null);
  };

  const openPenaltyModal = () => {
    setPenaltyForm({ employee_id:'', type:'penalty', amount:'', reason:'', reference_date: todayStr, month: now.getMonth()+1, year: now.getFullYear() });
    setPenaltyModal(true);
  };

  const savePenalty = async () => {
    if (!penaltyForm.employee_id || !penaltyForm.amount) {
      toast(isAr?'جميع الحقول مطلوبة':'All fields required','warning');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        employee_id: penaltyForm.employee_id,
        type: penaltyForm.type,
        amount: parseFloat(penaltyForm.amount),
        reason: penaltyForm.reason || null,
        reference_date: penaltyForm.reference_date,
        month: penaltyForm.month,
        year: penaltyForm.year,
        status: 'applied'
      };
      const { error } = await supabase.from('employee_penalties').insert([payload]);
      if (error) throw error;
      toast(isAr?'تم الحفظ ✓':'Saved ✓','success');
      setPenaltyModal(false);
      load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setSaving(false);
  };

  // Export functions
  const exportPDF = () => {
    const total = data.reduce((s,r)=>s+(r.net_salary||0),0);
    const totalBase = data.reduce((s,r)=>s+(r.base_salary||0),0);
    const totalPenalties = data.reduce((s,r)=>s+(r.late_deductions||0)+(r.absence_deductions||0)+(r.other_penalties||0),0);
    const totalRewards = data.reduce((s,r)=>s+(r.rewards||0)+(r.bonuses||0)+(r.commissions||0),0);

    const w = window.open('','_blank');
    if(!w) return;
    w.document.write(`<!DOCTYPE html><html><head><title>Payroll Report</title><style>
      body{font-family:Arial,sans-serif;padding:20px;color:#0D1526}
      h1{color:#0099BB;border-bottom:3px solid #00D4FF;padding-bottom:8px}
      .summary{display:flex;gap:16px;margin:16px 0;flex-wrap:wrap}
      .kpi{padding:12px 20px;border-radius:8px;text-align:center;font-size:13px;flex:1;min-width:140px}
      table{width:100%;border-collapse:collapse;font-size:11px;margin-top:16px}
      th{background:#0D1526;color:white;padding:8px;text-align:left}td{padding:6px;border-bottom:1px solid #eee}
      .total{font-weight:bold;background:#f0f8ff}.paid{color:#166534}.pending{color:#854d0e}
      @media print{body{padding:10px}}
    </style></head><body>
    <h1>REFORM FITNESS — Payroll Report</h1>
    <p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString()}</p>
    <div class="summary">
      <div class="kpi" style="background:#dcfce7;color:#166534"><strong>EGP ${totalBase.toLocaleString()}</strong><br>Base Salaries</div>
      <div class="kpi" style="background:#f0fdf4;color:#166534"><strong>EGP ${totalRewards.toLocaleString()}</strong><br>Rewards & Bonuses</div>
      <div class="kpi" style="background:#fee2e2;color:#991b1b"><strong>EGP ${totalPenalties.toLocaleString()}</strong><br>Penalties & Deductions</div>
      <div class="kpi" style="background:#e0f2fe;color:#0369a1"><strong>EGP ${total.toLocaleString()}</strong><br>Net Total</div>
    </div>
    <table><thead><tr><th>Employee</th><th>Month</th><th>Year</th><th>Base</th><th>Bonus</th><th>Rewards</th><th>Late Ded.</th><th>Abs. Ded.</th><th>Penalties</th><th>Net</th><th>Status</th></tr></thead>
    <tbody>
      ${data.map(r=>`<tr>
        <td>${r.employee_name || r.employee_id}</td>
        <td>${r.period_month}</td>
        <td>${r.period_year}</td>
        <td>EGP ${r.base_salary||0}</td>
        <td>EGP ${r.bonuses||0}</td>
        <td>EGP ${r.rewards||0}</td>
        <td>EGP ${r.late_deductions||0}</td>
        <td>EGP ${r.absence_deductions||0}</td>
        <td>EGP ${r.other_penalties||0}</td>
        <td class="${r.status}">EGP ${r.net_salary||0}</td>
        <td>${r.status}</td>
      </tr>`).join('')}
      <tr class="total"><td colspan="9" style="text-align:right;padding-right:8px">Total Net Salaries:</td><td>EGP ${total.toLocaleString()}</td><td></td></tr>
    </tbody></table></body></html>`);
    w.document.close();
    w.print();
  };

  const exportCSV = () => {
    const rows = [
      ['Employee','Month','Year','Base Salary','Bonuses','Commissions','Rewards','Late Deductions','Absence Deductions','Other Penalties','Loans','Advances','Overtime','Net Salary','Status'],
      ...data.map(r => [
        r.employee_name || r.employee_id, r.period_month, r.period_year,
        r.base_salary||0, r.bonuses||0, r.commissions||0, r.rewards||0,
        r.late_deductions||0, r.absence_deductions||0, r.other_penalties||0,
        r.loans||0, r.advances||0, r.overtime||0, r.net_salary||0, r.status
      ])
    ];
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `payroll_report_${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  // Summary statistics
  const stats = {
    total: data.length,
    totalNet: data.reduce((s,r)=>s+(r.net_salary||0),0),
    totalPenalties: data.reduce((s,r)=>s+(r.late_deductions||0)+(r.absence_deductions||0)+(r.other_penalties||0),0),
    totalRewards: data.reduce((s,r)=>s+(r.rewards||0)+(r.bonuses||0),0),
    paid: data.filter(r=>r.status==='paid').length,
    pending: data.filter(r=>r.status==='pending').length
  };

  const cols: Column<any>[] = [
    { key:'employee_id',  label:isAr?'الموظف':'Employee',
      render: r => <div>
        <span className="font-semibold text-sm">{r.employee_name || r.employee_id}</span>
        {r.employee_name && r.employee_id && <span className="text-xs block" style={{color:'var(--color-text-muted)'}}>{r.employee_id}</span>}
      </div> },
    { key:'period', label:isAr?'الفترة':'Period',
      render: r => `${r.period_month}/${r.period_year}` },
    { key:'base_salary',  label:isAr?'الراتب الأساسي':'Base', render:r=>`EGP ${r.base_salary||0}` },
    { key:'bonuses',      label:isAr?'المكافآت':'Bonus', render:r=>`EGP ${r.bonuses||0}` },
    { key:'rewards',      label:isAr?'المكافآت':'Rewards', render:r=><span style={{color:'#22C55E'}}>EGP {r.rewards||0}</span> },
    { key:'penalties',    label:isAr?'الخصومات':'Deductions',
      render: r => {
        const total = (r.late_deductions||0)+(r.absence_deductions||0)+(r.other_penalties||0)+(r.deductions||0);
        return <span style={{color: total > 0 ? 'var(--color-danger)' : 'var(--color-text)'}}>EGP {total}</span>;
      }},
    { key:'net_salary',   label:isAr?'صافي الراتب':'Net Salary',
      render:r=><span className="font-bold" style={{color:'var(--neon)'}}>EGP {r.net_salary||0}</span> },
    { key:'status',       label:isAr?'الحالة':'Status',
      render:r=><Badge color={r.status==='paid'?'success':r.status==='approved'?'info':'warning'}>{r.status}</Badge> },
  ];

  return (
    <div>
      <PageHeader title={isAr?'الرواتب':'Payroll'}
        subtitle={isAr?`إجمالي صافي: EGP ${stats.totalNet.toLocaleString()}`:`Total net: EGP ${stats.totalNet.toLocaleString()}`}
        action={<div className="flex gap-2 flex-wrap">
          <Button variant="secondary" size="sm" icon={Download} onClick={exportCSV}>{isAr?'تصدير CSV':'CSV'}</Button>
          <Button variant="secondary" size="sm" icon={Printer} onClick={exportPDF}>{isAr?'طباعة':'Print'}</Button>
          <Button variant="ghost" size="sm" icon={AlertTriangle} onClick={openPenaltyModal}>{isAr?'جزاء':'Penalty'}</Button>
          <Button icon={Plus} onClick={openAdd}>{isAr?'إضافة راتب':'Add Payroll'}</Button>
        </div>} />

      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
        {[
          { label: isAr?'إجمالي الرواتب':'Total Net', value: `EGP ${stats.totalNet.toLocaleString()}`, color: '#00D4FF', icon: DollarSign },
          { label: isAr?'الخصومات':'Penalties', value: `EGP ${stats.totalPenalties.toLocaleString()}`, color: '#EF4444', icon: AlertTriangle },
          { label: isAr?'المكافآت':'Rewards', value: `EGP ${stats.totalRewards.toLocaleString()}`, color: '#22C55E', icon: TrendingUp },
          { label: isAr?'مدفوعة':'Paid', value: stats.paid, color: '#22C55E', icon: Calendar },
          { label: isAr?'معلقة':'Pending', value: stats.pending, color: '#F59E0B', icon: Clock },
        ].map((s,i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="rf-card-glow stat-card p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{ background: `${s.color}18`, border: `1px solid ${s.color}30` }}>
                  <Icon size={16} style={{ color: s.color }} />
                </div>
              </div>
              <p className="text-lg font-extrabold" style={{ color: 'var(--color-text)' }}>{s.value}</p>
              <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{s.label}</p>
            </div>
          );
        })}
      </div>

      <DataTable data={data} columns={cols} loading={loading}
        onAdd={openAdd} onEdit={openEdit} onDelete={r=>setDelId(r.id)} onView={r=>setViewItem(r)}
        searchKeys={['employee_id','employee_name']}
        filters={[{label:'Status',value:'',onChange:()=>{},options:[{value:'pending',label:'Pending'},{value:'approved',label:'Approved'},{value:'paid',label:'Paid'}]}]}
        emptyTitle={isAr?'لا رواتب':'No payroll records'}
        emptyDescription={isAr?'أضف أول سجل راتب':'Add your first payroll entry'} />

      {/* Add/Edit Payroll Modal */}
      <Modal open={modal} onClose={()=>setModal(false)} size="xl"
        title={editId?(isAr?'تعديل راتب':'Edit Payroll'):(isAr?'إضافة راتب':'Add Payroll')}>
        <div className="space-y-4">
          {/* Employee info */}
          <div className="grid grid-cols-3 gap-4">
            <Input label={isAr?'كود الموظف':'Employee Code'} value={form.employee_id}
              onChange={e=>up('employee_id',e.target.value)} placeholder="EMP-00001" />
            <Input label={isAr?'اسم الموظف':'Employee Name'} value={form.employee_name}
              onChange={e=>up('employee_name',e.target.value)} placeholder={isAr?'الاسم':'Name'} />
            <div></div>
            <Input label={isAr?'الشهر':'Month (1-12)'} type="number" min="1" max="12" value={form.period_month} onChange={e=>up('period_month',parseInt(e.target.value)||1)} />
            <Input label={isAr?'السنة':'Year'} type="number" value={form.period_year} onChange={e=>up('period_year',parseInt(e.target.value)||now.getFullYear())} />
            <Input label={isAr?'أيام العمل':'Working Days'} type="number" value={form.working_days} onChange={e=>up('working_days',e.target.value)} />
          </div>

          {/* Salary section */}
          <Card>
            <h4 className="font-bold text-sm mb-3" style={{color:'var(--color-text)'}}>{isAr?'الراتب والمكافآت':'Salary & Rewards'}</h4>
            <div className="grid grid-cols-4 gap-4">
              <Input label={isAr?'الراتب الأساسي (EGP)':'Base Salary (EGP)'} type="number" min="0" value={form.base_salary} onChange={e=>up('base_salary',e.target.value)} />
              <Input label={isAr?'المكافآت (EGP)':'Bonuses (EGP)'} type="number" min="0" value={form.bonuses} onChange={e=>up('bonuses',e.target.value)} />
              <Input label={isAr?'العمولات (EGP)':'Commissions (EGP)'} type="number" min="0" value={form.commissions} onChange={e=>up('commissions',e.target.value)} />
              <Input label={isAr?'العمل الإضافي (EGP)':'Overtime (EGP)'} type="number" min="0" value={form.overtime} onChange={e=>up('overtime',e.target.value)} />
              <Input label={isAr?'المكافآت ':'Rewards'} type="number" min="0" value={form.rewards} onChange={e=>up('rewards',e.target.value)} />
            </div>
          </Card>

          {/* Penalties section */}
          <Card>
            <h4 className="font-bold text-sm mb-3" style={{color:'var(--color-text)'}}>{isAr?'الخصومات والجزاءات':'Deductions & Penalties'}</h4>
            <div className="grid grid-cols-5 gap-4">
              <Input label={isAr?'خصم التأخير':'Late Deductions'} type="number" min="0" value={form.late_deductions} onChange={e=>up('late_deductions',e.target.value)} />
              <Input label={isAr?'خصم الغياب':'Absence Deductions'} type="number" min="0" value={form.absence_deductions} onChange={e=>up('absence_deductions',e.target.value)} />
              <Input label={isAr?'جزاءات أخرى':'Other Penalties'} type="number" min="0" value={form.other_penalties} onChange={e=>up('other_penalties',e.target.value)} />
              <Input label={isAr?'القروض':'Loans'} type="number" min="0" value={form.loans} onChange={e=>up('loans',e.target.value)} />
              <Input label={isAr?'السلف':'Advances'} type="number" min="0" value={form.advances} onChange={e=>up('advances',e.target.value)} />
            </div>
            <div className="grid grid-cols-3 gap-4 mt-3">
              <Input label={isAr?'دقائق التأخير':'Late Minutes'} type="number" min="0" value={form.late_minutes} onChange={e=>up('late_minutes',e.target.value)} />
              <Input label={isAr?'أيام الغياب':'Absent Days'} type="number" min="0" value={form.absent_days} onChange={e=>up('absent_days',e.target.value)} />
              <Input label={isAr?'خصومات أخرى':'Other Deductions'} type="number" min="0" value={form.deductions} onChange={e=>up('deductions',e.target.value)} />
            </div>
          </Card>

          {/* Status */}
          <div className="grid grid-cols-2 gap-4">
            <Select label={isAr?'الحالة':'Status'} value={form.status} onChange={e=>up('status',e.target.value)}>
              <option value="pending">{isAr?'قيد الانتظار':'Pending'}</option>
              <option value="approved">{isAr?'معتمد':'Approved'}</option>
              <option value="paid">{isAr?'مدفوع':'Paid'}</option>
              <option value="cancelled">{isAr?'ملغي':'Cancelled'}</option>
            </Select>
            <Textarea label={isAr?'ملاحظات':'Notes'} value={form.notes} onChange={e=>up('notes',e.target.value)} rows={1} />
          </div>

          {/* Net salary display */}
          <div className="p-5 rounded-xl" style={{background:'linear-gradient(135deg, rgba(0,212,255,0.08), rgba(0,153,187,0.12))',border:'1px solid rgba(0,212,255,0.25)'}}>
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm" style={{color:'var(--color-text-muted)'}}>{isAr?'صافي الراتب المستحق':'Net Salary Due'}</span>
                <p className="text-xs mt-1" style={{color:'var(--color-text-secondary)'}}>
                  {isAr?'الراتب الأساسي + المكافآت + العمولات + العمل الإضافي - الخصومات':'Base + Bonuses + Commissions + Overtime - Deductions'}
                </p>
              </div>
              <span className="text-3xl font-extrabold" style={{color:'var(--neon)'}}>EGP {calcNet(form).toLocaleString()}</span>
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="secondary" onClick={()=>setModal(false)}>{isAr?'إلغاء':'Cancel'}</Button>
          <Button onClick={save} loading={saving}>{isAr?'حفظ':'Save'}</Button>
        </div>
      </Modal>

      {/* Add Penalty Modal */}
      <Modal open={penaltyModal} onClose={()=>setPenaltyModal(false)} title={isAr?'إضافة جزاء/مكافأة':'Add Penalty/Reward'} size="md">
        <div className="space-y-4">
          <Input label={isAr?'كود الموظف':'Employee Code'} value={penaltyForm.employee_id}
            onChange={e=>setPenaltyForm({...penaltyForm,employee_id:e.target.value})} placeholder="EMP-00001" />
          <Select label={isAr?'النوع':'Type'} value={penaltyForm.type} onChange={e=>setPenaltyForm({...penaltyForm,type:e.target.value})}>
            <option value="penalty">{isAr?'جزاء':'Penalty'}</option>
            <option value="reward">{isAr?'مكافأة':'Reward'}</option>
            <option value="bonus">{isAr?'حافز':'Bonus'}</option>
            <option value="late_deduction">{isAr?'خصم تأخير':'Late Deduction'}</option>
            <option value="absence_deduction">{isAr?'خصم غياب':'Absence Deduction'}</option>
            <option value="overtime_bonus">{isAr?'عمل إضافي':'Overtime Bonus'}</option>
          </Select>
          <Input label={isAr?'القيمة (EGP)':'Amount (EGP)'} type="number" value={penaltyForm.amount}
            onChange={e=>setPenaltyForm({...penaltyForm,amount:e.target.value})} />
          <div className="grid grid-cols-2 gap-4">
            <Input label={isAr?'التاريخ':'Date'} type="date" value={penaltyForm.reference_date}
              onChange={e=>setPenaltyForm({...penaltyForm,reference_date:e.target.value})} />
            <Input label={isAr?'الشهر':'Month'} type="number" min="1" max="12" value={penaltyForm.month}
              onChange={e=>setPenaltyForm({...penaltyForm,month:parseInt(e.target.value)||1})} />
          </div>
          <Textarea label={isAr?'السبب':'Reason'} value={penaltyForm.reason}
            onChange={e=>setPenaltyForm({...penaltyForm,reason:e.target.value})} rows={2} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={()=>setPenaltyModal(false)}>{isAr?'إلغاء':'Cancel'}</Button>
            <Button onClick={savePenalty} loading={saving}>{isAr?'حفظ':'Save'}</Button>
          </div>
        </div>
      </Modal>

      {/* View Modal */}
      <Modal open={!!viewItem} onClose={()=>setViewItem(null)} title={isAr?'تفاصيل الراتب':'Payroll Details'} size="lg">
        {viewItem && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl" style={{background:'var(--color-bg-surface)'}}>
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-lg" style={{color:'var(--color-text)'}}>{viewItem.employee_name || viewItem.employee_id}</h3>
                  <p className="text-sm" style={{color:'var(--neon)'}}>{viewItem.period_month}/{viewItem.period_year}</p>
                </div>
                <Badge color={viewItem.status==='paid'?'success':viewItem.status==='approved'?'info':'warning'}>{viewItem.status}</Badge>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <Card>
                <h4 className="font-bold mb-2" style={{color:'var(--color-text)'}}>{isAr?'الإيرادات':'Earnings'}</h4>
                {[
                  [isAr?'الراتب الأساسي':'Base Salary', viewItem.base_salary],
                  [isAr?'المكافآت':'Bonuses', viewItem.bonuses],
                  [isAr?'العمولات':'Commissions', viewItem.commissions],
                  [isAr?'العمل الإضافي':'Overtime', viewItem.overtime],
                  [isAr?'المكافآت ':'Rewards', viewItem.rewards],
                ].map(([l,v]) => v ? (
                  <div key={l as string} className="flex justify-between py-1">
                    <span style={{color:'var(--color-text-muted)'}}>{l}</span>
                    <span style={{color:'#22C55E'}}>EGP {v}</span>
                  </div>
                ) : null)}
              </Card>

              <Card>
                <h4 className="font-bold mb-2" style={{color:'var(--color-text)'}}>{isAr?'الخصومات':'Deductions'}</h4>
                {[
                  [isAr?'خصم التأخير':'Late Deductions', viewItem.late_deductions],
                  [isAr?'خصم الغياب':'Absence Deductions', viewItem.absence_deductions],
                  [isAr?'جزاءات أخرى':'Other Penalties', viewItem.other_penalties],
                  [isAr?'قروض':'Loans', viewItem.loans],
                  [isAr?'سلف':'Advances', viewItem.advances],
                ].map(([l,v]) => v ? (
                  <div key={l as string} className="flex justify-between py-1">
                    <span style={{color:'var(--color-text-muted)'}}>{l}</span>
                    <span style={{color:'var(--color-danger)'}}>EGP {v}</span>
                  </div>
                ) : null)}
              </Card>
            </div>

            <div className="p-4 rounded-xl" style={{background:'rgba(0,212,255,0.08)',border:'1px solid rgba(0,212,255,0.2)'}}>
              <div className="flex justify-between items-center">
                <span className="font-bold" style={{color:'var(--color-text)'}}>{isAr?'صافي الراتب':'Net Salary'}</span>
                <span className="text-2xl font-extrabold" style={{color:'var(--neon)'}}>EGP {viewItem.net_salary}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <Button size="sm" onClick={()=>{setViewItem(null);openEdit(viewItem);}}>{isAr?'تعديل':'Edit'}</Button>
              <Button size="sm" variant="danger" onClick={()=>{setViewItem(null);setDelId(viewItem.id);}}>{isAr?'حذف':'Delete'}</Button>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog open={!!delId} onClose={()=>setDelId(null)} onConfirm={del}
        title={isAr?'حذف راتب':'Delete Payroll'} message={isAr?'حذف هذا السجل؟':'Delete this payroll record?'} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   INVENTORY
══════════════════════════════════════════════════════ */
export function InventoryPage() {
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [data,    setData]    = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal,   setModal]   = useState(false);
  const [editId,  setEditId]  = useState<string|null>(null);
  const [delId,   setDelId]   = useState<string|null>(null);
  const [saving,  setSaving]  = useState(false);
  const [form, setForm] = useState({ product_id:'', quantity:'0', min_quantity:'0', expiry_date:'', batch_number:'' });

  const load = async () => {
    setLoading(true);
    try {
      const { data: rows, error } = await supabase.from('inventory').select('*').order('updated_at', { ascending: false });
      if (error) throw error;
      setData(rows || []);
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const openAdd  = () => { setForm({ product_id:'', quantity:'0', min_quantity:'0', expiry_date:'', batch_number:'' }); setEditId(null); setModal(true); };
  const openEdit = (r: any) => { setForm({ product_id:r.product_id||'', quantity:String(r.quantity||'0'), min_quantity:String(r.min_quantity||'0'), expiry_date:r.expiry_date||'', batch_number:r.batch_number||'' }); setEditId(r.id); setModal(true); };

  const save = async () => {
    if (!form.product_id.trim()) { toast(isAr?'معرف المنتج مطلوب':'Product ID is required','warning'); return; }
    setSaving(true);
    try {
      const payload = {
        product_id:   form.product_id.trim(),
        quantity:     parseInt(form.quantity)||0,
        min_quantity: parseInt(form.min_quantity)||0,
        expiry_date:  form.expiry_date || null,
        batch_number: form.batch_number || null,
        updated_at:   new Date().toISOString(),
      };
      const { error } = editId
        ? await supabase.from('inventory').update(payload).eq('id', editId)
        : await supabase.from('inventory').insert([payload]);
      if (error) throw error;
      toast(isAr?'تم الحفظ ✓':'Saved ✓','success'); setModal(false); load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setSaving(false);
  };

  const del = async () => {
    if (!delId) return;
    try {
      const { error } = await supabase.from('inventory').delete().eq('id', delId);
      if (error) throw error;
      toast(isAr?'تم الحذف ✓':'Deleted ✓','success'); load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setDelId(null);
  };

  const lowStockCount = data.filter(d => (d.quantity||0) <= (d.min_quantity||0) && (d.min_quantity||0) > 0).length;

  const cols: Column<any>[] = [
    { key:'product_id',   label:isAr?'معرف المنتج':'Product ID' },
    { key:'quantity',     label:isAr?'الكمية':'Quantity',
      render:r=>{
        const low = r.quantity <= r.min_quantity && r.min_quantity > 0;
        return <span className="font-bold" style={{color: low ? 'var(--color-danger)' : 'var(--neon)'}}>{r.quantity}{low ? ' ⚠' : ''}</span>;
      }},
    { key:'min_quantity', label:isAr?'الحد الأدنى':'Min Qty' },
    { key:'expiry_date',  label:isAr?'تاريخ الانتهاء':'Expiry' },
    { key:'batch_number', label:isAr?'رقم الدُفعة':'Batch #' },
  ];

  return (
    <div>
      {lowStockCount > 0 && (
        <div className="mb-4 p-3 rounded-xl flex items-center gap-2 text-sm animate-fade-in"
          style={{background:'rgba(239,68,68,0.1)',border:'1px solid rgba(239,68,68,0.3)',color:'var(--color-danger)'}}>
          <AlertTriangle size={16} />
          <strong>{lowStockCount}</strong> {isAr?'منتجات بمخزون منخفض — يرجى إعادة الطلب':'products have low stock — reorder needed'}
        </div>
      )}
      <PageHeader title={isAr?'المخزون':'Inventory'} subtitle={isAr?`${data.length} سجل`:`${data.length} records`}
        action={<Button icon={Plus} onClick={openAdd}>{isAr?'إضافة':'Add'}</Button>} />
      <DataTable data={data} columns={cols} loading={loading}
        onAdd={openAdd} onEdit={openEdit} onDelete={r=>setDelId(r.id)}
        searchKeys={['product_id','batch_number']}
        emptyTitle={isAr?'لا سجلات مخزون':'No inventory records'}
        emptyDescription={isAr?'أضف سجلات المخزون':'Add inventory entries'} />

      <Modal open={modal} onClose={()=>setModal(false)} size="md"
        title={editId?(isAr?'تعديل المخزون':'Edit Inventory'):(isAr?'إضافة مخزون':'Add Inventory')}>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><Input label={isAr?'معرف المنتج *':'Product ID *'} value={form.product_id} onChange={e=>setForm({...form,product_id:e.target.value})} placeholder="Product UUID or Code" /></div>
          <Input label={isAr?'الكمية الحالية':'Current Quantity'} type="number" min="0" value={form.quantity} onChange={e=>setForm({...form,quantity:e.target.value})} />
          <Input label={isAr?'الحد الأدنى للتنبيه':'Min Qty Alert'} type="number" min="0" value={form.min_quantity} onChange={e=>setForm({...form,min_quantity:e.target.value})} />
          <Input label={isAr?'تاريخ الانتهاء':'Expiry Date'} type="date" value={form.expiry_date} onChange={e=>setForm({...form,expiry_date:e.target.value})} />
          <Input label={isAr?'رقم الدُفعة':'Batch Number'} value={form.batch_number} onChange={e=>setForm({...form,batch_number:e.target.value})} />
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="secondary" onClick={()=>setModal(false)}>{isAr?'إلغاء':'Cancel'}</Button>
          <Button onClick={save} loading={saving}>{isAr?'حفظ':'Save'}</Button>
        </div>
      </Modal>
      <ConfirmDialog open={!!delId} onClose={()=>setDelId(null)} onConfirm={del}
        title={isAr?'حذف سجل':'Delete Inventory'} message={isAr?'حذف هذا السجل؟':'Delete this inventory record?'} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════
   ORDERS (uses `sales` table)
══════════════════════════════════════════════════════ */
export function OrdersPage() {
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [data,    setData]    = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal,   setModal]   = useState(false);
  const [viewItem,setViewItem]= useState<any|null>(null);
  const [editId,  setEditId]  = useState<string|null>(null);
  const [delId,   setDelId]   = useState<string|null>(null);
  const [saving,  setSaving]  = useState(false);
  const [statusF, setStatusF] = useState('');
  const [form, setForm] = useState({
    customer_id:'', customer_name:'', notes:'',
    subtotal:'', discount:'0', tax:'0', total:'',
    payment_method:'cash', payment_status:'unpaid', status:'pending',
  });

  const load = async () => {
    setLoading(true);
    try {
      const { data: rows, error } = await supabase.from('sales').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      setData(rows || []);
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const calcTotal = (f: typeof form) => {
    const sub  = parseFloat(f.subtotal)||0;
    const disc = parseFloat(f.discount)||0;
    const tax  = parseFloat(f.tax)||0;
    return +(sub - disc + tax).toFixed(2);
  };

  const openAdd  = () => { setForm({ customer_id:'', customer_name:'', notes:'', subtotal:'', discount:'0', tax:'0', total:'', payment_method:'cash', payment_status:'unpaid', status:'pending' }); setEditId(null); setModal(true); };
  const openEdit = (r: any) => { setForm({ customer_id:r.customer_id||'', customer_name:r.customer_name||'', notes:r.notes||'', subtotal:String(r.subtotal||''), discount:String(r.discount||'0'), tax:String(r.tax||'0'), total:String(r.total||''), payment_method:r.payment_method||'cash', payment_status:r.payment_status||'unpaid', status:r.status||'pending' }); setEditId(r.id); setModal(true); };

  const upForm = (k: string, v: any) => setForm(p => {
    const next = {...p,[k]:v};
    if (['subtotal','discount','tax'].includes(k)) return {...next, total: String(calcTotal(next))};
    return next;
  });

  const save = async () => {
    setSaving(true);
    try {
      const payload = {
        customer_id:    form.customer_id || null,
        customer_name:  form.customer_name || null,
        notes:          form.notes || null,
        subtotal:       parseFloat(form.subtotal)||0,
        discount:       parseFloat(form.discount)||0,
        tax:            parseFloat(form.tax)||0,
        total:          parseFloat(form.total)||calcTotal(form),
        payment_method: form.payment_method||'cash',
        payment_status: form.payment_status||'unpaid',
        status:         form.status||'pending',
        ...(editId ? {} : { sale_number: `ORD-${Date.now().toString().slice(-6)}`, sale_date: new Date().toISOString() }),
      };
      const { error } = editId
        ? await supabase.from('sales').update(payload).eq('id', editId)
        : await supabase.from('sales').insert([payload]);
      if (error) throw error;
      toast(editId?(isAr?'تم التحديث ✓':'Updated ✓'):(isAr?'تمت الإضافة ✓':'Order added ✓'),'success'); setModal(false); load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setSaving(false);
  };

  const del = async () => {
    if (!delId) return;
    try {
      const { error } = await supabase.from('sales').delete().eq('id', delId);
      if (error) throw error;
      toast(isAr?'تم الحذف ✓':'Deleted ✓','success'); load();
    } catch (e: any) {
      toast(e.message, 'error');
    }
    setDelId(null);
  };

  const displayed = statusF ? data.filter(d => d.status === statusF) : data;

  const cols: Column<any>[] = [
    { key:'sale_number', label:isAr?'رقم الطلب':'Order #', render:r=><span className="font-mono text-xs" style={{color:'var(--neon)'}}>{r.sale_number||'—'}</span> },
    { key:'sale_date',   label:isAr?'التاريخ':'Date', render:r=>r.sale_date?new Date(r.sale_date).toLocaleDateString():'—' },
    { key:'customer_name', label:isAr?'العميل':'Customer', render:r=><span className="font-semibold">{r.customer_name || r.customer_id || '—'}</span> },
    { key:'subtotal',    label:isAr?'المجموع':'Subtotal', render:r=>`EGP ${r.subtotal||0}` },
    { key:'discount',    label:isAr?'الخصم':'Discount', render:r=>`EGP ${r.discount||0}` },
    { key:'total',       label:isAr?'الإجمالي':'Total', render:r=><span className="font-bold">EGP {r.total||0}</span> },
    { key:'payment_method', label:isAr?'الدفع':'Payment', render:r=><Badge color="info">{r.payment_method}</Badge> },
    { key:'payment_status', label:isAr?'حالة الدفع':'Pay Status', render:r=><Badge color={r.payment_status==='paid'?'success':'warning'}>{r.payment_status}</Badge> },
    { key:'status',         label:isAr?'الحالة':'Status', render:r=><Badge color={r.status==='completed'?'success':r.status==='cancelled'?'danger':'warning'}>{r.status}</Badge> },
  ];

  return (
    <div>
      <PageHeader title={isAr?'الطلبات':'Orders'}
        subtitle={isAr?`${data.length} طلب`:`${data.length} orders`}
        action={<Button icon={Plus} onClick={openAdd}>{isAr?'طلب جديد':'New Order'}</Button>} />
      <DataTable data={displayed} columns={cols} loading={loading}
        onAdd={openAdd} onEdit={openEdit} onDelete={r=>setDelId(r.id)} onView={r=>setViewItem(r)}
        searchKeys={['sale_number','customer_id','customer_name']}
        filters={[{label:'Status',value:statusF,onChange:setStatusF,options:[
          {value:'pending',label:'Pending'},{value:'completed',label:'Completed'},{value:'cancelled',label:'Cancelled'}
        ]}]}
        emptyTitle={isAr?'لا طلبات':'No orders yet'}
        emptyDescription={isAr?'أضف أول طلب':'Create your first order'} />

      <Modal open={modal} onClose={()=>setModal(false)} size="lg"
        title={editId?(isAr?'تعديل طلب':'Edit Order'):(isAr?'طلب جديد':'New Order')}>
        <div className="grid grid-cols-2 gap-4">
          <Input label={isAr?'كود العميل':'Customer Code'} value={form.customer_id} onChange={e=>upForm('customer_id',e.target.value)} placeholder="CUS-00001" />
          <Input label={isAr?'اسم العميل':'Customer Name'} value={form.customer_name} onChange={e=>upForm('customer_name',e.target.value)} />
          <Input label={isAr?'المجموع الفرعي (EGP)':'Subtotal (EGP)'} type="number" min="0" value={form.subtotal} onChange={e=>upForm('subtotal',e.target.value)} />
          <Input label={isAr?'الخصم (EGP)':'Discount (EGP)'} type="number" min="0" value={form.discount} onChange={e=>upForm('discount',e.target.value)} />
          <Input label={isAr?'الضريبة (EGP)':'Tax (EGP)'} type="number" min="0" value={form.tax} onChange={e=>upForm('tax',e.target.value)} />
          <div className="p-3 rounded-xl flex items-center justify-between" style={{background:'rgba(0,212,255,0.08)',border:'1px solid rgba(0,212,255,0.2)'}}>
            <span className="text-sm" style={{color:'var(--color-text-secondary)'}}>{isAr?'الإجمالي:':'Total:'}</span>
            <span className="font-extrabold" style={{color:'var(--neon)'}}>EGP {calcTotal(form)}</span>
          </div>
          <Select label={isAr?'طريقة الدفع':'Payment Method'} value={form.payment_method} onChange={e=>upForm('payment_method',e.target.value)}>
            <option value="cash">{isAr?'نقدي':'Cash'}</option>
            <option value="card">{isAr?'بطاقة':'Card'}</option>
            <option value="transfer">{isAr?'تحويل':'Transfer'}</option>
            <option value="wallet">{isAr?'محفظة':'Wallet'}</option>
          </Select>
          <Select label={isAr?'حالة الدفع':'Payment Status'} value={form.payment_status} onChange={e=>upForm('payment_status',e.target.value)}>
            <option value="unpaid">{isAr?'غير مدفوع':'Unpaid'}</option>
            <option value="partial">{isAr?'جزئي':'Partial'}</option>
            <option value="paid">{isAr?'مدفوع':'Paid'}</option>
            <option value="refunded">{isAr?'مسترد':'Refunded'}</option>
          </Select>
          <Select label={isAr?'حالة الطلب':'Order Status'} value={form.status} onChange={e=>upForm('status',e.target.value)}>
            <option value="pending">{isAr?'قيد الانتظار':'Pending'}</option>
            <option value="completed">{isAr?'مكتمل':'Completed'}</option>
            <option value="cancelled">{isAr?'ملغي':'Cancelled'}</option>
            <option value="refunded">{isAr?'مسترد':'Refunded'}</option>
          </Select>
          <div className="col-span-2"><Textarea label={isAr?'ملاحظات':'Notes'} value={form.notes} onChange={e=>upForm('notes',e.target.value)} rows={2} /></div>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="secondary" onClick={()=>setModal(false)}>{isAr?'إلغاء':'Cancel'}</Button>
          <Button onClick={save} loading={saving}>{isAr?'حفظ':'Save'}</Button>
        </div>
      </Modal>

      {/* View Receipt */}
      <Modal open={!!viewItem} onClose={()=>setViewItem(null)} title={isAr?'تفاصيل الطلب':'Order Details'} size="md">
        {viewItem && (
          <div>
            <div className="text-center pb-3 mb-3" style={{borderBottom:'1px solid var(--color-border)'}}>
              <h2 className="logo-text text-xl">REFORM FITNESS</h2>
              <p className="text-xs mt-1" style={{color:'var(--color-text-muted)'}}>{viewItem.sale_date?new Date(viewItem.sale_date).toLocaleString():'—'}</p>
            </div>
            {[
              [isAr?'رقم الطلب':'Order #',   viewItem.sale_number],
              [isAr?'العميل':'Customer', viewItem.customer_name || viewItem.customer_id],
              [isAr?'المجموع الفرعي':'Subtotal',`EGP ${viewItem.subtotal||0}`],
              [isAr?'الخصم':'Discount',      `EGP ${viewItem.discount||0}`],
              [isAr?'الضريبة':'Tax',          `EGP ${viewItem.tax||0}`],
              [isAr?'الإجمالي':'Total',       `EGP ${viewItem.total||0}`],
              [isAr?'طريقة الدفع':'Payment',  viewItem.payment_method],
              [isAr?'حالة الدفع':'Pay Status',viewItem.payment_status],
              [isAr?'الحالة':'Status',        viewItem.status],
              [isAr?'ملاحظات':'Notes',        viewItem.notes],
            ].filter(([,v])=>v).map(([l,v])=>(
              <div key={l as string} className="flex justify-between py-2" style={{borderBottom:'1px solid var(--color-border)'}}>
                <span className="text-xs" style={{color:'var(--color-text-muted)'}}>{l}</span>
                <span className="text-xs font-semibold" style={{color:'var(--color-text)'}}>{v}</span>
              </div>
            ))}
            <div className="flex gap-3 mt-4">
              <Button size="sm" onClick={()=>{setViewItem(null);openEdit(viewItem);}}>{isAr?'تعديل':'Edit'}</Button>
              <Button size="sm" variant="danger" onClick={()=>{setViewItem(null);setDelId(viewItem.id);}}>{isAr?'حذف':'Delete'}</Button>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog open={!!delId} onClose={()=>setDelId(null)} onConfirm={del}
        title={isAr?'حذف الطلب':'Delete Order'}
        message={isAr?'هل أنت متأكد من حذف هذا الطلب؟':'Are you sure you want to delete this order?'} />
    </div>
  );
}
