import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { Button, Input, Select, Textarea, Modal, PageHeader, Badge, Card } from '../components/ui';
import { Plus, MessageSquare, Server, Send, FileCode, Trash2, Edit } from 'lucide-react';

type Tab = 'messages' | 'templates' | 'providers';

export function SMSPage() {
  const { toast } = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';
  const [tab, setTab] = useState<Tab>('messages');
  const [messages, setMessages] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sendModal, setSendModal] = useState(false);
  const [tplModal, setTplModal] = useState(false);
  const [provModal, setProvModal] = useState(false);
  const [editTpl, setEditTpl] = useState<any | null>(null);

  const [sendForm, setSendForm] = useState({ to_number: '', message: '', template_id: '' });
  const [tplForm, setTplForm] = useState({ name: '', body: '', category: 'general' });
  const [provForm, setProvForm] = useState({ name: '', provider: '', api_url: '', api_key_encrypted: '', sender_id: '', is_default: false });

  const load = async () => {
    setLoading(true);
    const { data: msgs } = await supabase.from('sms_messages').select('*').order('created_at', { ascending: false });
    setMessages(msgs || []);
    const { data: tpls } = await supabase.from('sms_templates').select('*').order('created_at', { ascending: false });
    setTemplates(tpls || []);
    const { data: provs } = await supabase.from('sms_providers').select('*').order('created_at', { ascending: false });
    setProviders(provs || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const sendSMS = async () => {
    if (!sendForm.to_number || !sendForm.message) { toast(isAr ? 'يرجى ملء الحقول' : 'Please fill all fields', 'warning'); return; }
    const { error } = await supabase.from('sms_messages').insert([{
      ...sendForm,
      status: 'sent',
      sent_at: new Date().toISOString(),
    }]);
    if (error) toast(error.message, 'error');
    else { toast(isAr ? 'تم إرسال الرسالة' : 'SMS sent', 'success'); setSendModal(false); setSendForm({ to_number: '', message: '', template_id: '' }); load(); }
  };

  const saveTemplate = async () => {
    if (!tplForm.name) { toast(isAr ? 'الاسم مطلوب' : 'Name required', 'warning'); return; }
    const { error } = editTpl
      ? await supabase.from('sms_templates').update(tplForm).eq('id', editTpl.id)
      : await supabase.from('sms_templates').insert([tplForm]);
    if (error) toast(error.message, 'error');
    else { toast(isAr ? 'تم الحفظ' : 'Saved', 'success'); setTplModal(false); setEditTpl(null); setTplForm({ name: '', body: '', category: 'general' }); load(); }
  };

  const saveProvider = async () => {
    if (!provForm.name) { toast(isAr ? 'الاسم مطلوب' : 'Name required', 'warning'); return; }
    const { error } = await supabase.from('sms_providers').insert([provForm]);
    if (error) toast(error.message, 'error');
    else { toast(isAr ? 'تم الحفظ' : 'Saved', 'success'); setProvModal(false); setProvForm({ name: '', provider: '', api_url: '', api_key_encrypted: '', sender_id: '', is_default: false }); load(); }
  };

  const deleteTemplate = async (id: string) => {
    await supabase.from('sms_templates').delete().eq('id', id);
    toast(isAr ? 'تم الحذف' : 'Deleted', 'success'); load();
  };

  const tabs: { id: Tab; label: string; labelAr: string; icon: any }[] = [
    { id: 'messages', label: 'Messages', labelAr: 'الرسائل', icon: MessageSquare },
    { id: 'templates', label: 'Templates', labelAr: 'القوالب', icon: FileCode },
    { id: 'providers', label: 'Providers', labelAr: 'المزودون', icon: Server },
  ];

  return (
    <div>
      <PageHeader
        title={isAr ? 'نظام الرسائل القصيرة' : 'SMS System'}
        subtitle={isAr ? 'إدارة الرسائل والقوالب والمزودين' : 'Manage SMS, templates, and providers'}
        action={<Button icon={Plus} onClick={() => setSendModal(true)}>{isAr ? 'رسالة جديدة' : 'Send SMS'}</Button>}
      />

      <div className="flex gap-1 mb-4">
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button key={t.id} onClick={() => setTab(t.id)} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition whitespace-nowrap"
              style={{ background: tab === t.id ? 'var(--color-primary)' : 'var(--color-card)', color: tab === t.id ? 'white' : 'var(--color-text-secondary)', border: '1px solid var(--color-border)' }}>
              <Icon size={16} />{isAr ? t.labelAr : t.label}
            </button>
          );
        })}
      </div>

      {loading ? (
        <Card><div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="skeleton h-12" />)}</div></Card>
      ) : tab === 'messages' ? (
        <Card className="p-0 overflow-hidden">
          {messages.length === 0 ? (
            <div className="text-center py-12">
              <MessageSquare size={32} className="mx-auto mb-3" style={{ color: 'var(--color-text-secondary)' }} />
              <p style={{ color: 'var(--color-text-secondary)' }}>{isAr ? 'لا توجد رسائل' : 'No messages'}</p>
            </div>
          ) : (
            <div>
              {messages.map((msg) => (
                <div key={msg.id} className="flex items-center gap-3 p-4" style={{ borderBottom: '1px solid var(--color-border)' }}>
                  <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--color-primary)20' }}>
                    <MessageSquare size={18} style={{ color: 'var(--color-primary)' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>{msg.to_number}</p>
                    <p className="text-xs truncate" style={{ color: 'var(--color-text-secondary)' }}>{msg.message}</p>
                  </div>
                  <Badge color={msg.status === 'sent' ? 'success' : msg.status === 'failed' ? 'danger' : 'warning'}>{msg.status}</Badge>
                  <span className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>{new Date(msg.created_at).toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          )}
        </Card>
      ) : tab === 'templates' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates.map((tpl) => (
            <Card key={tpl.id} hover>
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-semibold" style={{ color: 'var(--color-text)' }}>{tpl.name}</h3>
                <Badge color="info">{tpl.category}</Badge>
              </div>
              <p className="text-sm mb-3" style={{ color: 'var(--color-text-secondary)' }}>{tpl.body}</p>
              <div className="flex gap-1">
                <button onClick={() => { setEditTpl(tpl); setTplForm({ name: tpl.name, body: tpl.body || '', category: tpl.category || 'general' }); setTplModal(true); }} className="p-1.5 rounded" style={{ color: 'var(--color-primary)' }}><Edit size={16} /></button>
                <button onClick={() => deleteTemplate(tpl.id)} className="p-1.5 rounded" style={{ color: 'var(--color-danger)' }}><Trash2 size={16} /></button>
              </div>
            </Card>
          ))}
          <Card className="flex items-center justify-center cursor-pointer border-dashed" hover>
            <button onClick={() => { setEditTpl(null); setTplForm({ name: '', body: '', category: 'general' }); setTplModal(true); }} className="flex flex-col items-center" style={{ color: 'var(--color-text-secondary)' }}>
              <Plus size={24} className="mb-1" /><span className="text-sm">{isAr ? 'إضافة قالب' : 'Add Template'}</span>
            </button>
          </Card>
        </div>
      ) : (
        <div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {providers.map((prov) => (
              <Card key={prov.id} hover>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'var(--color-primary)20' }}>
                      <Server size={20} style={{ color: 'var(--color-primary)' }} />
                    </div>
                    <div>
                      <h3 className="font-semibold" style={{ color: 'var(--color-text)' }}>{prov.name}</h3>
                      <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>{prov.provider || 'Custom'}</p>
                    </div>
                  </div>
                  <Badge color={prov.is_active ? 'success' : 'default'}>{prov.is_active ? 'Active' : 'Inactive'}</Badge>
                </div>
                <div className="mt-3 text-xs space-y-1" style={{ color: 'var(--color-text-secondary)' }}>
                  <p>Sender ID: {prov.sender_id || '—'}</p>
                  <p>API: {prov.api_url || '—'}</p>
                </div>
              </Card>
            ))}
          </div>
          <Button icon={Plus} onClick={() => setProvModal(true)}>{isAr ? 'إضافة مزود' : 'Add Provider'}</Button>
        </div>
      )}

      {/* Send Modal */}
      <Modal open={sendModal} onClose={() => setSendModal(false)} title={isAr ? 'رسالة جديدة' : 'Send SMS'} size="md">
        <div className="space-y-4">
          <div>
            <label className="label">{isAr ? 'القالب' : 'Template'}</label>
            <select className="input" value={sendForm.template_id} onChange={(e) => {
              const tpl = templates.find((t) => t.id === e.target.value);
              setSendForm({ ...sendForm, template_id: e.target.value, message: tpl?.body || sendForm.message });
            }}>
              <option value="">{isAr ? 'بدون قالب' : 'No template'}</option>
              {templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </div>
          <Input label={isAr ? 'رقم الهاتف' : 'Phone Number'} value={sendForm.to_number} onChange={(e) => setSendForm({ ...sendForm, to_number: e.target.value })} placeholder="+20..." />
          <Textarea label={isAr ? 'الرسالة' : 'Message'} rows={4} value={sendForm.message} onChange={(e) => setSendForm({ ...sendForm, message: e.target.value })} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setSendModal(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
            <Button icon={Send} onClick={sendSMS}>{isAr ? 'إرسال' : 'Send'}</Button>
          </div>
        </div>
      </Modal>

      {/* Template Modal */}
      <Modal open={tplModal} onClose={() => setTplModal(false)} title={editTpl ? (isAr ? 'تعديل قالب' : 'Edit Template') : (isAr ? 'قالب جديد' : 'New Template')} size="md">
        <div className="space-y-4">
          <Input label={isAr ? 'الاسم' : 'Name'} value={tplForm.name} onChange={(e) => setTplForm({ ...tplForm, name: e.target.value })} />
          <Select label={isAr ? 'الفئة' : 'Category'} value={tplForm.category} onChange={(e) => setTplForm({ ...tplForm, category: e.target.value })}>
            <option value="general">General</option>
            <option value="otp">OTP</option>
            <option value="appointment">Appointment Reminder</option>
            <option value="membership">Membership Renewal</option>
            <option value="invoice">Invoice</option>
            <option value="payment">Payment Confirmation</option>
          </Select>
          <Textarea label={isAr ? 'المحتوى' : 'Body'} rows={4} value={tplForm.body} onChange={(e) => setTplForm({ ...tplForm, body: e.target.value })} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setTplModal(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
            <Button onClick={saveTemplate}>{isAr ? 'حفظ' : 'Save'}</Button>
          </div>
        </div>
      </Modal>

      {/* Provider Modal */}
      <Modal open={provModal} onClose={() => setProvModal(false)} title={isAr ? 'إضافة مزود' : 'Add Provider'} size="md">
        <div className="space-y-4">
          <Input label={isAr ? 'الاسم' : 'Name'} value={provForm.name} onChange={(e) => setProvForm({ ...provForm, name: e.target.value })} />
          <Input label={isAr ? 'المزود' : 'Provider'} value={provForm.provider} onChange={(e) => setProvForm({ ...provForm, provider: e.target.value })} placeholder="Twilio, etc." />
          <Input label={isAr ? 'رابط API' : 'API URL'} value={provForm.api_url} onChange={(e) => setProvForm({ ...provForm, api_url: e.target.value })} />
          <Input label={isAr ? 'مفتاح API' : 'API Key'} type="password" value={provForm.api_key_encrypted} onChange={(e) => setProvForm({ ...provForm, api_key_encrypted: e.target.value })} />
          <Input label={isAr ? 'معرف المرسل' : 'Sender ID'} value={provForm.sender_id} onChange={(e) => setProvForm({ ...provForm, sender_id: e.target.value })} />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setProvModal(false)}>{isAr ? 'إلغاء' : 'Cancel'}</Button>
            <Button onClick={saveProvider}>{isAr ? 'حفظ' : 'Save'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
