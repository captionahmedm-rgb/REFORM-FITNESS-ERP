/*
# Employee Code Auto-Generator (Sequential 5-digit)

## Purpose
Generates unique sequential 5-digit employee codes starting at 10001.
Codes are never reused, even for deleted employees.

## Changes
1. New sequence `employee_code_seq` starting at 10001
2. New function `next_employee_code()` returns text like '10001'
3. `app_users.employee_code` column (distinct from old `employee_id` text field)
   - Auto-assigned on insert via trigger
   - UNIQUE constraint prevents duplicates
   - Read-only from application perspective (trigger-assigned)

## Security
- Trigger runs server-side — cannot be spoofed from frontend
- Unique constraint enforced at DB level
*/

-- Sequence for 5-digit codes starting at 10001
CREATE SEQUENCE IF NOT EXISTS employee_code_seq
  START WITH 10001
  INCREMENT BY 1
  MINVALUE 10001
  NO MAXVALUE
  NO CYCLE;

-- Add employee_code column if not exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'app_users' AND column_name = 'employee_code') THEN
    ALTER TABLE app_users ADD COLUMN employee_code text UNIQUE;
  END IF;
END $$;

-- Function to generate next code
CREATE OR REPLACE FUNCTION next_employee_code()
RETURNS text LANGUAGE sql AS $$
  SELECT nextval('employee_code_seq')::text;
$$;

-- Trigger function: assign code on insert if not already set
CREATE OR REPLACE FUNCTION assign_employee_code()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.employee_code IS NULL OR NEW.employee_code = '' THEN
    NEW.employee_code := nextval('employee_code_seq')::text;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_assign_employee_code ON app_users;
CREATE TRIGGER trg_assign_employee_code
  BEFORE INSERT ON app_users
  FOR EACH ROW EXECUTE FUNCTION assign_employee_code();

-- Back-fill existing rows that have no code
UPDATE app_users
SET employee_code = nextval('employee_code_seq')::text
WHERE employee_code IS NULL;
