/*
# Reform Fitness Enterprise ERP - Core Schema

## Overview
Creates the foundational schema for the Reform Fitness Enterprise ERP platform.
Multi-branch enterprise system with role-based access control.

## Tables
1. branches, departments, app_users, roles, user_roles, permissions, role_permissions
2. audit_logs, settings, notifications
*/

-- Branches
CREATE TABLE IF NOT EXISTS branches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE,
  address text,
  city text,
  phone text,
  email text,
  manager_id uuid,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Departments
CREATE TABLE IF NOT EXISTS departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  head_id uuid,
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- App users
CREATE TABLE IF NOT EXISTS app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_id uuid UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  employee_id text UNIQUE,
  full_name text NOT NULL,
  email text UNIQUE,
  phone text,
  avatar_url text,
  job_title text,
  department_id uuid REFERENCES departments(id) ON DELETE SET NULL,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  manager_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  status text DEFAULT 'active' CHECK (status IN ('active','inactive','suspended','pending')),
  hire_date date,
  last_login timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Roles
CREATE TABLE IF NOT EXISTS roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  display_name text NOT NULL,
  description text,
  is_system boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- User-Role mapping
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  assigned_at timestamptz DEFAULT now(),
  UNIQUE(user_id, role_id)
);

-- Permissions
CREATE TABLE IF NOT EXISTS permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  module text NOT NULL,
  action text NOT NULL,
  description text
);

-- Role-Permission mapping
CREATE TABLE IF NOT EXISTS role_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id uuid NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  UNIQUE(role_id, permission_id)
);

-- Audit logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  action text NOT NULL,
  module text,
  entity_type text,
  entity_id uuid,
  details jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- Settings
CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb,
  category text NOT NULL DEFAULT 'general',
  is_public boolean DEFAULT false,
  updated_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  updated_at timestamptz DEFAULT now()
);

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES app_users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text,
  type text DEFAULT 'info' CHECK (type IN ('info','success','warning','error')),
  module text,
  is_read boolean DEFAULT false,
  link text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE branches ENABLE ROW LEVEL SECURITY;
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Helper: all CRUD policies for a table
-- Branches
DROP POLICY IF EXISTS "auth_read_branches" ON branches;
CREATE POLICY "auth_read_branches" ON branches FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_branches" ON branches;
CREATE POLICY "auth_insert_branches" ON branches FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_branches" ON branches;
CREATE POLICY "auth_update_branches" ON branches FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_branches" ON branches;
CREATE POLICY "auth_delete_branches" ON branches FOR DELETE TO authenticated USING (true);

-- Departments
DROP POLICY IF EXISTS "auth_read_departments" ON departments;
CREATE POLICY "auth_read_departments" ON departments FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_departments" ON departments;
CREATE POLICY "auth_insert_departments" ON departments FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_departments" ON departments;
CREATE POLICY "auth_update_departments" ON departments FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_departments" ON departments;
CREATE POLICY "auth_delete_departments" ON departments FOR DELETE TO authenticated USING (true);

-- App users
DROP POLICY IF EXISTS "auth_read_app_users" ON app_users;
CREATE POLICY "auth_read_app_users" ON app_users FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_app_users" ON app_users;
CREATE POLICY "auth_insert_app_users" ON app_users FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_app_users" ON app_users;
CREATE POLICY "auth_update_app_users" ON app_users FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_app_users" ON app_users;
CREATE POLICY "auth_delete_app_users" ON app_users FOR DELETE TO authenticated USING (true);

-- Roles
DROP POLICY IF EXISTS "auth_read_roles" ON roles;
CREATE POLICY "auth_read_roles" ON roles FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_roles" ON roles;
CREATE POLICY "auth_insert_roles" ON roles FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_roles" ON roles;
CREATE POLICY "auth_update_roles" ON roles FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_roles" ON roles;
CREATE POLICY "auth_delete_roles" ON roles FOR DELETE TO authenticated USING (true);

-- User roles
DROP POLICY IF EXISTS "auth_read_user_roles" ON user_roles;
CREATE POLICY "auth_read_user_roles" ON user_roles FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_user_roles" ON user_roles;
CREATE POLICY "auth_insert_user_roles" ON user_roles FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_user_roles" ON user_roles;
CREATE POLICY "auth_update_user_roles" ON user_roles FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_user_roles" ON user_roles;
CREATE POLICY "auth_delete_user_roles" ON user_roles FOR DELETE TO authenticated USING (true);

-- Permissions
DROP POLICY IF EXISTS "auth_read_permissions" ON permissions;
CREATE POLICY "auth_read_permissions" ON permissions FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_permissions" ON permissions;
CREATE POLICY "auth_insert_permissions" ON permissions FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_permissions" ON permissions;
CREATE POLICY "auth_delete_permissions" ON permissions FOR DELETE TO authenticated USING (true);

-- Role permissions
DROP POLICY IF EXISTS "auth_read_role_permissions" ON role_permissions;
CREATE POLICY "auth_read_role_permissions" ON role_permissions FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_role_permissions" ON role_permissions;
CREATE POLICY "auth_insert_role_permissions" ON role_permissions FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_role_permissions" ON role_permissions;
CREATE POLICY "auth_delete_role_permissions" ON role_permissions FOR DELETE TO authenticated USING (true);

-- Audit logs
DROP POLICY IF EXISTS "auth_read_audit_logs" ON audit_logs;
CREATE POLICY "auth_read_audit_logs" ON audit_logs FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_audit_logs" ON audit_logs;
CREATE POLICY "auth_insert_audit_logs" ON audit_logs FOR INSERT TO authenticated WITH CHECK (true);

-- Settings
DROP POLICY IF EXISTS "auth_read_settings" ON settings;
CREATE POLICY "auth_read_settings" ON settings FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_settings" ON settings;
CREATE POLICY "auth_insert_settings" ON settings FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_settings" ON settings;
CREATE POLICY "auth_update_settings" ON settings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_settings" ON settings;
CREATE POLICY "auth_delete_settings" ON settings FOR DELETE TO authenticated USING (true);

-- Notifications (user sees their own)
DROP POLICY IF EXISTS "auth_read_notifications" ON notifications;
CREATE POLICY "auth_read_notifications" ON notifications FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "auth_insert_notifications" ON notifications;
CREATE POLICY "auth_insert_notifications" ON notifications FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_notifications" ON notifications;
CREATE POLICY "auth_update_notifications" ON notifications FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "auth_delete_notifications" ON notifications;
CREATE POLICY "auth_delete_notifications" ON notifications FOR DELETE TO authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_app_users_auth_id ON app_users(auth_id);
CREATE INDEX IF NOT EXISTS idx_app_users_email ON app_users(email);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_settings_key ON settings(key);
CREATE INDEX IF NOT EXISTS idx_settings_category ON settings(category);

-- Default system roles
INSERT INTO roles (name, display_name, description, is_system) VALUES
  ('super_admin', 'Super Admin', 'Full system access', true),
  ('owner', 'Owner', 'Business owner with full access', true),
  ('general_manager', 'General Manager', 'Manages all branches and operations', true),
  ('branch_manager', 'Branch Manager', 'Manages a single branch', true),
  ('hr', 'HR Manager', 'Human resources management', true),
  ('accountant', 'Accountant', 'Financial and accounting management', true),
  ('sales', 'Sales', 'Sales and POS operations', true),
  ('customer_service', 'Customer Service', 'Customer support', true),
  ('call_center', 'Call Center Agent', 'Call center operations', true),
  ('technical_support', 'Technical Support', 'IT support tickets', true),
  ('trainer', 'Trainer', 'Fitness training and workout programs', true),
  ('nutritionist', 'Nutrition Specialist', 'Nutrition planning', true),
  ('doctor', 'Doctor', 'Medical consultations', true),
  ('warehouse_manager', 'Warehouse Manager', 'Inventory management', true),
  ('employee', 'Employee', 'Basic employee access', true),
  ('customer', 'Customer', 'Customer portal access', true)
ON CONFLICT (name) DO NOTHING;

-- Default permissions
INSERT INTO permissions (name, module, action, description) VALUES
  ('customers.create', 'customers', 'create', 'Create customer records'),
  ('customers.read', 'customers', 'read', 'View customer records'),
  ('customers.update', 'customers', 'update', 'Edit customer records'),
  ('customers.delete', 'customers', 'delete', 'Delete customer records'),
  ('employees.create', 'employees', 'create', 'Create employee records'),
  ('employees.read', 'employees', 'read', 'View employee records'),
  ('employees.update', 'employees', 'update', 'Edit employee records'),
  ('employees.delete', 'employees', 'delete', 'Delete employee records'),
  ('inventory.create', 'inventory', 'create', 'Create inventory items'),
  ('inventory.read', 'inventory', 'read', 'View inventory'),
  ('inventory.update', 'inventory', 'update', 'Edit inventory items'),
  ('inventory.delete', 'inventory', 'delete', 'Delete inventory items'),
  ('sales.create', 'sales', 'create', 'Create sales/POS transactions'),
  ('sales.read', 'sales', 'read', 'View sales records'),
  ('sales.update', 'sales', 'update', 'Edit sales records'),
  ('sales.delete', 'sales', 'delete', 'Delete sales records'),
  ('settings.manage', 'settings', 'manage', 'Manage system settings'),
  ('reports.read', 'reports', 'read', 'View reports'),
  ('reports.export', 'reports', 'export', 'Export reports')
ON CONFLICT (name) DO NOTHING;

-- Default settings
INSERT INTO settings (key, value, category, is_public) VALUES
  ('theme', '{"primaryColor":"#2563EB","secondaryColor":"#1D4ED8","accentColor":"#3B82F6","backgroundColor":"#0F172A","sidebarColor":"#111827","cardColor":"#1E293B","borderColor":"#334155","textColor":"#F8FAFC","secondaryTextColor":"#94A3B8","successColor":"#10B981","warningColor":"#F59E0B","dangerColor":"#EF4444","borderRadius":"12px","mode":"dark","fontFamily":"Inter"}'::jsonb, 'theme', true),
  ('company', '{"name":"REFORM FITNESS","logo":"","favicon":"","tagline":"Enterprise Fitness Management"}'::jsonb, 'general', true),
  ('language', '{"default":"en","supported":["en","ar"],"direction":"ltr"}'::jsonb, 'general', true)
ON CONFLICT (key) DO NOTHING;
