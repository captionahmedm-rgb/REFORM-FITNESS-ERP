/*
# Employee Profile — Extended Fields Migration

Adds comprehensive employee personal information fields to app_users table.
Changes department_id from UUID FK to plain text (department name) so the UI
can store department names directly without needing a separate departments lookup.
Same for branch_id → branch_name text column for simplicity.

## Changes
- app_users: add gender, date_of_birth, national_id, nationality, marital_status,
  whatsapp_number, personal_email, company_email, address, city, governorate,
  postal_code, emergency_contact, emergency_phone, contract_type, employment_type,
  shift_type, salary, years_experience, previous_company, notes,
  department_name (text), branch_name (text)
- All new columns nullable for backwards compat
- No data loss — only additions
*/

-- Add extended employee fields
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='gender') THEN
    ALTER TABLE app_users ADD COLUMN gender text CHECK (gender IN ('male','female','other'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='date_of_birth') THEN
    ALTER TABLE app_users ADD COLUMN date_of_birth date;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='national_id') THEN
    ALTER TABLE app_users ADD COLUMN national_id text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='nationality') THEN
    ALTER TABLE app_users ADD COLUMN nationality text DEFAULT 'Egyptian';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='marital_status') THEN
    ALTER TABLE app_users ADD COLUMN marital_status text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='whatsapp_number') THEN
    ALTER TABLE app_users ADD COLUMN whatsapp_number text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='personal_email') THEN
    ALTER TABLE app_users ADD COLUMN personal_email text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='company_email') THEN
    ALTER TABLE app_users ADD COLUMN company_email text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='address') THEN
    ALTER TABLE app_users ADD COLUMN address text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='city') THEN
    ALTER TABLE app_users ADD COLUMN city text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='governorate') THEN
    ALTER TABLE app_users ADD COLUMN governorate text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='postal_code') THEN
    ALTER TABLE app_users ADD COLUMN postal_code text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='emergency_contact') THEN
    ALTER TABLE app_users ADD COLUMN emergency_contact text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='emergency_phone') THEN
    ALTER TABLE app_users ADD COLUMN emergency_phone text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='contract_type') THEN
    ALTER TABLE app_users ADD COLUMN contract_type text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='employment_type') THEN
    ALTER TABLE app_users ADD COLUMN employment_type text DEFAULT 'full_time';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='shift_type') THEN
    ALTER TABLE app_users ADD COLUMN shift_type text DEFAULT 'morning';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='salary') THEN
    ALTER TABLE app_users ADD COLUMN salary numeric;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='years_experience') THEN
    ALTER TABLE app_users ADD COLUMN years_experience integer DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='previous_company') THEN
    ALTER TABLE app_users ADD COLUMN previous_company text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='notes') THEN
    ALTER TABLE app_users ADD COLUMN notes text;
  END IF;
  -- Text department/branch (no FK) — safe fallback alongside the UUID columns
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='department_name') THEN
    ALTER TABLE app_users ADD COLUMN department_name text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='branch_name') THEN
    ALTER TABLE app_users ADD COLUMN branch_name text;
  END IF;
  -- Role label (e.g. "Trainer", "Admin") — distinct from RBAC roles table
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='app_users' AND column_name='role_label') THEN
    ALTER TABLE app_users ADD COLUMN role_label text;
  END IF;
END $$;

-- Profile picture in Supabase storage bucket (url stored here)
-- avatar_url already exists, no change needed

-- Add password_hash placeholder (actual auth is Supabase Auth)
-- No changes needed, passwords handled by supabase.auth

-- Add index on employee_id for fast lookups
CREATE INDEX IF NOT EXISTS idx_app_users_emp_id ON app_users(employee_id);
CREATE INDEX IF NOT EXISTS idx_app_users_national_id ON app_users(national_id);
