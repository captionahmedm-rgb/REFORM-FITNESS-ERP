/*
# Enhanced Employee & Customer Code Sequences

## Overview
Creates proper sequences and functions for auto-generating codes:
- Employees: EMP-00001, EMP-00002, etc.
- Customers: CUS-00001, CUS-00002, etc.
*/

-- Create sequences for employee and customer codes
CREATE SEQUENCE IF NOT EXISTS employee_code_seq START 1 INCREMENT 1;
CREATE SEQUENCE IF NOT EXISTS customer_code_seq START 1 INCREMENT 1;

-- Function to get next employee code
CREATE OR REPLACE FUNCTION get_next_employee_code()
RETURNS text AS $$
DECLARE
  next_val bigint;
  code text;
BEGIN
  next_val := nextval('employee_code_seq');
  code := 'EMP-' || LPAD(next_val::text, 5, '0');
  RETURN code;
END;
$$ LANGUAGE plpgsql;

-- Function to get next customer code
CREATE OR REPLACE FUNCTION get_next_customer_code()
RETURNS text AS $$
DECLARE
  next_val bigint;
  code text;
BEGIN
  next_val := nextval('customer_code_seq');
  code := 'CUS-' || LPAD(next_val::text, 5, '0');
  RETURN code;
END;
$$ LANGUAGE plpgsql;

-- Sync sequences with existing data
SELECT setval('employee_code_seq', COALESCE(
  (SELECT MAX(CAST(REPLACE(employee_id, 'EMP-', '') AS bigint)) FROM app_users WHERE employee_id ~ '^EMP-\d{5}$'),
  0
) + 1, false);

SELECT setval('customer_code_seq', COALESCE(
  (SELECT MAX(CAST(REPLACE(customer_code, 'CUS-', '') AS bigint)) FROM customers WHERE customer_code ~ '^CUS-\d{5}$'),
  0
) + 1, false);

-- Add trigger for auto-generating employee code on insert
CREATE OR REPLACE FUNCTION auto_generate_employee_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.employee_id IS NULL OR NEW.employee_id = '' THEN
    NEW.employee_id := get_next_employee_code();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add trigger for auto-generating customer code on insert
CREATE OR REPLACE FUNCTION auto_generate_customer_code()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.customer_code IS NULL OR NEW.customer_code = '' THEN
    NEW.customer_code := get_next_customer_code();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS trigger_auto_employee_code ON app_users;
DROP TRIGGER IF EXISTS trigger_auto_customer_code ON customers;

-- Create triggers
CREATE TRIGGER trigger_auto_employee_code
  BEFORE INSERT ON app_users
  FOR EACH ROW
  EXECUTE FUNCTION auto_generate_employee_code();

CREATE TRIGGER trigger_auto_customer_code
  BEFORE INSERT ON customers
  FOR EACH ROW
  EXECUTE FUNCTION auto_generate_customer_code();

-- Add working hours columns to attendance if not exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'attendance' AND column_name = 'late_minutes') THEN
    ALTER TABLE attendance ADD COLUMN late_minutes integer DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'attendance' AND column_name = 'working_hours') THEN
    ALTER TABLE attendance ADD COLUMN working_hours numeric DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'attendance' AND column_name = 'check_in_time') THEN
    ALTER TABLE attendance ADD COLUMN check_in_time time;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'attendance' AND column_name = 'check_out_time') THEN
    ALTER TABLE attendance ADD COLUMN check_out_time time;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'attendance' AND column_name = 'shift_start') THEN
    ALTER TABLE attendance ADD COLUMN shift_start time DEFAULT '09:00:00';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'attendance' AND column_name = 'shift_end') THEN
    ALTER TABLE attendance ADD COLUMN shift_end time DEFAULT '17:00:00';
  END IF;
END $$;