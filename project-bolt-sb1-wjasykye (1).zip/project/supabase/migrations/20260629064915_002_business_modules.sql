/*
# Reform Fitness - Business Modules Schema

## Overview
Creates tables for all business modules: customers, employees, products, inventory,
sales, appointments, programs, accounting, support, email, SMS.

## Tables
- customers, customer_documents, customer_measurements
- employees, employee_documents, attendance, payroll, leave_requests
- categories, products, suppliers, inventory, stock_movements
- sales, sale_items, invoices, payments
- memberships, membership_plans
- appointments, workout_programs, nutrition_programs, medical_records
- call_center_calls, support_tickets
- expenses, revenue
- email_accounts, email_templates, email_messages, email_campaigns
- sms_providers, sms_templates, sms_messages
- warehouses
*/

-- ============ CUSTOMERS ============
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_code text UNIQUE,
  full_name text NOT NULL,
  national_id text,
  email text,
  phone text,
  whatsapp_number text,
  address text,
  city text,
  country text DEFAULT 'Egypt',
  date_of_birth date,
  gender text CHECK (gender IN ('male','female','other')),
  occupation text,
  emergency_contact text,
  emergency_phone text,
  profile_photo text,
  height numeric,
  weight numeric,
  body_fat numeric,
  muscle_mass numeric,
  bmi numeric,
  fitness_goal text,
  activity_level text,
  diseases text,
  allergies text,
  medications text,
  injuries text,
  medical_notes text,
  membership_id uuid,
  trainer_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  nutritionist_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  doctor_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  subscription_status text DEFAULT 'inactive',
  payment_status text DEFAULT 'none',
  wallet_balance numeric DEFAULT 0,
  loyalty_points integer DEFAULT 0,
  referral_code text,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  status text DEFAULT 'active' CHECK (status IN ('active','inactive','suspended')),
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customer_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  type text NOT NULL,
  name text,
  file_url text,
  uploaded_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customer_measurements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  measured_at date DEFAULT CURRENT_DATE,
  height numeric,
  weight numeric,
  body_fat numeric,
  muscle_mass numeric,
  bmi numeric,
  chest numeric,
  waist numeric,
  hips numeric,
  arms numeric,
  thighs numeric,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- ============ EMPLOYEES (HR detail) ============
CREATE TABLE IF NOT EXISTS employee_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  app_user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  national_id text,
  passport_number text,
  date_of_birth date,
  gender text CHECK (gender IN ('male','female','other')),
  marital_status text,
  nationality text DEFAULT 'Egyptian',
  whatsapp_number text,
  personal_email text,
  company_email text,
  home_address text,
  emergency_contact text,
  emergency_phone text,
  contract_type text,
  salary numeric,
  bank_account text,
  iban text,
  tax_number text,
  social_insurance_number text,
  medical_insurance text,
  education text,
  certificates text,
  skills text,
  languages text,
  previous_experience text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS employee_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  type text NOT NULL,
  name text,
  file_url text,
  uploaded_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS attendance (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  date date NOT NULL DEFAULT CURRENT_DATE,
  check_in timestamptz,
  check_out timestamptz,
  status text DEFAULT 'present' CHECK (status IN ('present','absent','late','leave','holiday')),
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payroll (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  period_month integer NOT NULL,
  period_year integer NOT NULL,
  base_salary numeric,
  bonuses numeric DEFAULT 0,
  commissions numeric DEFAULT 0,
  deductions numeric DEFAULT 0,
  loans numeric DEFAULT 0,
  advances numeric DEFAULT 0,
  overtime numeric DEFAULT 0,
  net_salary numeric,
  status text DEFAULT 'pending' CHECK (status IN ('pending','approved','paid','cancelled')),
  paid_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS leave_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('annual','sick','emergency','unpaid','maternity')),
  start_date date NOT NULL,
  end_date date NOT NULL,
  reason text,
  status text DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','cancelled')),
  approved_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- ============ PRODUCTS & INVENTORY ============
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  parent_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE,
  contact_person text,
  email text,
  phone text,
  address text,
  city text,
  country text DEFAULT 'Egypt',
  tax_number text,
  payment_terms text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_code text UNIQUE,
  name text NOT NULL,
  barcode text,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  supplier_id uuid REFERENCES suppliers(id) ON DELETE SET NULL,
  brand text,
  description text,
  unit text DEFAULT 'piece',
  cost_price numeric,
  selling_price numeric,
  min_stock integer DEFAULT 0,
  is_active boolean DEFAULT true,
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS warehouses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  address text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  warehouse_id uuid REFERENCES warehouses(id) ON DELETE SET NULL,
  quantity integer DEFAULT 0,
  min_quantity integer DEFAULT 0,
  expiry_date date,
  batch_number text,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  warehouse_id uuid REFERENCES warehouses(id) ON DELETE SET NULL,
  type text NOT NULL CHECK (type IN ('in','out','transfer','adjustment')),
  quantity integer NOT NULL,
  reference_type text,
  reference_id uuid,
  notes text,
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS purchase_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_number text UNIQUE,
  supplier_id uuid NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  warehouse_id uuid REFERENCES warehouses(id) ON DELETE SET NULL,
  order_date date DEFAULT CURRENT_DATE,
  expected_date date,
  total_amount numeric,
  status text DEFAULT 'pending' CHECK (status IN ('pending','approved','received','cancelled')),
  notes text,
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS purchase_order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  po_id uuid NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  quantity integer NOT NULL,
  unit_cost numeric NOT NULL,
  total numeric
);

-- ============ SALES & INVOICES ============
CREATE TABLE IF NOT EXISTS sales (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_number text UNIQUE,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  sale_date timestamptz DEFAULT now(),
  subtotal numeric DEFAULT 0,
  discount numeric DEFAULT 0,
  tax numeric DEFAULT 0,
  total numeric DEFAULT 0,
  payment_method text CHECK (payment_method IN ('cash','card','transfer','wallet','mixed')),
  payment_status text DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid','partial','paid','refunded')),
  status text DEFAULT 'completed' CHECK (status IN ('pending','completed','cancelled','refunded')),
  cashier_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  notes text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sale_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sale_id uuid NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  description text,
  quantity integer NOT NULL DEFAULT 1,
  unit_price numeric NOT NULL,
  discount numeric DEFAULT 0,
  total numeric
);

CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text UNIQUE,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  sale_id uuid REFERENCES sales(id) ON DELETE SET NULL,
  issue_date date DEFAULT CURRENT_DATE,
  due_date date,
  subtotal numeric DEFAULT 0,
  discount numeric DEFAULT 0,
  tax numeric DEFAULT 0,
  total numeric DEFAULT 0,
  paid_amount numeric DEFAULT 0,
  balance numeric DEFAULT 0,
  status text DEFAULT 'draft' CHECK (status IN ('draft','sent','paid','partial','overdue','cancelled')),
  notes text,
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_number text UNIQUE,
  invoice_id uuid REFERENCES invoices(id) ON DELETE SET NULL,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  amount numeric NOT NULL,
  payment_method text CHECK (payment_method IN ('cash','card','transfer','wallet')),
  payment_date timestamptz DEFAULT now(),
  reference text,
  notes text,
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- ============ MEMBERSHIPS ============
CREATE TABLE IF NOT EXISTS membership_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text UNIQUE,
  description text,
  duration_months integer NOT NULL,
  price numeric NOT NULL,
  is_active boolean DEFAULT true,
  features jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES membership_plans(id) ON DELETE RESTRICT,
  start_date date NOT NULL DEFAULT CURRENT_DATE,
  end_date date NOT NULL,
  status text DEFAULT 'active' CHECK (status IN ('active','expired','suspended','cancelled')),
  amount numeric,
  paid_amount numeric DEFAULT 0,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- ============ APPOINTMENTS & PROGRAMS ============
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('trainer','nutritionist','doctor','general')),
  staff_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  appointment_date date NOT NULL,
  start_time time NOT NULL,
  end_time time,
  status text DEFAULT 'scheduled' CHECK (status IN ('scheduled','confirmed','completed','cancelled','no_show')),
  notes text,
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS workout_programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  trainer_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  name text NOT NULL,
  description text,
  start_date date,
  end_date date,
  status text DEFAULT 'active' CHECK (status IN ('active','completed','paused','cancelled')),
  details jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS nutrition_programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  nutritionist_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  name text NOT NULL,
  description text,
  start_date date,
  end_date date,
  daily_calories integer,
  protein_grams integer,
  carbs_grams integer,
  fats_grams integer,
  status text DEFAULT 'active' CHECK (status IN ('active','completed','paused','cancelled')),
  details jsonb,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS medical_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  doctor_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  visit_date date DEFAULT CURRENT_DATE,
  diagnosis text,
  prescription text,
  recommendations text,
  follow_up_date date,
  status text DEFAULT 'open' CHECK (status IN ('open','closed')),
  created_at timestamptz DEFAULT now()
);

-- ============ CALL CENTER & SUPPORT ============
CREATE TABLE IF NOT EXISTS call_center_calls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  call_type text CHECK (call_type IN ('incoming','outgoing')),
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  agent_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  phone_number text,
  call_date timestamptz DEFAULT now(),
  duration_seconds integer,
  outcome text,
  notes text,
  status text DEFAULT 'completed' CHECK (status IN ('answered','missed','completed','busy')),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_number text UNIQUE,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  subject text NOT NULL,
  description text,
  priority text DEFAULT 'medium' CHECK (priority IN ('low','medium','high','urgent')),
  category text,
  status text DEFAULT 'open' CHECK (status IN ('open','in_progress','resolved','closed','reopened')),
  assigned_to uuid REFERENCES app_users(id) ON DELETE SET NULL,
  sla_due_at timestamptz,
  resolved_at timestamptz,
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ticket_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  sender_id uuid REFERENCES app_users(id) ON DELETE SET NULL,
  message text NOT NULL,
  is_internal boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- ============ ACCOUNTING ============
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  expense_number text UNIQUE,
  category text,
  description text NOT NULL,
  amount numeric NOT NULL,
  expense_date date DEFAULT CURRENT_DATE,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  payment_method text,
  vendor text,
  status text DEFAULT 'pending' CHECK (status IN ('pending','approved','paid','rejected')),
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS revenue_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  revenue_number text UNIQUE,
  source text NOT NULL,
  description text,
  amount numeric NOT NULL,
  revenue_date date DEFAULT CURRENT_DATE,
  branch_id uuid REFERENCES branches(id) ON DELETE SET NULL,
  reference_type text,
  reference_id uuid,
  created_at timestamptz DEFAULT now()
);

-- ============ EMAIL SYSTEM ============
CREATE TABLE IF NOT EXISTS email_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email_address text NOT NULL,
  provider text CHECK (provider IN ('gmail','outlook','smtp','custom')),
  smtp_host text,
  smtp_port integer,
  smtp_username text,
  smtp_password_encrypted text,
  use_ssl boolean DEFAULT true,
  is_default boolean DEFAULT false,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  subject text,
  body text,
  category text DEFAULT 'general',
  variables jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid REFERENCES email_accounts(id) ON DELETE SET NULL,
  to_address text NOT NULL,
  cc text,
  bcc text,
  subject text,
  body text,
  template_id uuid REFERENCES email_templates(id) ON DELETE SET NULL,
  status text DEFAULT 'draft' CHECK (status IN ('draft','queued','sent','failed','received')),
  folder text DEFAULT 'sent' CHECK (folder IN ('inbox','sent','drafts','trash','spam')),
  is_read boolean DEFAULT false,
  has_attachments boolean DEFAULT false,
  sent_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  template_id uuid REFERENCES email_templates(id) ON DELETE SET NULL,
  subject text,
  recipient_count integer DEFAULT 0,
  sent_count integer DEFAULT 0,
  failed_count integer DEFAULT 0,
  status text DEFAULT 'draft' CHECK (status IN ('draft','scheduled','sending','completed','cancelled')),
  scheduled_at timestamptz,
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- ============ SMS SYSTEM ============
CREATE TABLE IF NOT EXISTS sms_providers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  provider text,
  api_url text,
  api_key_encrypted text,
  sender_id text,
  is_default boolean DEFAULT false,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sms_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  body text,
  category text DEFAULT 'general',
  variables jsonb,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sms_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id uuid REFERENCES sms_providers(id) ON DELETE SET NULL,
  to_number text NOT NULL,
  message text,
  template_id uuid REFERENCES sms_templates(id) ON DELETE SET NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending','sent','failed','delivered')),
  cost numeric,
  sent_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- ============ ENABLE RLS ON ALL NEW TABLES ============
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_measurements ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouses ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE sale_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE membership_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_programs ENABLE ROW LEVEL SECURITY;
ALTER TABLE nutrition_programs ENABLE ROW LEVEL SECURITY;
ALTER TABLE medical_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE call_center_calls ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE revenue_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE sms_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE sms_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE sms_messages ENABLE ROW LEVEL SECURITY;

-- ============ GENERIC POLICY HELPER ============
-- For each table, create CRUD policies for authenticated users
DO $$
DECLARE
  tbl text;
  tables text[] := ARRAY[
    'customers','customer_documents','customer_measurements',
    'employee_profiles','employee_documents','attendance','payroll','leave_requests',
    'categories','suppliers','products','warehouses','inventory','stock_movements',
    'purchase_orders','purchase_order_items',
    'sales','sale_items','invoices','payments',
    'membership_plans','memberships',
    'appointments','workout_programs','nutrition_programs','medical_records',
    'call_center_calls','support_tickets','ticket_messages',
    'expenses','revenue_records',
    'email_accounts','email_templates','email_messages','email_campaigns',
    'sms_providers','sms_templates','sms_messages'
  ];
  tbl_singular text;
BEGIN
  FOREACH tbl IN ARRAY tables LOOP
    EXECUTE format('DROP POLICY IF EXISTS "auth_read_%s" ON %s;', tbl, tbl);
    EXECUTE format('CREATE POLICY "auth_read_%s" ON %s FOR SELECT TO authenticated USING (true);', tbl, tbl);
    EXECUTE format('DROP POLICY IF EXISTS "auth_insert_%s" ON %s;', tbl, tbl);
    EXECUTE format('CREATE POLICY "auth_insert_%s" ON %s FOR INSERT TO authenticated WITH CHECK (true);', tbl, tbl);
    EXECUTE format('DROP POLICY IF EXISTS "auth_update_%s" ON %s;', tbl, tbl);
    EXECUTE format('CREATE POLICY "auth_update_%s" ON %s FOR UPDATE TO authenticated USING (true) WITH CHECK (true);', tbl, tbl);
    EXECUTE format('DROP POLICY IF EXISTS "auth_delete_%s" ON %s;', tbl, tbl);
    EXECUTE format('CREATE POLICY "auth_delete_%s" ON %s FOR DELETE TO authenticated USING (true);', tbl, tbl);
  END LOOP;
END $$;

-- ============ INDEXES ============
CREATE INDEX IF NOT EXISTS idx_customers_email ON customers(email);
CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);
CREATE INDEX IF NOT EXISTS idx_customers_branch ON customers(branch_id);
CREATE INDEX IF NOT EXISTS idx_attendance_employee_date ON attendance(employee_id, date);
CREATE INDEX IF NOT EXISTS idx_payroll_employee_period ON payroll(employee_id, period_year, period_month);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_supplier ON products(supplier_id);
CREATE INDEX IF NOT EXISTS idx_inventory_product ON inventory(product_id);
CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customer_id);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);
CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_memberships_customer ON memberships(customer_id);
CREATE INDEX IF NOT EXISTS idx_appointments_customer_date ON appointments(customer_id, appointment_date);
CREATE INDEX IF NOT EXISTS idx_support_tickets_status ON support_tickets(status);
CREATE INDEX IF NOT EXISTS idx_email_messages_folder ON email_messages(folder);
CREATE INDEX IF NOT EXISTS idx_sms_messages_status ON sms_messages(status);
