/*
# Make leave_requests.employee_id nullable

The existing table had employee_id NOT NULL, but our application allows
creating leave requests by employee name/code without a UUID foreign key.
*/
ALTER TABLE leave_requests ALTER COLUMN employee_id DROP NOT NULL;

-- Also make the 'type' column nullable if it exists (old column)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='leave_requests' AND column_name='type' AND is_nullable='NO') THEN
    ALTER TABLE leave_requests ALTER COLUMN type DROP NOT NULL;
  END IF;
END $$;
