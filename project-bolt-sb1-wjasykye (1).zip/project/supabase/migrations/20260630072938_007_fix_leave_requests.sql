/*
# Fix leave_requests table — align columns with application schema

## Problem
The existing leave_requests table had columns: employee_id (uuid FK), type, start_date, end_date, reason, status, approved_by, created_at.
The new application uses: employee_name (text), employee_code (text), leave_type, plus admin_notes, approved_at, total_days, updated_at.

## Changes
Add missing columns to the existing table. Keep existing columns for backward compatibility.
*/

DO $$
BEGIN
  -- employee_name text (for display without FK lookup)
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='leave_requests' AND column_name='employee_name') THEN
    ALTER TABLE leave_requests ADD COLUMN employee_name text;
  END IF;
  -- employee_code text
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='leave_requests' AND column_name='employee_code') THEN
    ALTER TABLE leave_requests ADD COLUMN employee_code text;
  END IF;
  -- leave_type (might conflict with 'type' column)
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='leave_requests' AND column_name='leave_type') THEN
    ALTER TABLE leave_requests ADD COLUMN leave_type text DEFAULT 'annual';
  END IF;
  -- admin_notes
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='leave_requests' AND column_name='admin_notes') THEN
    ALTER TABLE leave_requests ADD COLUMN admin_notes text;
  END IF;
  -- approved_at
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='leave_requests' AND column_name='approved_at') THEN
    ALTER TABLE leave_requests ADD COLUMN approved_at timestamptz;
  END IF;
  -- total_days computed
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='leave_requests' AND column_name='total_days') THEN
    ALTER TABLE leave_requests ADD COLUMN total_days int;
  END IF;
  -- updated_at
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='leave_requests' AND column_name='updated_at') THEN
    ALTER TABLE leave_requests ADD COLUMN updated_at timestamptz DEFAULT now();
  END IF;
END $$;

-- RLS policies
ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_leave"  ON leave_requests;
DROP POLICY IF EXISTS "auth_insert_leave"  ON leave_requests;
DROP POLICY IF EXISTS "auth_update_leave"  ON leave_requests;
DROP POLICY IF EXISTS "auth_delete_leave"  ON leave_requests;

CREATE POLICY "auth_select_leave" ON leave_requests FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_leave" ON leave_requests FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_leave" ON leave_requests FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_leave" ON leave_requests FOR DELETE TO authenticated USING (true);
