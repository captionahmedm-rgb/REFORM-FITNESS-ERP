/*
# Payroll Penalties & Rewards System

## Overview
Adds comprehensive penalty and reward tracking for employee payroll calculation.

## Tables
1. penalty_types - defines types of penalties/rewards
2. employee_penalties - individual penalty/reward records
3. Enhanced payroll with deductions breakdown
*/

-- Penalty types (penalties and rewards)
CREATE TABLE IF NOT EXISTS penalty_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_ar text,
  type text NOT NULL CHECK (type IN ('penalty', 'reward', 'bonus')),
  default_amount numeric DEFAULT 0,
  description text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Employee penalties/rewards records
CREATE TABLE IF NOT EXISTS employee_penalties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id text NOT NULL,
  penalty_type_id uuid REFERENCES penalty_types(id) ON DELETE SET NULL,
  type text NOT NULL CHECK (type IN ('penalty', 'reward', 'bonus', 'late_deduction', 'absence_deduction', 'overtime_bonus')),
  amount numeric NOT NULL DEFAULT 0,
  reason text,
  reference_date date,
  reference_type text, -- 'attendance', 'manual', 'leave'
  reference_id uuid,
  month integer,
  year integer,
  status text DEFAULT 'applied' CHECK (status IN ('pending', 'applied', 'cancelled')),
  created_by uuid REFERENCES app_users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE penalty_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE employee_penalties ENABLE ROW LEVEL SECURITY;

-- RLS Policies for penalty_types
CREATE POLICY "auth_read_penalty_types" ON penalty_types FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_penalty_types" ON penalty_types FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_penalty_types" ON penalty_types FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_penalty_types" ON penalty_types FOR DELETE TO authenticated USING (true);

-- RLS Policies for employee_penalties
CREATE POLICY "auth_read_employee_penalties" ON employee_penalties FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_employee_penalties" ON employee_penalties FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_employee_penalties" ON employee_penalties FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_employee_penalties" ON employee_penalties FOR DELETE TO authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_employee_penalties_employee_id ON employee_penalties(employee_id);
CREATE INDEX IF NOT EXISTS idx_employee_penalties_month_year ON employee_penalties(month, year);
CREATE INDEX IF NOT EXISTS idx_employee_penalties_type ON employee_penalties(type);

-- Default penalty types
INSERT INTO penalty_types (name, name_ar, type, default_amount, description) VALUES
  ('Late Attendance', 'خصم التأخير', 'penalty', 50, 'Deduction for arriving late'),
  ('Absence', 'خصم الغياب', 'penalty', 100, 'Deduction for unexcused absence'),
  ('Performance Bonus', 'مكافأة الأداء', 'bonus', 0, 'Performance-based bonus'),
  ('Overtime Pay', 'مكافأة العمل الإضافي', 'reward', 0, 'Compensation for overtime work'),
  ('Sales Commission', 'عمولة المبيعات', 'reward', 0, 'Commission on sales'),
  ('Late Minutes Deduction', 'خصم دقائق التأخير', 'penalty', 0, 'Per-minute late deduction'),
  ('Annual Reward', 'المكافأة السنوية', 'reward', 0, 'Annual performance reward'),
  ('Disciplinary Action', 'جزاء تأديبي', 'penalty', 0, 'Disciplinary penalty')
ON CONFLICT DO NOTHING;

-- Add penalties breakdown columns to payroll if not exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'payroll' AND column_name = 'late_deductions') THEN
    ALTER TABLE payroll ADD COLUMN late_deductions numeric DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'payroll' AND column_name = 'absence_deductions') THEN
    ALTER TABLE payroll ADD COLUMN absence_deductions numeric DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'payroll' AND column_name = 'other_penalties') THEN
    ALTER TABLE payroll ADD COLUMN other_penalties numeric DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'payroll' AND column_name = 'rewards') THEN
    ALTER TABLE payroll ADD COLUMN rewards numeric DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'payroll' AND column_name = 'late_minutes') THEN
    ALTER TABLE payroll ADD COLUMN late_minutes integer DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'payroll' AND column_name = 'absent_days') THEN
    ALTER TABLE payroll ADD COLUMN absent_days integer DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'payroll' AND column_name = 'working_days') THEN
    ALTER TABLE payroll ADD COLUMN working_days integer DEFAULT 0;
  END IF;
END $$;