/*
# Leave Management System

## Purpose
Full employee leave request workflow with approval/rejection by admin.

## New Tables

### leave_requests
Stores employee leave requests with status tracking.
- employee_code: links to app_users.employee_code for lookups
- leave_type: annual / sick / emergency / unpaid
- status: pending / approved / rejected
- admin_notes: manager's approval/rejection reason
- approved_by: who approved/rejected it
- When approved, attendance sync is handled by application layer

## Security
RLS enabled — authenticated users only (HR system requires login)
Permissive for authenticated since it's internal admin tool
*/

CREATE TABLE IF NOT EXISTS leave_requests (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id   uuid REFERENCES app_users(id) ON DELETE CASCADE,
  employee_code text,
  employee_name text NOT NULL,
  leave_type    text NOT NULL DEFAULT 'annual'
                CHECK (leave_type IN ('annual','sick','emergency','unpaid')),
  start_date    date NOT NULL,
  end_date      date NOT NULL,
  total_days    int  GENERATED ALWAYS AS (end_date - start_date + 1) STORED,
  reason        text,
  status        text NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','approved','rejected')),
  admin_notes   text,
  approved_by   uuid REFERENCES app_users(id),
  approved_at   timestamptz,
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);

ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_leave"  ON leave_requests;
DROP POLICY IF EXISTS "auth_insert_leave"  ON leave_requests;
DROP POLICY IF EXISTS "auth_update_leave"  ON leave_requests;
DROP POLICY IF EXISTS "auth_delete_leave"  ON leave_requests;

CREATE POLICY "auth_select_leave" ON leave_requests FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_leave" ON leave_requests FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_leave" ON leave_requests FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_leave" ON leave_requests FOR DELETE TO authenticated USING (true);
