/*
# Social Media Center + Marketing + Notifications

## Purpose
Stores company social media links, marketing campaigns, and in-app notifications.

## New Tables

### social_media_settings
Key-value store for all social media URLs and contact info.
One row per platform/key. Admin editable.

### marketing_posts
Post ideas, promotions, and marketing calendar entries.
- scheduled_date: when to publish
- platform: which social media channel
- status: draft / scheduled / published

### notifications (extended)
Already exists — verify and add missing columns if needed.

## Security
All tables use permissive authenticated RLS (internal admin tool).
*/

-- Social media settings table
CREATE TABLE IF NOT EXISTS social_media_settings (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key        text UNIQUE NOT NULL,  -- e.g. 'facebook_url', 'instagram_url'
  value      text,
  label      text,
  icon       text,
  is_active  boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE social_media_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_select_social"  ON social_media_settings;
DROP POLICY IF EXISTS "auth_insert_social"  ON social_media_settings;
DROP POLICY IF EXISTS "auth_update_social"  ON social_media_settings;
DROP POLICY IF EXISTS "auth_delete_social"  ON social_media_settings;

CREATE POLICY "auth_select_social" ON social_media_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_insert_social" ON social_media_settings FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_update_social" ON social_media_settings FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_delete_social" ON social_media_settings FOR DELETE TO authenticated USING (true);

-- Seed default social media entries
INSERT INTO social_media_settings (key, label, value, icon, is_active) VALUES
  ('facebook_url',   'Facebook',          'https://facebook.com/reformfitness',   'facebook',   true),
  ('instagram_url',  'Instagram',         'https://instagram.com/reformfitness',  'instagram',  true),
  ('tiktok_url',     'TikTok',            'https://tiktok.com/@reformfitness',    'tiktok',     true),
  ('youtube_url',    'YouTube',           'https://youtube.com/@reformfitness',   'youtube',    true),
  ('linkedin_url',   'LinkedIn',          'https://linkedin.com/company/reformfitness','linkedin',true),
  ('twitter_url',    'X (Twitter)',       'https://x.com/reformfitness',          'twitter',    true),
  ('whatsapp_1',     'WhatsApp 1',        'https://wa.me/201550098212',           'whatsapp',   true),
  ('whatsapp_2',     'WhatsApp 2',        'https://wa.me/201551510427',           'whatsapp',   true),
  ('telegram_url',   'Telegram',          'https://t.me/reformfitness',           'telegram',   false),
  ('website_url',    'Website',           'https://reformfitness.com',            'globe',      true),
  ('phone_1',        'Phone 1',           '01550098212',                          'phone',      true),
  ('phone_2',        'Phone 2',           '01551510427',                          'phone',      true),
  ('email_main',     'Main Email',        'captionahmedm@gmail.com',              'mail',       true),
  ('email_store',    'Store Email',       'captainahmedstoreynutritionals@gmail.com','mail',    true)
ON CONFLICT (key) DO NOTHING;

-- Marketing posts / planner
CREATE TABLE IF NOT EXISTS marketing_posts (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title          text NOT NULL,
  content        text,
  platform       text DEFAULT 'facebook',  -- facebook, instagram, tiktok, all
  post_type      text DEFAULT 'post',      -- post, story, reel, campaign
  status         text DEFAULT 'draft'
                 CHECK (status IN ('draft','scheduled','published','cancelled')),
  scheduled_date date,
  image_url      text,
  tags           text,
  created_by     uuid REFERENCES app_users(id),
  created_at     timestamptz DEFAULT now(),
  updated_at     timestamptz DEFAULT now()
);

ALTER TABLE marketing_posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_sel_mkt"  ON marketing_posts;
DROP POLICY IF EXISTS "auth_ins_mkt"  ON marketing_posts;
DROP POLICY IF EXISTS "auth_upd_mkt"  ON marketing_posts;
DROP POLICY IF EXISTS "auth_del_mkt"  ON marketing_posts;

CREATE POLICY "auth_sel_mkt" ON marketing_posts FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_ins_mkt" ON marketing_posts FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_upd_mkt" ON marketing_posts FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_del_mkt" ON marketing_posts FOR DELETE TO authenticated USING (true);

-- Extend notifications table if needed
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notifications' AND column_name='action_url') THEN
    ALTER TABLE notifications ADD COLUMN action_url text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notifications' AND column_name='priority') THEN
    ALTER TABLE notifications ADD COLUMN priority text DEFAULT 'normal';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='notifications' AND column_name='metadata') THEN
    ALTER TABLE notifications ADD COLUMN metadata jsonb;
  END IF;
END $$;

-- Employee support tickets
CREATE TABLE IF NOT EXISTS support_tickets (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_number text UNIQUE,
  employee_id   uuid REFERENCES app_users(id),
  employee_code text,
  subject       text NOT NULL,
  description   text,
  category      text DEFAULT 'general',
  priority      text DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  status        text DEFAULT 'open'   CHECK (status IN ('open','in_progress','resolved','closed')),
  attachments   jsonb DEFAULT '[]',
  admin_reply   text,
  resolved_by   uuid REFERENCES app_users(id),
  resolved_at   timestamptz,
  created_at    timestamptz DEFAULT now(),
  updated_at    timestamptz DEFAULT now()
);

ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "auth_sel_tickets"  ON support_tickets;
DROP POLICY IF EXISTS "auth_ins_tickets"  ON support_tickets;
DROP POLICY IF EXISTS "auth_upd_tickets"  ON support_tickets;
DROP POLICY IF EXISTS "auth_del_tickets"  ON support_tickets;

CREATE POLICY "auth_sel_tickets" ON support_tickets FOR SELECT TO authenticated USING (true);
CREATE POLICY "auth_ins_tickets" ON support_tickets FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "auth_upd_tickets" ON support_tickets FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_del_tickets" ON support_tickets FOR DELETE TO authenticated USING (true);

-- Auto ticket number trigger
CREATE OR REPLACE FUNCTION assign_ticket_number()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.ticket_number IS NULL THEN
    NEW.ticket_number := 'TKT-' || LPAD(nextval('employee_code_seq')::text, 6, '0');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_ticket_number ON support_tickets;
CREATE TRIGGER trg_ticket_number
  BEFORE INSERT ON support_tickets
  FOR EACH ROW EXECUTE FUNCTION assign_ticket_number();
