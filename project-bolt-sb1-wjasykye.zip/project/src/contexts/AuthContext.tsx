import { createContext, useContext, useEffect, useState, useRef, ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import type { AppUser, Role } from '../types';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  profile: AppUser | null;
  roles: Role[];
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfile: (updates: Partial<AppUser>) => Promise<{ error: string | null }>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user,    setUser]    = useState<User | null>(null);
  const [profile, setProfile] = useState<AppUser | null>(null);
  const [roles,   setRoles]   = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);

  // Prevent double-fire from getSession + onAuthStateChange both calling setLoading
  const initialized = useRef(false);

  const loadProfile = async (authId: string) => {
    try {
      const { data: profileData, error } = await supabase
        .from('app_users').select('*').eq('auth_id', authId).maybeSingle();

      if (error) {
        console.warn('Profile load error:', error.message);
        return;
      }

      if (profileData) {
        setProfile(profileData as AppUser);
        const { data: roleData } = await supabase
          .from('user_roles')
          .select('role:roles(*)')
          .eq('user_id', (profileData as AppUser).id);
        if (roleData) setRoles(roleData.map((r: any) => r.role).filter(Boolean));
        // Fire-and-forget last login update
        supabase.from('app_users')
          .update({ last_login: new Date().toISOString() })
          .eq('id', (profileData as AppUser).id)
          .then(() => {});
      } else {
        // Profile doesn't exist yet - auto-create from auth user
        const { data: authUser } = await supabase.auth.getUser();
        if (authUser?.user) {
          const newProfile = {
            auth_id: authId,
            full_name: authUser.user.user_metadata?.full_name || authUser.user.email?.split('@')[0] || 'User',
            email: authUser.user.email || '',
            status: 'active' as const,
            employee_id: 'EMP-' + Math.floor(Math.random() * 99999).toString().padStart(5, '0'),
          };
          const { data: created } = await supabase
            .from('app_users').insert(newProfile).select().maybeSingle();
          if (created) setProfile(created as AppUser);
        }
      }
    } catch (err) {
      console.warn('loadProfile failed:', err);
    }
  };

  useEffect(() => {
    let mounted = true;

    // Safety timeout: never stay loading more than 10 seconds
    const timeout = setTimeout(() => {
      if (mounted) setLoading(false);
    }, 10000);

    // onAuthStateChange fires immediately with current session (replaces getSession)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, sess) => {
      if (!mounted) return;

      setSession(sess);
      setUser(sess?.user ?? null);

      if (sess?.user) {
        if (!initialized.current) {
          initialized.current = true;
          try {
            await loadProfile(sess.user.id);
          } finally {
            if (mounted) {
              clearTimeout(timeout);
              setLoading(false);
            }
          }
        } else {
          // Subsequent auth changes (sign in, token refresh)
          if (event === 'SIGNED_IN' || event === 'USER_UPDATED') {
            await loadProfile(sess.user.id);
          }
        }
      } else {
        initialized.current = false;
        setProfile(null);
        setRoles([]);
        clearTimeout(timeout);
        if (mounted) setLoading(false);
      }
    });

    return () => {
      mounted = false;
      clearTimeout(timeout);
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signUp = async (email: string, password: string, fullName: string) => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { error: error.message };
    if (data.user) {
      const { error: insErr } = await supabase.from('app_users').insert({
        auth_id: data.user.id, full_name: fullName, email, status: 'active',
        employee_id: 'EMP-' + Math.floor(Math.random() * 99999).toString().padStart(5, '0'),
      });
      if (insErr) return { error: insErr.message };
      // First user gets super_admin
      const { count } = await supabase.from('app_users').select('*', { count: 'exact', head: true });
      if (count === 1) {
        const { data: adminRole } = await supabase.from('roles').select('id').eq('name', 'super_admin').maybeSingle();
        if (adminRole) {
          const { data: newProfile } = await supabase.from('app_users').select('id').eq('auth_id', data.user.id).maybeSingle();
          if (newProfile) await supabase.from('user_roles').insert({ user_id: newProfile.id, role_id: adminRole.id });
        }
      }
    }
    return { error: null };
  };

  const signOut = async () => {
    initialized.current = false;
    setProfile(null);
    setRoles([]);
    await supabase.auth.signOut();
  };

  const refreshProfile = async () => {
    if (user) await loadProfile(user.id);
  };

  const updateProfile = async (updates: Partial<AppUser>) => {
    if (!profile) return { error: 'Not authenticated' };
    const { error } = await supabase.from('app_users').update(updates).eq('id', profile.id);
    if (error) return { error: error.message };
    await loadProfile(profile.auth_id!);
    return { error: null };
  };

  const changePassword = async (_currentPassword: string, newPassword: string) => {
    if (newPassword.length < 6) return { error: 'Password must be at least 6 characters' };
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    return { error: error?.message ?? null };
  };

  return (
    <AuthContext.Provider value={{ session, user, profile, roles, loading, signIn, signUp, signOut, refreshProfile, updateProfile, changePassword }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
