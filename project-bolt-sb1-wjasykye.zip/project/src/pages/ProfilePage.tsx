import { useState, useEffect, useRef, ChangeEvent } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { Button, Input, Select, Textarea, Card, PageHeader, Badge } from '../components/ui';
import { supabase } from '../lib/supabase';
import {
  Camera, Lock, Shield, Bell, User, Save, Eye, EyeOff, CheckCircle,
  Upload, X, Loader2, Phone, MapPin, Briefcase, Calendar,
} from 'lucide-react';

type Tab = 'profile' | 'password' | 'security' | 'notifications';

const DEPTS = ['Management','Training','Nutrition','Sales','Warehouse','Accounting','Customer Service','IT','Reception','Operations'];
const GOVS  = ['Cairo','Giza','Alexandria','Dakahlia','Red Sea','Beheira','Fayoum','Gharbiya','Ismailia','Menofia','Minya','Qaliubiya','New Valley','Suez','Aswan','Assiut','Beni Suef','Port Said','Damietta','Sharqia','South Sinai','Kafr El Sheikh','Matrouh','Luxor','Qena','North Sinai','Sohag'];

export function ProfilePage() {
  const { profile, roles, updateProfile, changePassword, refreshProfile } = useAuth();
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [tab, setTab] = useState<Tab>('profile');

  /* ── Profile form ── */
  const [pForm, setPForm] = useState({
    full_name: '', phone: '', whatsapp_number: '', email: '',
    job_title: '', department_name: '', governorate: '', city: '', address: '',
    personal_email: '', national_id: '', date_of_birth: '',
    gender: 'male', marital_status: 'single', nationality: 'Egyptian', notes: '',
    emergency_contact: '', emergency_phone: '',
  });
  const [pSaving, setPSaving] = useState(false);

  /* ── Photo upload ── */
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading,  setUploading]  = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  /* ── Password form ── */
  const [pwForm,   setPwForm]   = useState({ current: '', next: '', confirm: '' });
  const [showCur,  setShowCur]  = useState(false);
  const [showNew,  setShowNew]  = useState(false);
  const [pwSaving, setPwSaving] = useState(false);

  // Populate form from profile
  useEffect(() => {
    if (!profile) return;
    const p = profile as any;
    setPForm({
      full_name:         p.full_name         || '',
      phone:             p.phone             || '',
      whatsapp_number:   p.whatsapp_number   || '',
      email:             p.email             || '',
      job_title:         p.job_title         || '',
      department_name:   p.department_name   || '',
      governorate:       p.governorate       || '',
      city:              p.city              || '',
      address:           p.address           || '',
      personal_email:    p.personal_email    || '',
      national_id:       p.national_id       || '',
      date_of_birth:     p.date_of_birth     || '',
      gender:            p.gender            || 'male',
      marital_status:    p.marital_status    || 'single',
      nationality:       p.nationality       || 'Egyptian',
      notes:             p.notes             || '',
      emergency_contact: p.emergency_contact || '',
      emergency_phone:   p.emergency_phone   || '',
    });
  }, [profile]);

  /* ── Photo handlers ── */
  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      toast(isAr ? 'يرجى اختيار صورة' : 'Please select an image', 'error');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast(isAr ? 'الحجم الأقصى 5 ميجا' : 'Max size is 5MB', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = ev => setPreviewUrl(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const uploadPhoto = async () => {
    const file = fileInputRef.current?.files?.[0];
    if (!file || !profile) return;
    setUploading(true);
    try {
      let avatarUrl: string;
      const ext      = file.name.split('.').pop() ?? 'jpg';
      const filePath = `${(profile as any).id}/${Date.now()}.${ext}`;

      const { error: upErr } = await supabase.storage.from('avatars').upload(filePath, file, { upsert: true });

      if (upErr) {
        // Fallback: base64 data-url stored directly in DB
        avatarUrl = await new Promise<string>(resolve => {
          const r = new FileReader();
          r.onload = ev => resolve(ev.target?.result as string);
          r.readAsDataURL(file);
        });
      } else {
        const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(filePath);
        avatarUrl = urlData.publicUrl;
      }

      const { error: updErr } = await updateProfile({ avatar_url: avatarUrl } as any);
      if (updErr) throw new Error(updErr);

      setPreviewUrl(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      toast(isAr ? 'تم رفع الصورة ✓' : 'Photo uploaded ✓', 'success');
      await refreshProfile();
    } catch (err: any) {
      toast(err.message || 'Upload failed', 'error');
    }
    setUploading(false);
  };

  const removePhoto = async () => {
    if (!profile) return;
    setUploading(true);
    try {
      const { error } = await updateProfile({ avatar_url: '' } as any);
      if (error) throw new Error(error);
      setPreviewUrl(null);
      toast(isAr ? 'تم حذف الصورة' : 'Photo removed', 'success');
      await refreshProfile();
    } catch (err: any) {
      toast(err.message, 'error');
    }
    setUploading(false);
  };

  /* ── Save profile ── */
  const saveProfile = async () => {
    if (!pForm.full_name.trim()) {
      toast(isAr ? 'الاسم مطلوب' : 'Name is required', 'warning');
      return;
    }
    setPSaving(true);
    const { error } = await updateProfile({
      full_name:         pForm.full_name.trim(),
      phone:             pForm.phone             || undefined,
      whatsapp_number:   pForm.whatsapp_number   || undefined,
      job_title:         pForm.job_title         || undefined,
      department_name:   pForm.department_name   || undefined,
      governorate:       pForm.governorate       || undefined,
      city:              pForm.city              || undefined,
      address:           pForm.address           || undefined,
      personal_email:    pForm.personal_email    || undefined,
      national_id:       pForm.national_id       || undefined,
      date_of_birth:     pForm.date_of_birth     || undefined,
      gender:            pForm.gender            || undefined,
      marital_status:    pForm.marital_status    || undefined,
      nationality:       pForm.nationality       || undefined,
      notes:             pForm.notes             || undefined,
      emergency_contact: pForm.emergency_contact || undefined,
      emergency_phone:   pForm.emergency_phone   || undefined,
    } as any);
    if (error) toast(error, 'error');
    else {
      toast(isAr ? 'تم الحفظ ✓' : 'Saved ✓', 'success');
      await refreshProfile();
    }
    setPSaving(false);
  };

  /* ── Change password ── */
  const savePassword = async () => {
    if (!pwForm.current) { toast(isAr ? 'أدخل كلمة المرور الحالية' : 'Enter current password', 'warning'); return; }
    if (pwForm.next.length < 6) { toast(isAr ? 'كلمة المرور 6 أحرف على الأقل' : 'Min 6 characters', 'warning'); return; }
    if (pwForm.next !== pwForm.confirm) { toast(isAr ? 'كلمتا المرور غير متطابقتين' : 'Passwords do not match', 'error'); return; }
    setPwSaving(true);
    const { error } = await changePassword(pwForm.current, pwForm.next);
    if (error) toast(error, 'error');
    else {
      toast(isAr ? 'تم تغيير كلمة المرور ✓' : 'Password changed ✓', 'success');
      setPwForm({ current: '', next: '', confirm: '' });
    }
    setPwSaving(false);
  };

  /* ── Loading state ── */
  if (!profile) return (
    <div className="flex flex-col items-center justify-center h-64 gap-3">
      <Loader2 size={32} className="animate-spin" style={{ color: 'var(--neon)' }} />
      <p style={{ color: 'var(--color-text-muted)' }}>{isAr ? 'جاري تحميل الملف الشخصي...' : 'Loading profile...'}</p>
    </div>
  );

  const currentAvatar = previewUrl || (profile as any).avatar_url || '';

  const TABS: { id: Tab; icon: any; en: string; ar: string }[] = [
    { id: 'profile',       icon: User,   en: 'My Profile',     ar: 'ملفي الشخصي' },
    { id: 'password',      icon: Lock,   en: 'Change Password', ar: 'تغيير كلمة المرور' },
    { id: 'security',      icon: Shield, en: 'Security',        ar: 'الأمان' },
    { id: 'notifications', icon: Bell,   en: 'Notifications',   ar: 'الإشعارات' },
  ];

  return (
    <div>
      <PageHeader
        title={isAr ? 'الملف الشخصي' : 'My Profile'}
        subtitle={isAr ? 'إدارة معلوماتك الشخصية' : 'Manage your personal information'}
      />

      {/* Hero card */}
      <div className="rf-card stat-card p-6 mb-6 overflow-hidden relative">
        <div className="flex items-center gap-5 flex-wrap">

          {/* Avatar + upload controls */}
          <div className="relative group">
            <div className="avatar w-24 h-24"
              style={{ border: '3px solid var(--neon)', boxShadow: '0 0 24px rgba(0,212,255,0.4)' }}>
              {currentAvatar
                ? <img src={currentAvatar} alt={profile.full_name}
                    onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                : <span className="text-3xl font-bold" style={{ color: 'var(--neon)' }}>
                    {profile.full_name?.charAt(0)?.toUpperCase() || 'U'}
                  </span>
              }
            </div>

            {/* Overlay on hover */}
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="absolute inset-0 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ background: 'rgba(0,0,0,0.6)' }}
              title={isAr ? 'تغيير الصورة' : 'Change photo'}
            >
              {uploading ? <Loader2 size={20} className="animate-spin" style={{ color: '#fff' }} />
                         : <Camera size={20} style={{ color: '#fff' }} />}
            </button>

            {/* Remove button */}
            {currentAvatar && !uploading && (
              <button
                onClick={removePhoto}
                className="absolute -top-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center shadow-lg transition-transform hover:scale-110"
                style={{ background: 'var(--color-danger)', color: '#fff' }}
                title={isAr ? 'حذف الصورة' : 'Remove photo'}
              >
                <X size={12} />
              </button>
            )}
          </div>

          <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileSelect} />

          <div className="flex-1 min-w-0">
            <h2 className="text-2xl font-extrabold truncate" style={{ color: 'var(--color-text)' }}>
              {profile.full_name}
            </h2>
            <p className="text-sm mt-0.5" style={{ color: 'var(--neon)' }}>
              {(profile as any).job_title || (isAr ? 'لم يحدد' : 'Not set')}
            </p>
            <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{profile.email}</p>
            <div className="flex gap-2 mt-2 flex-wrap">
              {roles.map(r => <Badge key={r.id} color="primary">{r.display_name}</Badge>)}
              <Badge color={(profile as any).status === 'active' ? 'success' : 'default'}>
                {(profile as any).status}
              </Badge>
            </div>
          </div>

          <div className="text-end shrink-0">
            <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
              {isAr ? 'رقم الموظف' : 'Employee ID'}
            </p>
            <p className="font-mono font-bold" style={{ color: 'var(--neon)' }}>
              {(profile as any).employee_id || '—'}
            </p>
            {profile.last_login && (
              <>
                <p className="text-xs mt-2" style={{ color: 'var(--color-text-muted)' }}>
                  {isAr ? 'آخر دخول' : 'Last login'}
                </p>
                <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>
                  {new Date(profile.last_login).toLocaleString()}
                </p>
              </>
            )}
          </div>
        </div>

        {/* Preview pending upload bar */}
        {previewUrl && (
          <div className="mt-4 flex items-center gap-3 p-3 rounded-xl"
            style={{ background: 'rgba(0,212,255,0.08)', border: '1px solid var(--neon)' }}>
            <img src={previewUrl} className="w-10 h-10 rounded-full object-cover"
              style={{ border: '2px solid var(--neon)' }} alt="preview" />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold" style={{ color: 'var(--color-text)' }}>
                {isAr ? 'صورة جاهزة للرفع' : 'Photo ready to upload'}
              </p>
              <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                {isAr ? 'اضغط "رفع الصورة" لحفظها' : 'Click "Upload Photo" to save'}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={uploadPhoto}
                disabled={uploading}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
                style={{ background: 'linear-gradient(135deg,#0099BB,#00D4FF)', color: '#050A14' }}
              >
                {uploading ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />}
                {isAr ? 'رفع الصورة' : 'Upload Photo'}
              </button>
              <button
                onClick={() => { setPreviewUrl(null); if (fileInputRef.current) fileInputRef.current.value = ''; }}
                className="px-2 py-1.5 rounded-lg text-xs font-semibold"
                style={{ background: 'var(--color-border)', color: 'var(--color-text-muted)' }}
              >
                <X size={13} />
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Tabs sidebar */}
        <div className="lg:w-52 shrink-0">
          <div className="rf-card p-2 space-y-1">
            {TABS.map(t => {
              const Icon = t.icon;
              return (
                <button key={t.id} onClick={() => setTab(t.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition nav-item ${tab === t.id ? 'nav-active' : ''}`}
                  style={{ color: tab === t.id ? 'var(--neon)' : 'var(--color-text-secondary)' }}>
                  <Icon size={16} /><span>{isAr ? t.ar : t.en}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Content area */}
        <div className="flex-1 min-w-0">

          {/* ── PROFILE TAB ── */}
          {tab === 'profile' && (
            <Card>
              <h3 className="font-bold mb-5 flex items-center gap-2" style={{ color: 'var(--color-text)' }}>
                <User size={18} style={{ color: 'var(--neon)' }} />
                {isAr ? 'تعديل الملف الشخصي' : 'Edit Profile'}
              </h3>

              {/* Photo upload section */}
              <div className="flex items-center gap-4 p-4 rounded-xl mb-6"
                style={{ background: 'var(--color-bg-surface)', border: '1px solid var(--color-border)' }}>
                <div className="relative">
                  <div className="avatar w-16 h-16" style={{ border: '2px solid var(--neon)' }}>
                    {currentAvatar
                      ? <img src={currentAvatar} alt="preview"
                          onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                      : <Camera size={22} style={{ color: 'var(--neon)' }} />}
                  </div>
                </div>
                <div className="flex-1">
                  <p className="text-xs font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
                    {isAr ? 'الصورة الشخصية' : 'Profile Photo'}
                  </p>
                  <div className="flex gap-2 flex-wrap">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={uploading}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition hover:opacity-80"
                      style={{ background: 'var(--color-border)', color: 'var(--color-text-secondary)' }}
                    >
                      <Upload size={13} /> {isAr ? 'اختر صورة' : 'Choose Image'}
                    </button>
                    {currentAvatar && (
                      <button
                        onClick={removePhoto}
                        disabled={uploading}
                        className="px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition hover:opacity-80"
                        style={{ background: 'rgba(239,68,68,0.15)', color: 'var(--color-danger)' }}
                      >
                        <X size={13} /> {isAr ? 'حذف الصورة' : 'Remove Photo'}
                      </button>
                    )}
                  </div>
                  <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>
                    {isAr ? 'PNG أو JPG بحد أقصى 5MB' : 'PNG or JPG, max 5MB'}
                  </p>
                </div>
              </div>

              {/* Personal info */}
              <div className="mb-4">
                <p className="text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-2"
                  style={{ color: 'var(--color-text-muted)' }}>
                  <User size={13} /> {isAr ? 'المعلومات الشخصية' : 'Personal Information'}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label={isAr ? 'الاسم الكامل *' : 'Full Name *'} value={pForm.full_name}
                    onChange={e => setPForm(p => ({ ...p, full_name: e.target.value }))} />
                  <Input label={isAr ? 'المسمى الوظيفي' : 'Job Title'} value={pForm.job_title}
                    onChange={e => setPForm(p => ({ ...p, job_title: e.target.value }))} />
                  <Select label={isAr ? 'القسم' : 'Department'} value={pForm.department_name}
                    onChange={e => setPForm(p => ({ ...p, department_name: e.target.value }))}>
                    <option value="">—</option>
                    {DEPTS.map(d => <option key={d} value={d}>{d}</option>)}
                  </Select>
                  <Select label={isAr ? 'الجنس' : 'Gender'} value={pForm.gender}
                    onChange={e => setPForm(p => ({ ...p, gender: e.target.value }))}>
                    <option value="male">{isAr ? 'ذكر' : 'Male'}</option>
                    <option value="female">{isAr ? 'أنثى' : 'Female'}</option>
                    <option value="other">{isAr ? 'آخر' : 'Other'}</option>
                  </Select>
                  <Select label={isAr ? 'الحالة الاجتماعية' : 'Marital Status'} value={pForm.marital_status}
                    onChange={e => setPForm(p => ({ ...p, marital_status: e.target.value }))}>
                    <option value="single">{isAr ? 'أعزب' : 'Single'}</option>
                    <option value="married">{isAr ? 'متزوج' : 'Married'}</option>
                    <option value="divorced">{isAr ? 'مطلق' : 'Divorced'}</option>
                    <option value="widowed">{isAr ? 'أرمل' : 'Widowed'}</option>
                  </Select>
                  <Input label={isAr ? 'تاريخ الميلاد' : 'Date of Birth'} type="date" value={pForm.date_of_birth}
                    onChange={e => setPForm(p => ({ ...p, date_of_birth: e.target.value }))} />
                  <Input label={isAr ? 'الرقم القومي' : 'National ID'} value={pForm.national_id}
                    onChange={e => setPForm(p => ({ ...p, national_id: e.target.value }))} maxLength={14} />
                  <Input label={isAr ? 'الجنسية' : 'Nationality'} value={pForm.nationality}
                    onChange={e => setPForm(p => ({ ...p, nationality: e.target.value }))} />
                </div>
              </div>

              {/* Contact info */}
              <div className="mb-4">
                <p className="text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-2"
                  style={{ color: 'var(--color-text-muted)' }}>
                  <Phone size={13} /> {isAr ? 'بيانات الاتصال' : 'Contact Details'}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label={isAr ? 'رقم الهاتف' : 'Phone'} value={pForm.phone}
                    onChange={e => setPForm(p => ({ ...p, phone: e.target.value }))} placeholder="+201xxxxxxxxx" />
                  <Input label={isAr ? 'واتساب' : 'WhatsApp'} value={pForm.whatsapp_number}
                    onChange={e => setPForm(p => ({ ...p, whatsapp_number: e.target.value }))} placeholder="+201xxxxxxxxx" />
                  <Input label={isAr ? 'البريد الشخصي' : 'Personal Email'} type="email" value={pForm.personal_email}
                    onChange={e => setPForm(p => ({ ...p, personal_email: e.target.value }))} />
                  <Input label={isAr ? 'جهة الاتصال للطوارئ' : 'Emergency Contact'} value={pForm.emergency_contact}
                    onChange={e => setPForm(p => ({ ...p, emergency_contact: e.target.value }))} />
                  <Input label={isAr ? 'هاتف الطوارئ' : 'Emergency Phone'} value={pForm.emergency_phone}
                    onChange={e => setPForm(p => ({ ...p, emergency_phone: e.target.value }))} />
                </div>
              </div>

              {/* Address */}
              <div className="mb-4">
                <p className="text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-2"
                  style={{ color: 'var(--color-text-muted)' }}>
                  <MapPin size={13} /> {isAr ? 'العنوان' : 'Address'}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select label={isAr ? 'المحافظة' : 'Governorate'} value={pForm.governorate}
                    onChange={e => setPForm(p => ({ ...p, governorate: e.target.value }))}>
                    <option value="">—</option>
                    {GOVS.map(g => <option key={g} value={g}>{g}</option>)}
                  </Select>
                  <Input label={isAr ? 'المدينة' : 'City'} value={pForm.city}
                    onChange={e => setPForm(p => ({ ...p, city: e.target.value }))} />
                  <div className="md:col-span-2">
                    <Textarea label={isAr ? 'العنوان التفصيلي' : 'Full Address'} value={pForm.address} rows={2}
                      onChange={e => setPForm(p => ({ ...p, address: e.target.value }))} />
                  </div>
                </div>
              </div>

              {/* Notes */}
              <div className="mb-6">
                <p className="text-xs font-bold uppercase tracking-wider mb-3 flex items-center gap-2"
                  style={{ color: 'var(--color-text-muted)' }}>
                  <Briefcase size={13} /> {isAr ? 'ملاحظات' : 'Notes'}
                </p>
                <Textarea label="" value={pForm.notes} rows={3}
                  onChange={e => setPForm(p => ({ ...p, notes: e.target.value }))} />
              </div>

              <div className="flex justify-end">
                <Button icon={Save} onClick={saveProfile} loading={pSaving}>
                  {isAr ? 'حفظ التغييرات' : 'Save Changes'}
                </Button>
              </div>
            </Card>
          )}

          {/* ── PASSWORD TAB ── */}
          {tab === 'password' && (
            <Card>
              <h3 className="font-bold mb-5 flex items-center gap-2" style={{ color: 'var(--color-text)' }}>
                <Lock size={18} style={{ color: 'var(--neon)' }} />
                {isAr ? 'تغيير كلمة المرور' : 'Change Password'}
              </h3>
              <div className="space-y-4 max-w-sm">
                {/* Current password */}
                <div>
                  <label className="label">{isAr ? 'كلمة المرور الحالية' : 'Current Password'}</label>
                  <div className="relative">
                    <input type={showCur ? 'text' : 'password'} className="input pr-10"
                      value={pwForm.current} onChange={e => setPwForm(p => ({ ...p, current: e.target.value }))}
                      placeholder="••••••••" />
                    <button type="button" onClick={() => setShowCur(!showCur)}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                      style={{ color: 'var(--color-text-muted)' }}>
                      {showCur ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                {/* New password */}
                <div>
                  <label className="label">{isAr ? 'كلمة المرور الجديدة' : 'New Password'}</label>
                  <div className="relative">
                    <input type={showNew ? 'text' : 'password'} className="input pr-10"
                      value={pwForm.next} onChange={e => setPwForm(p => ({ ...p, next: e.target.value }))}
                      placeholder="••••••••" minLength={6} />
                    <button type="button" onClick={() => setShowNew(!showNew)}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                      style={{ color: 'var(--color-text-muted)' }}>
                      {showNew ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {pwForm.next && (
                    <div className="mt-2">
                      <div className="progress-bar">
                        <div className="progress-fill" style={{
                          width: pwForm.next.length >= 12 ? '100%' : pwForm.next.length >= 8 ? '66%' : '33%'
                        }} />
                      </div>
                      <p className="text-xs mt-1" style={{
                        color: pwForm.next.length >= 8 ? 'var(--color-success)' : 'var(--color-warning)'
                      }}>
                        {pwForm.next.length >= 12 ? (isAr?'قوية':'Strong') : pwForm.next.length >= 8 ? (isAr?'متوسطة':'Medium') : (isAr?'ضعيفة':'Weak')}
                      </p>
                    </div>
                  )}
                </div>
                {/* Confirm */}
                <div>
                  <label className="label">{isAr ? 'تأكيد كلمة المرور' : 'Confirm Password'}</label>
                  <div className="relative">
                    <input type="password" className="input pr-10"
                      value={pwForm.confirm} onChange={e => setPwForm(p => ({ ...p, confirm: e.target.value }))}
                      placeholder="••••••••" />
                    {pwForm.confirm && pwForm.next === pwForm.confirm && (
                      <CheckCircle size={16} className="absolute right-3 top-1/2 -translate-y-1/2"
                        style={{ color: 'var(--color-success)' }} />
                    )}
                  </div>
                </div>
                <Button icon={Lock} onClick={savePassword} loading={pwSaving}>
                  {isAr ? 'تغيير كلمة المرور' : 'Change Password'}
                </Button>
              </div>
            </Card>
          )}

          {/* ── SECURITY TAB ── */}
          {tab === 'security' && (
            <Card>
              <h3 className="font-bold mb-5 flex items-center gap-2" style={{ color: 'var(--color-text)' }}>
                <Shield size={18} style={{ color: 'var(--neon)' }} />
                {isAr ? 'إعدادات الأمان' : 'Security Settings'}
              </h3>
              <div className="space-y-3 max-w-md">
                {[
                  { label: isAr?'تنبيهات تسجيل الدخول':'Login Alerts',             checked: true  },
                  { label: isAr?'خروج تلقائي بعد عدم النشاط':'Auto Logout',        checked: true  },
                  { label: isAr?'المصادقة الثنائية (2FA)':'Two-Factor Auth (2FA)', checked: false },
                ].map((s, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-xl"
                    style={{ background: 'var(--color-bg-surface)' }}>
                    <span className="text-sm" style={{ color: 'var(--color-text)' }}>{s.label}</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked={s.checked} className="sr-only peer" />
                      <div className="w-10 h-5 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:start-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"
                        style={{ background: 'var(--color-border)' }} />
                    </label>
                  </div>
                ))}

                <div className="p-3 rounded-xl mt-3" style={{ background: 'var(--color-bg-surface)' }}>
                  <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                    {isAr ? 'معرف المستخدم' : 'User ID'}
                  </p>
                  <p className="text-xs font-mono break-all" style={{ color: 'var(--neon)' }}>
                    {profile.auth_id}
                  </p>
                </div>

                <div className="p-3 rounded-xl" style={{ background: 'var(--color-bg-surface)' }}>
                  <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                    {isAr ? 'آخر تسجيل دخول' : 'Last Login'}
                  </p>
                  <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>
                    {profile.last_login ? new Date(profile.last_login).toLocaleString() : '—'}
                  </p>
                </div>

                <div className="p-3 rounded-xl" style={{ background: 'var(--color-bg-surface)' }}>
                  <p className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                    {isAr ? 'تاريخ الانضمام' : 'Member Since'}
                  </p>
                  <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>
                    <Calendar size={12} className="inline mr-1" />
                    {profile.created_at ? new Date(profile.created_at).toLocaleDateString() : '—'}
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* ── NOTIFICATIONS TAB ── */}
          {tab === 'notifications' && (
            <Card>
              <h3 className="font-bold mb-5 flex items-center gap-2" style={{ color: 'var(--color-text)' }}>
                <Bell size={18} style={{ color: 'var(--neon)' }} />
                {isAr ? 'تفضيلات الإشعارات' : 'Notification Preferences'}
              </h3>
              <div className="space-y-3 max-w-md">
                {[
                  { label: isAr?'إشعارات البريد الإلكتروني':'Email Notifications',  checked: true  },
                  { label: isAr?'إشعارات الرسائل القصيرة':'SMS Notifications',      checked: false },
                  { label: isAr?'إشعارات تسجيل الحضور':'Attendance Alerts',         checked: true  },
                  { label: isAr?'تنبيهات الرواتب':'Payroll Notifications',          checked: true  },
                  { label: isAr?'تنبيهات المبيعات':'Sales Alerts',                  checked: true  },
                  { label: isAr?'تنبيهات الأمان':'Security Alerts',                 checked: true  },
                ].map((s, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-xl"
                    style={{ background: 'var(--color-bg-surface)' }}>
                    <span className="text-sm" style={{ color: 'var(--color-text)' }}>{s.label}</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked={s.checked} className="sr-only peer" />
                      <div className="w-10 h-5 rounded-full peer peer-checked:after:translate-x-5 after:content-[''] after:absolute after:top-0.5 after:start-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"
                        style={{ background: 'var(--color-border)' }} />
                    </label>
                  </div>
                ))}
                <Button icon={Save} onClick={() => toast(isAr ? 'تم الحفظ ✓' : 'Saved ✓', 'success')}>
                  {isAr ? 'حفظ التفضيلات' : 'Save Preferences'}
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
