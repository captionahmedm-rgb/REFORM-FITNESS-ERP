import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { DataTable, Column } from '../components/DataTable';
import { Button, Input, Select, Textarea, Modal, ConfirmDialog, PageHeader, Badge } from '../components/ui';
import { Plus, CheckCircle, XCircle, Clock, Calendar } from 'lucide-react';

const LEAVE_TYPES = ['annual','sick','emergency','unpaid'] as const;
const STATUSES    = ['pending','approved','rejected'] as const;

export function LeaveManagementPage() {
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [data,     setData]    = useState<any[]>([]);
  const [loading,  setLoading] = useState(true);
  const [modal,    setModal]   = useState(false);
  const [editId,   setEditId]  = useState<string|null>(null);
  const [delId,    setDelId]   = useState<string|null>(null);
  const [viewItem, setViewItem]= useState<any|null>(null);
  const [saving,   setSaving]  = useState(false);
  const [statusF,  setStatusF] = useState('');
  const [typeF,    setTypeF]   = useState('');

  const today = new Date().toISOString().split('T')[0];
  const [form, setForm] = useState({
    employee_name: '', employee_code: '', leave_type: 'annual',
    start_date: today, end_date: today, reason: '',
    status: 'pending', admin_notes: '',
  });

  const load = async () => {
    setLoading(true);
    try {
      const { data: rows, error } = await supabase
        .from('leave_requests').select('*').order('created_at', { ascending: false });
      if (error) {
        console.warn('Leave requests load error:', error.message);
        toast(error.message, 'error');
      }
      setData(rows || []);
    } catch (err) {
      console.warn('Leave requests load failed:', err);
      setData([]);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  const f = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }));

  const openAdd  = () => { setForm({ employee_name:'', employee_code:'', leave_type:'annual', start_date:today, end_date:today, reason:'', status:'pending', admin_notes:'' }); setEditId(null); setModal(true); };
  const openEdit = (r: any) => { setForm({ employee_name:r.employee_name||'', employee_code:r.employee_code||'', leave_type:r.leave_type||'annual', start_date:r.start_date||today, end_date:r.end_date||today, reason:r.reason||'', status:r.status||'pending', admin_notes:r.admin_notes||'' }); setEditId(r.id); setModal(true); };

  const save = async () => {
    if (!form.employee_name.trim()) { toast(isAr?'اسم الموظف مطلوب':'Employee name required','warning'); return; }
    if (!form.start_date || !form.end_date) { toast(isAr?'التاريخ مطلوب':'Dates required','warning'); return; }
    if (form.end_date < form.start_date) { toast(isAr?'تاريخ النهاية يجب أن يكون بعد تاريخ البداية':'End date must be after start date','error'); return; }
    setSaving(true);
    const payload = {
      employee_name: form.employee_name.trim(),
      employee_code: form.employee_code || null,
      leave_type:    form.leave_type,
      start_date:    form.start_date,
      end_date:      form.end_date,
      reason:        form.reason || null,
      status:        form.status,
      admin_notes:   form.admin_notes || null,
      updated_at:    new Date().toISOString(),
    };
    const { error } = editId
      ? await supabase.from('leave_requests').update(payload).eq('id', editId)
      : await supabase.from('leave_requests').insert([payload]);
    if (error) toast(error.message, 'error');
    else { toast(isAr?'تم الحفظ ✓':'Saved ✓','success'); setModal(false); load(); }
    setSaving(false);
  };

  const del = async () => {
    if (!delId) return;
    const { error } = await supabase.from('leave_requests').delete().eq('id', delId);
    if (error) toast(error.message,'error');
    else { toast(isAr?'تم الحذف ✓':'Deleted ✓','success'); load(); }
    setDelId(null);
  };

  const quickStatus = async (id: string, status: string) => {
    const { error } = await supabase.from('leave_requests').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) toast(error.message,'error');
    else { toast(`${status} ✓`,'success'); load(); }
  };

  const stats = {
    total:    data.length,
    pending:  data.filter(r => r.status === 'pending').length,
    approved: data.filter(r => r.status === 'approved').length,
    rejected: data.filter(r => r.status === 'rejected').length,
  };

  let displayed = [...data];
  if (statusF) displayed = displayed.filter(d => d.status === statusF);
  if (typeF)   displayed = displayed.filter(d => d.leave_type === typeF);

  const leaveTypeLabel: Record<string,string> = {
    annual: isAr?'سنوية':'Annual',
    sick:   isAr?'مرضية':'Sick',
    emergency: isAr?'طارئة':'Emergency',
    unpaid: isAr?'بدون راتب':'Unpaid',
  };

  const statusColor: Record<string,any> = { pending:'warning', approved:'success', rejected:'danger' };

  const columns: Column<any>[] = [
    { key:'employee_code',  label:isAr?'كود الموظف':'Emp Code',
      render:r=><span className="font-mono text-xs" style={{color:'var(--neon)'}}>{r.employee_code||'—'}</span> },
    { key:'employee_name',  label:isAr?'الموظف':'Employee',
      render:r=><span className="font-semibold text-sm">{r.employee_name}</span> },
    { key:'leave_type',     label:isAr?'نوع الإجازة':'Leave Type',
      render:r=><Badge color="info">{leaveTypeLabel[r.leave_type]||r.leave_type}</Badge> },
    { key:'start_date',     label:isAr?'من':'From' },
    { key:'end_date',       label:isAr?'إلى':'To' },
    { key:'total_days',     label:isAr?'الأيام':'Days',
      render:r=><span className="font-bold" style={{color:'var(--neon)'}}>{r.total_days||'—'}</span> },
    { key:'status',         label:isAr?'الحالة':'Status',
      render:r=>(
        <div className="flex items-center gap-1">
          <Badge color={statusColor[r.status]||'default'}>{r.status}</Badge>
          {r.status==='pending' && (
            <>
              <button onClick={()=>quickStatus(r.id,'approved')} title="Approve"
                className="w-6 h-6 rounded flex items-center justify-center hover:bg-white/5"
                style={{color:'var(--color-success)'}}>
                <CheckCircle size={14}/>
              </button>
              <button onClick={()=>quickStatus(r.id,'rejected')} title="Reject"
                className="w-6 h-6 rounded flex items-center justify-center hover:bg-white/5"
                style={{color:'var(--color-danger)'}}>
                <XCircle size={14}/>
              </button>
            </>
          )}
        </div>
      ) },
  ];

  return (
    <div>
      <PageHeader title={isAr?'إدارة الإجازات':'Leave Management'}
        subtitle={isAr?'طلبات الإجازة وإدارة الموافقات':'Manage employee leave requests'}
        action={<Button icon={Plus} onClick={openAdd}>{isAr?'طلب إجازة':'New Request'}</Button>} />

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {[
          { label:isAr?'إجمالي الطلبات':'Total',    value:stats.total,    icon:Calendar,     color:'#00D4FF' },
          { label:isAr?'قيد الانتظار':'Pending',    value:stats.pending,  icon:Clock,        color:'#F59E0B' },
          { label:isAr?'موافق عليها':'Approved',    value:stats.approved, icon:CheckCircle,  color:'#22C55E' },
          { label:isAr?'مرفوضة':'Rejected',         value:stats.rejected, icon:XCircle,      color:'#EF4444' },
        ].map((s,i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="rf-card-glow stat-card p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                  style={{background:`${s.color}18`,border:`1px solid ${s.color}30`}}>
                  <Icon size={18} style={{color:s.color}}/>
                </div>
                <span className="text-2xl font-extrabold" style={{color:'var(--color-text)'}}>{s.value}</span>
              </div>
              <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
            </div>
          );
        })}
      </div>

      <DataTable data={displayed} columns={columns} loading={loading}
        onAdd={openAdd} onEdit={openEdit} onDelete={r=>setDelId(r.id)} onView={r=>setViewItem(r)}
        searchKeys={['employee_name','employee_code','leave_type','status']}
        filters={[
          {label:'Status',value:statusF,onChange:setStatusF,options:STATUSES.map(s=>({value:s,label:s}))},
          {label:'Type',  value:typeF,  onChange:setTypeF,  options:LEAVE_TYPES.map(t=>({value:t,label:leaveTypeLabel[t]||t}))},
        ]}
        emptyTitle={isAr?'لا طلبات إجازة':'No leave requests'}
        emptyDescription={isAr?'لم يتم تقديم أي طلبات إجازة بعد':'No leave requests submitted yet'} />

      {/* Add/Edit modal */}
      <Modal open={modal} onClose={()=>setModal(false)} size="lg"
        title={editId?(isAr?'تعديل طلب الإجازة':'Edit Leave Request'):(isAr?'طلب إجازة جديد':'New Leave Request')}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label={isAr?'اسم الموظف *':'Employee Name *'} value={form.employee_name} onChange={e=>f('employee_name',e.target.value)} />
          <Input label={isAr?'كود الموظف':'Employee Code'} value={form.employee_code} onChange={e=>f('employee_code',e.target.value)} placeholder="10001" />
          <Select label={isAr?'نوع الإجازة':'Leave Type'} value={form.leave_type} onChange={e=>f('leave_type',e.target.value)}>
            <option value="annual">{isAr?'إجازة سنوية':'Annual Leave'}</option>
            <option value="sick">{isAr?'إجازة مرضية':'Sick Leave'}</option>
            <option value="emergency">{isAr?'إجازة طارئة':'Emergency Leave'}</option>
            <option value="unpaid">{isAr?'إجازة بدون راتب':'Unpaid Leave'}</option>
          </Select>
          <Select label={isAr?'الحالة (للمدير)':'Status (Admin)'} value={form.status} onChange={e=>f('status',e.target.value)}>
            <option value="pending">{isAr?'قيد الانتظار':'Pending'}</option>
            <option value="approved">{isAr?'موافق عليه':'Approved'}</option>
            <option value="rejected">{isAr?'مرفوض':'Rejected'}</option>
          </Select>
          <Input label={isAr?'تاريخ البداية':'Start Date'} type="date" value={form.start_date} onChange={e=>f('start_date',e.target.value)} />
          <Input label={isAr?'تاريخ النهاية':'End Date'} type="date" value={form.end_date} min={form.start_date} onChange={e=>f('end_date',e.target.value)} />
          <div className="md:col-span-2">
            {form.start_date && form.end_date && form.end_date >= form.start_date && (
              <div className="p-3 rounded-xl mb-3 text-sm flex items-center gap-2"
                style={{background:'rgba(0,212,255,0.08)',border:'1px solid rgba(0,212,255,0.2)'}}>
                <Calendar size={16} style={{color:'var(--neon)'}}/>
                <span style={{color:'var(--color-text)'}}>{isAr?'عدد الأيام:':'Total Days:'}
                  <strong className="ms-1" style={{color:'var(--neon)'}}>
                    {Math.max(1, Math.round((new Date(form.end_date).getTime()-new Date(form.start_date).getTime())/(1000*60*60*24))+1)}
                  </strong>
                </span>
              </div>
            )}
          </div>
          <div className="md:col-span-2"><Textarea label={isAr?'السبب':'Reason'} value={form.reason} onChange={e=>f('reason',e.target.value)} rows={2} /></div>
          <div className="md:col-span-2"><Textarea label={isAr?'ملاحظات الإدارة':'Admin Notes'} value={form.admin_notes} onChange={e=>f('admin_notes',e.target.value)} rows={2} placeholder={isAr?'ملاحظات الموافقة أو الرفض...':'Approval/rejection notes...'} /></div>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="secondary" onClick={()=>setModal(false)}>{isAr?'إلغاء':'Cancel'}</Button>
          <Button onClick={save} loading={saving}>{isAr?'حفظ':'Save'}</Button>
        </div>
      </Modal>

      {/* View modal */}
      <Modal open={!!viewItem} onClose={()=>setViewItem(null)} title={isAr?'تفاصيل الإجازة':'Leave Request Details'} size="md">
        {viewItem && (
          <div>
            <div className="p-4 rounded-xl mb-4" style={{background:'var(--color-bg-surface)'}}>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-bold" style={{color:'var(--color-text)'}}>{viewItem.employee_name}</h3>
                <Badge color={statusColor[viewItem.status]}>{viewItem.status}</Badge>
              </div>
              <p className="text-xs font-mono" style={{color:'var(--neon)'}}>{viewItem.employee_code||'No code'}</p>
            </div>
            {[
              [isAr?'نوع الإجازة':'Leave Type', leaveTypeLabel[viewItem.leave_type]||viewItem.leave_type],
              [isAr?'من':'From',       viewItem.start_date],
              [isAr?'إلى':'To',         viewItem.end_date],
              [isAr?'الأيام':'Days',    viewItem.total_days],
              [isAr?'السبب':'Reason',   viewItem.reason],
              [isAr?'ملاحظات الإدارة':'Admin Notes', viewItem.admin_notes],
              [isAr?'تاريخ الطلب':'Submitted', viewItem.created_at?new Date(viewItem.created_at).toLocaleString():'—'],
            ].filter(([,v])=>v).map(([l,v])=>(
              <div key={l as string} className="flex justify-between py-2" style={{borderBottom:'1px solid var(--color-border)'}}>
                <span className="text-xs" style={{color:'var(--color-text-muted)'}}>{l}</span>
                <span className="text-xs font-semibold text-end ms-2" style={{color:'var(--color-text)'}}>{v}</span>
              </div>
            ))}
            {viewItem.status==='pending' && (
              <div className="flex gap-3 mt-4">
                <Button icon={CheckCircle} onClick={()=>{quickStatus(viewItem.id,'approved');setViewItem(null);}}>
                  {isAr?'موافقة':'Approve'}
                </Button>
                <Button icon={XCircle} variant="danger" onClick={()=>{quickStatus(viewItem.id,'rejected');setViewItem(null);}}>
                  {isAr?'رفض':'Reject'}
                </Button>
              </div>
            )}
          </div>
        )}
      </Modal>

      <ConfirmDialog open={!!delId} onClose={()=>setDelId(null)} onConfirm={del}
        title={isAr?'حذف طلب الإجازة':'Delete Leave Request'}
        message={isAr?'هل أنت متأكد من حذف هذا الطلب؟':'Delete this leave request permanently?'} />
    </div>
  );
}
