import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { Button, Input, Select, Textarea, Modal, PageHeader, Badge, Card } from '../components/ui';
import {
  ExternalLink, Edit2, Save, Plus, Trash2, Calendar,
  Facebook, Instagram, Youtube, MessageCircle, Linkedin, Twitter,
  Share2, Globe, Phone, Mail
} from 'lucide-react';

/* ─── Platform config ─── */
const PLATFORMS = [
  { key:'facebook_url',  label:'Facebook',   icon: Facebook,     color:'#1877F2', bgColor:'rgba(24,119,242,0.12)' },
  { key:'instagram_url', label:'Instagram',  icon: Instagram,    color:'#E1306C', bgColor:'rgba(225,48,108,0.12)' },
  { key:'youtube_url',   label:'YouTube',    icon: Youtube,      color:'#FF0000', bgColor:'rgba(255,0,0,0.12)' },
  { key:'whatsapp_1',    label:'WhatsApp 1', icon: MessageCircle,color:'#25D366', bgColor:'rgba(37,211,102,0.12)' },
  { key:'whatsapp_2',    label:'WhatsApp 2', icon: MessageCircle,color:'#25D366', bgColor:'rgba(37,211,102,0.12)' },
  { key:'tiktok_url',    label:'TikTok',     icon: Share2,       color:'#010101', bgColor:'rgba(100,100,100,0.15)' },
  { key:'linkedin_url',  label:'LinkedIn',   icon: Linkedin,     color:'#0A66C2', bgColor:'rgba(10,102,194,0.12)' },
  { key:'twitter_url',   label:'X (Twitter)',icon: Twitter,      color:'#1DA1F2', bgColor:'rgba(29,161,242,0.12)' },
  { key:'telegram_url',  label:'Telegram',   icon: Share2,       color:'#26A5E4', bgColor:'rgba(38,165,228,0.12)' },
  { key:'website_url',   label:'Website',    icon: Globe,        color:'#00D4FF', bgColor:'rgba(0,212,255,0.12)' },
];

const CONTACT_ITEMS = [
  { key:'phone_1',    label:'Phone 1',     icon: Phone, color:'#00D4FF', type:'phone' },
  { key:'phone_2',    label:'Phone 2',     icon: Phone, color:'#00D4FF', type:'phone' },
  { key:'email_main', label:'Main Email',  icon: Mail,  color:'#F59E0B', type:'email' },
  { key:'email_store',label:'Store Email', icon: Mail,  color:'#F59E0B', type:'email' },
];

export function SocialMediaPage() {
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';

  const [settings,  setSettings]  = useState<Record<string,string>>({});
  const [editKey,   setEditKey]   = useState<string|null>(null);
  const [editVal,   setEditVal]   = useState('');
  const [savingKey, setSavingKey] = useState<string|null>(null);
  const [tab,       setTab]       = useState<'overview'|'links'|'marketing'|'contact'>('overview');

  // Marketing posts
  const [posts,       setPosts]     = useState<any[]>([]);
  const [postModal,   setPostModal] = useState(false);
  const [editPost,    setEditPost]  = useState<any|null>(null);
  const [postForm,    setPostForm]  = useState({ title:'', content:'', platform:'facebook', post_type:'post', status:'draft', scheduled_date:'', image_url:'', tags:'' });
  const [savingPost,  setSavingPost]= useState(false);
  const [delPostId,   setDelPostId] = useState<string|null>(null);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase.from('social_media_settings').select('key, value');
      if (error) {
        console.warn('Social settings load error:', error.message);
        toast(error.message, 'error');
      }
      const map: Record<string,string> = {};
      (data||[]).forEach((r:any) => { map[r.key] = r.value||''; });
      setSettings(map);
    } catch (err) {
      console.warn('Social settings load failed:', err);
    }
  };

  const loadPosts = async () => {
    try {
      const { data, error } = await supabase.from('marketing_posts').select('*').order('created_at',{ascending:false});
      if (error) console.warn('Marketing posts load error:', error.message);
      setPosts(data||[]);
    } catch (err) {
      console.warn('Marketing posts load failed:', err);
      setPosts([]);
    }
  };

  useEffect(() => { loadSettings(); loadPosts(); }, []);

  const saveLink = async (key: string) => {
    setSavingKey(key);
    const { error } = await supabase.from('social_media_settings')
      .update({ value: editVal, updated_at: new Date().toISOString() })
      .eq('key', key);
    if (error) toast(error.message,'error');
    else {
      toast(isAr?'تم الحفظ ✓':'Saved ✓','success');
      setSettings(p => ({ ...p, [key]: editVal }));
      setEditKey(null);
    }
    setSavingKey(null);
  };

  const savePost = async () => {
    if (!postForm.title.trim()) { toast('Title required','warning'); return; }
    setSavingPost(true);
    const payload = { ...postForm, updated_at: new Date().toISOString(), scheduled_date: postForm.scheduled_date||null };
    const { error } = editPost
      ? await supabase.from('marketing_posts').update(payload).eq('id',editPost.id)
      : await supabase.from('marketing_posts').insert([payload]);
    if (error) toast(error.message,'error');
    else { toast(isAr?'تم الحفظ ✓':'Saved ✓','success'); setPostModal(false); loadPosts(); }
    setSavingPost(false);
  };

  const openPost = (p?:any) => {
    setEditPost(p||null);
    setPostForm(p ? { title:p.title||'', content:p.content||'', platform:p.platform||'facebook', post_type:p.post_type||'post', status:p.status||'draft', scheduled_date:p.scheduled_date||'', image_url:p.image_url||'', tags:p.tags||'' } : { title:'', content:'', platform:'facebook', post_type:'post', status:'draft', scheduled_date:'', image_url:'', tags:'' });
    setPostModal(true);
  };

  const delPost = async () => {
    if (!delPostId) return;
    await supabase.from('marketing_posts').delete().eq('id',delPostId);
    toast('Deleted','success'); setDelPostId(null); loadPosts();
  };

  const getHref = (key: string, val: string) => {
    if (key.startsWith('phone'))   return `tel:${val}`;
    if (key.startsWith('email'))   return `mailto:${val}`;
    if (key.startsWith('whatsapp'))return val.startsWith('http') ? val : `https://wa.me/${val.replace(/\D/g,'')}`;
    return val.startsWith('http') ? val : `https://${val}`;
  };

  const TABS = [
    { id:'overview',  en:'Overview',  ar:'نظرة عامة' },
    { id:'links',     en:'Edit Links',ar:'تعديل الروابط' },
    { id:'marketing', en:'Marketing', ar:'التسويق' },
    { id:'contact',   en:'Contact',   ar:'التواصل' },
  ];

  const statusColors: Record<string,any> = { draft:'default', scheduled:'warning', published:'success', cancelled:'danger' };

  return (
    <div>
      <PageHeader title={isAr?'مركز التواصل الاجتماعي':'Social Media Center'}
        subtitle={isAr?'إدارة حسابات التواصل الاجتماعي والتسويق':'Manage social media accounts and marketing'} />

      {/* Tabs */}
      <div className="flex gap-1 mb-6 overflow-x-auto">
        {TABS.map(t => (
          <button key={t.id} onClick={()=>setTab(t.id as any)}
            className="px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition"
            style={{
              background: tab===t.id ? 'linear-gradient(135deg,#0099BB,#00D4FF)' : 'var(--color-card)',
              color: tab===t.id ? '#050A14' : 'var(--color-text-secondary)',
              border: '1px solid var(--color-border)',
            }}>
            {isAr ? t.ar : t.en}
          </button>
        ))}
      </div>

      {/* OVERVIEW */}
      {tab === 'overview' && (
        <div className="space-y-6">
          {/* Platform quick-access grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {PLATFORMS.filter(p => settings[p.key]).map(p => {
              const Icon = p.icon;
              const val  = settings[p.key];
              const href = getHref(p.key, val);
              return (
                <a key={p.key} href={href} target="_blank" rel="noopener noreferrer"
                  className="rf-card-glow flex flex-col items-center gap-2 p-4 rounded-xl transition hover:scale-105 cursor-pointer"
                  style={{ textDecoration:'none' }}>
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
                    style={{ background: p.bgColor, border:`1px solid ${p.color}30` }}>
                    <Icon size={24} style={{ color: p.color }} />
                  </div>
                  <span className="text-xs font-bold" style={{ color:'var(--color-text)' }}>{p.label}</span>
                  <span className="text-xs truncate max-w-full" style={{ color:'var(--color-text-muted)' }}>
                    {val.replace('https://','').replace('http://','').slice(0,20)}...
                  </span>
                </a>
              );
            })}
          </div>

          {/* Stats cards (placeholder — real analytics requires API keys) */}
          <Card>
            <h3 className="font-bold text-sm mb-4" style={{color:'var(--color-text)'}}>{isAr?'إحصائيات التسويق':'Marketing Stats'}</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                {label:isAr?'منشورات مجدولة':'Scheduled Posts', value: posts.filter(p=>p.status==='scheduled').length, color:'#F59E0B'},
                {label:isAr?'منشورات منشورة':'Published Posts', value: posts.filter(p=>p.status==='published').length, color:'#22C55E'},
                {label:isAr?'مسودات':'Drafts',                  value: posts.filter(p=>p.status==='draft').length,     color:'#00D4FF'},
                {label:isAr?'إجمالي المنشورات':'Total Posts',   value: posts.length,                                    color:'#A78BFA'},
              ].map((s,i) => (
                <div key={i} className="p-4 rounded-xl text-center" style={{background:'var(--color-bg-surface)',border:`1px solid ${s.color}25`}}>
                  <p className="text-2xl font-extrabold mb-1" style={{color:s.color}}>{s.value}</p>
                  <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{s.label}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* Contact quick-dial */}
          <Card>
            <h3 className="font-bold text-sm mb-4" style={{color:'var(--color-text)'}}>{isAr?'التواصل السريع':'Quick Contact'}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {CONTACT_ITEMS.map(c => {
                const Icon = c.icon;
                const val  = settings[c.key];
                if (!val) return null;
                return (
                  <a key={c.key} href={getHref(c.key,val)}
                    className="flex items-center gap-3 p-3 rounded-xl transition hover:bg-white/5"
                    style={{background:'var(--color-bg-surface)',textDecoration:'none'}}>
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{background:`${c.color}18`}}>
                      <Icon size={16} style={{color:c.color}}/>
                    </div>
                    <div>
                      <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{c.label}</p>
                      <p className="text-xs font-bold" style={{color:c.color}}>{val}</p>
                    </div>
                    <ExternalLink size={12} className="ms-auto" style={{color:'var(--color-text-muted)'}}/>
                  </a>
                );
              })}
            </div>
          </Card>
        </div>
      )}

      {/* EDIT LINKS */}
      {tab === 'links' && (
        <div className="space-y-4">
          <p className="text-sm mb-4" style={{color:'var(--color-text-muted)'}}>{isAr?'اضغط على زر التعديل لتغيير أي رابط':'Click edit to update any link'}</p>
          {[...PLATFORMS, ...CONTACT_ITEMS.map(c=>({key:c.key, label:c.label, icon:c.icon, color:c.color, bgColor:`${c.color}18`}))].map(p => {
            const Icon = p.icon;
            const val  = settings[p.key] || '';
            const isEditing = editKey === p.key;
            return (
              <div key={p.key} className="rf-card p-4 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{background:p.bgColor}}>
                  <Icon size={18} style={{color:p.color}}/>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold mb-1" style={{color:'var(--color-text)'}}>{p.label}</p>
                  {isEditing ? (
                    <input className="input text-xs py-1.5 h-8" value={editVal}
                      onChange={e=>setEditVal(e.target.value)} onKeyDown={e=>e.key==='Enter'&&saveLink(p.key)}
                      autoFocus />
                  ) : (
                    <p className="text-xs truncate" style={{color:'var(--color-text-muted)'}}>{val||isAr?'لم يُحدَّد':'Not set'}</p>
                  )}
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  {val && !isEditing && (
                    <a href={getHref(p.key,val)} target="_blank" rel="noopener noreferrer"
                      className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5"
                      style={{color:'var(--color-text-muted)'}}>
                      <ExternalLink size={14}/>
                    </a>
                  )}
                  {isEditing ? (
                    <>
                      <Button size="sm" icon={Save} loading={savingKey===p.key} onClick={()=>saveLink(p.key)}>{isAr?'حفظ':'Save'}</Button>
                      <Button size="sm" variant="secondary" onClick={()=>setEditKey(null)}>{isAr?'إلغاء':'Cancel'}</Button>
                    </>
                  ) : (
                    <button onClick={()=>{setEditKey(p.key);setEditVal(val);}}
                      className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5"
                      style={{color:'var(--neon)'}}>
                      <Edit2 size={14}/>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MARKETING */}
      {tab === 'marketing' && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold" style={{color:'var(--color-text)'}}>{isAr?'خطة التسويق':'Marketing Planner'}</h3>
            <Button icon={Plus} onClick={()=>openPost()}>{isAr?'إضافة منشور':'Add Post'}</Button>
          </div>
          {posts.length === 0 ? (
            <div className="rf-card py-16 text-center">
              <Share2 size={32} className="mx-auto mb-3" style={{color:'var(--color-text-muted)'}}/>
              <p className="text-sm" style={{color:'var(--color-text-muted)'}}>{isAr?'لا منشورات بعد':'No posts yet'}</p>
              <Button icon={Plus} size="sm" className="mt-3" onClick={()=>openPost()}>{isAr?'إضافة أول منشور':'Add First Post'}</Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {posts.map(p => {
                const platform = PLATFORMS.find(pl=>pl.key===`${p.platform}_url`||pl.label.toLowerCase()===p.platform);
                const PIcon = platform?.icon || Share2;
                const pColor = platform?.color || '#00D4FF';
                return (
                  <div key={p.id} className="rf-card-glow p-4 hover:translate-y-[-2px] transition-transform">
                    {p.image_url && (
                      <img src={p.image_url} alt={p.title} className="w-full h-32 object-cover rounded-xl mb-3"
                        onError={e=>{(e.target as any).style.display='none';}} />
                    )}
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{background:`${pColor}18`}}>
                        <PIcon size={14} style={{color:pColor}}/>
                      </div>
                      <span className="text-xs font-bold capitalize" style={{color:pColor}}>{p.platform}</span>
                      <Badge color={statusColors[p.status]||'default'}>{p.status}</Badge>
                    </div>
                    <h4 className="font-bold text-sm mb-1" style={{color:'var(--color-text)'}}>{p.title}</h4>
                    {p.content && <p className="text-xs mb-2 line-clamp-2" style={{color:'var(--color-text-muted)'}}>{p.content}</p>}
                    {p.scheduled_date && (
                      <div className="flex items-center gap-1 mb-3">
                        <Calendar size={11} style={{color:'var(--color-text-muted)'}}/>
                        <span className="text-xs" style={{color:'var(--color-text-muted)'}}>{p.scheduled_date}</span>
                      </div>
                    )}
                    <div className="flex gap-2">
                      <Button size="sm" variant="secondary" icon={Edit2} onClick={()=>openPost(p)}>{isAr?'تعديل':'Edit'}</Button>
                      <button onClick={()=>setDelPostId(p.id)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5"
                        style={{color:'var(--color-danger)'}}>
                        <Trash2 size={14}/>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* CONTACT */}
      {tab === 'contact' && (
        <div className="space-y-4">
          <Card>
            <h3 className="font-bold text-sm mb-4" style={{color:'var(--color-text)'}}>{isAr?'مركز تواصل العملاء':'Customer Contact Center'}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                {label:isAr?'اتصل الآن':'Call Now',         href:`tel:${settings.phone_1||'01550098212'}`,      icon:Phone,         color:'#00D4FF', bg:'rgba(0,212,255,0.1)',   btn:isAr?'اتصل':'Call'},
                {label:isAr?'واتساب 1':'WhatsApp 1',         href:`https://wa.me/201550098212`,                  icon:MessageCircle, color:'#25D366', bg:'rgba(37,211,102,0.1)',  btn:'WhatsApp'},
                {label:isAr?'واتساب 2':'WhatsApp 2',         href:`https://wa.me/201551510427`,                  icon:MessageCircle, color:'#25D366', bg:'rgba(37,211,102,0.1)',  btn:'WhatsApp'},
                {label:isAr?'البريد الرئيسي':'Main Email',  href:`mailto:${settings.email_main||'captionahmedm@gmail.com'}`, icon:Mail, color:'#F59E0B', bg:'rgba(245,158,11,0.1)', btn:isAr?'إرسال':'Email'},
                {label:isAr?'فيسبوك':'Facebook',             href:settings.facebook_url||'#',                    icon:Facebook,      color:'#1877F2', bg:'rgba(24,119,242,0.1)', btn:'Facebook'},
                {label:isAr?'إنستغرام':'Instagram',          href:settings.instagram_url||'#',                   icon:Instagram,     color:'#E1306C', bg:'rgba(225,48,108,0.1)', btn:'Instagram'},
              ].map((c,i) => {
                const Icon = c.icon;
                return (
                  <a key={i} href={c.href} target={c.href.startsWith('http')?'_blank':undefined} rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 rounded-xl transition hover:scale-102 hover:bg-white/3"
                    style={{background:c.bg,border:`1px solid ${c.color}25`,textDecoration:'none'}}>
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center"
                      style={{background:`${c.color}20`}}>
                      <Icon size={20} style={{color:c.color}}/>
                    </div>
                    <div>
                      <p className="text-xs" style={{color:'var(--color-text-muted)'}}>{c.label}</p>
                      <p className="text-sm font-bold" style={{color:c.color}}>{c.btn}</p>
                    </div>
                    <ExternalLink size={14} className="ms-auto" style={{color:c.color}}/>
                  </a>
                );
              })}
            </div>
          </Card>
        </div>
      )}

      {/* Post modal */}
      <Modal open={postModal} onClose={()=>setPostModal(false)} title={editPost?'Edit Post':'New Marketing Post'} size="lg">
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2"><Input label="Title *" value={postForm.title} onChange={e=>setPostForm({...postForm,title:e.target.value})} /></div>
          <Select label="Platform" value={postForm.platform} onChange={e=>setPostForm({...postForm,platform:e.target.value})}>
            {['facebook','instagram','tiktok','youtube','linkedin','twitter','all'].map(p=><option key={p} value={p}>{p}</option>)}
          </Select>
          <Select label="Post Type" value={postForm.post_type} onChange={e=>setPostForm({...postForm,post_type:e.target.value})}>
            <option value="post">Post</option><option value="story">Story</option><option value="reel">Reel</option><option value="campaign">Campaign</option>
          </Select>
          <Select label="Status" value={postForm.status} onChange={e=>setPostForm({...postForm,status:e.target.value})}>
            <option value="draft">Draft</option><option value="scheduled">Scheduled</option><option value="published">Published</option><option value="cancelled">Cancelled</option>
          </Select>
          <Input label="Scheduled Date" type="date" value={postForm.scheduled_date} onChange={e=>setPostForm({...postForm,scheduled_date:e.target.value})} />
          <div className="col-span-2"><Input label="Image URL" value={postForm.image_url} onChange={e=>setPostForm({...postForm,image_url:e.target.value})} placeholder="https://..." /></div>
          <div className="col-span-2"><Textarea label="Content" value={postForm.content} onChange={e=>setPostForm({...postForm,content:e.target.value})} rows={3} /></div>
          <div className="col-span-2"><Input label="Tags" value={postForm.tags} onChange={e=>setPostForm({...postForm,tags:e.target.value})} placeholder="#fitness #reform" /></div>
        </div>
        <div className="flex justify-end gap-3 mt-4">
          <Button variant="secondary" onClick={()=>setPostModal(false)}>Cancel</Button>
          <Button icon={Save} onClick={savePost} loading={savingPost}>Save</Button>
        </div>
      </Modal>

      {/* Delete post confirm */}
      {delPostId && (
        <div className="modal-backdrop animate-fade-in" onClick={()=>setDelPostId(null)}>
          <div className="rf-card p-6 max-w-sm w-full rounded-2xl animate-scale-in" onClick={e=>e.stopPropagation()}>
            <h3 className="font-bold mb-2" style={{color:'var(--color-text)'}}>Delete Post</h3>
            <p className="text-sm mb-4" style={{color:'var(--color-text-secondary)'}}>Delete this marketing post?</p>
            <div className="flex justify-end gap-3">
              <Button variant="secondary" size="sm" onClick={()=>setDelPostId(null)}>Cancel</Button>
              <Button variant="danger"    size="sm" onClick={delPost}>Delete</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
