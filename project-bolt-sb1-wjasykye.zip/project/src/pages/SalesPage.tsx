import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useToast } from '../contexts/ToastContext';
import { useTheme } from '../contexts/ThemeContext';
import { Button, Modal, PageHeader, Badge } from '../components/ui';
import { Plus, Trash2, ShoppingCart, Receipt } from 'lucide-react';

export function SalesPage() {
  const { toast }    = useToast();
  const { language } = useTheme();
  const isAr = language === 'ar';
  const [sales,    setSales]    = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [cart,     setCart]     = useState<{ p: any; qty: number }[]>([]);
  const [posOpen,  setPosOpen]  = useState(false);
  const [payMethod,setPayMethod]= useState('cash');
  const [saving,   setSaving]   = useState(false);
  const [viewSale, setViewSale] = useState<any>(null);

  const loadSales = async () => {
    try {
      const { data, error } = await supabase.from('sales').select('*').order('created_at', { ascending: false });
      if (error) console.warn('Sales load error:', error.message);
      setSales(data || []);
    } catch (err) {
      console.warn('Sales load failed:', err);
      setSales([]);
    }
  };
  const loadProds = async () => {
    try {
      const { data, error } = await supabase.from('products').select('*').eq('is_active', true);
      if (error) console.warn('Products load error:', error.message);
      setProducts(data || []);
    } catch (err) {
      console.warn('Products load failed:', err);
      setProducts([]);
    }
  };

  useEffect(() => { loadSales(); }, []);
  useEffect(() => { if (posOpen) loadProds(); }, [posOpen]);

  const addToCart = (product: any) => {
    setCart(c => {
      const existing = c.find(x => x.p.id === product.id);
      return existing ? c.map(x => x.p.id === product.id ? { ...x, qty: x.qty + 1 } : x) : [...c, { p: product, qty: 1 }];
    });
  };
  const removeFromCart = (id: string) => setCart(c => c.filter(x => x.p.id !== id));
  const changeQty = (id: string, d: number) => setCart(c => c.map(x => x.p.id === id ? { ...x, qty: Math.max(1, x.qty + d) } : x));
  const total = cart.reduce((s, x) => s + (x.p.selling_price || 0) * x.qty, 0);

  const checkout = async () => {
    if (!cart.length) return;
    setSaving(true);
    try {
      const saleNum = `SALE-${Date.now().toString().slice(-6)}`;
      const { data: sale, error } = await supabase.from('sales').insert([{
        sale_number: saleNum, subtotal: total, total,
        payment_method: payMethod, payment_status: 'paid', status: 'completed',
      }]).select().single();
      if (error) { toast(error.message, 'error'); return; }
      if (sale) {
        const { error: itemError } = await supabase.from('sale_items').insert(
          cart.map(x => ({ sale_id: sale.id, product_id: x.p.id, description: x.p.name, quantity: x.qty, unit_price: x.p.selling_price || 0, total: (x.p.selling_price || 0) * x.qty }))
        );
        if (itemError) console.warn('Sale items insert error:', itemError.message);
      }
      toast(isAr ? 'تمت عملية البيع ✓' : 'Sale completed ✓', 'success');
      setCart([]); setPosOpen(false); loadSales();
    } catch (err: any) {
      console.warn('Checkout failed:', err);
      toast(err?.message || 'Checkout failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader title={isAr ? 'نقطة البيع' : 'Sales / POS'}
        subtitle={isAr ? 'إتمام عمليات البيع' : 'Process sales transactions'}
        action={<Button icon={Plus} onClick={() => setPosOpen(true)}>{isAr ? 'بيع جديد' : 'New Sale'}</Button>} />

      {/* Sales history */}
      <div className="rf-card p-0 overflow-hidden">
        <div className="px-5 py-3 flex items-center justify-between" style={{ borderBottom: '1px solid var(--color-border)' }}>
          <h3 className="font-bold text-sm" style={{ color: 'var(--color-text)' }}>{isAr ? 'سجل المبيعات' : 'Sales History'}</h3>
          <span className="badge" style={{ background: 'rgba(0,212,255,0.12)', color: 'var(--neon)' }}>{sales.length}</span>
        </div>
        {sales.length === 0 ? (
          <div className="py-12 text-center">
            <ShoppingCart size={32} className="mx-auto mb-3" style={{ color: 'var(--color-text-muted)' }} />
            <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>{isAr ? 'لا مبيعات بعد' : 'No sales yet'}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead><tr>
                <th>{isAr?'رقم':'Sale #'}</th><th>{isAr?'التاريخ':'Date'}</th>
                <th>{isAr?'الإجمالي':'Total'}</th><th>{isAr?'الدفع':'Payment'}</th>
                <th>{isAr?'الحالة':'Status'}</th><th>Actions</th>
              </tr></thead>
              <tbody>
                {sales.map(s => (
                  <tr key={s.id}>
                    <td><span className="font-mono text-xs" style={{ color: 'var(--neon)' }}>{s.sale_number}</span></td>
                    <td>{new Date(s.sale_date).toLocaleDateString()}</td>
                    <td><span className="font-bold">EGP {s.total}</span></td>
                    <td><Badge color="info">{s.payment_method}</Badge></td>
                    <td><Badge color={s.status === 'completed' ? 'success' : 'warning'}>{s.status}</Badge></td>
                    <td><button onClick={() => setViewSale(s)} className="w-7 h-7 rounded-lg flex items-center justify-center hover:bg-white/5" style={{ color: 'var(--neon)' }}><Receipt size={14}/></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* POS Modal */}
      <Modal open={posOpen} onClose={() => setPosOpen(false)} title={isAr ? 'نقطة البيع' : 'Point of Sale'} size="xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Products grid */}
          <div>
            <p className="label mb-3">{isAr ? 'المنتجات' : 'Products'}</p>
            <div className="grid grid-cols-2 gap-2 max-h-80 overflow-y-auto">
              {products.map(p => (
                <button key={p.id} onClick={() => addToCart(p)}
                  className="text-start p-3 rounded-xl transition hover:border-neon"
                  style={{ background: 'var(--color-bg-surface)', border: '1px solid var(--color-border)' }}>
                  {p.image_url && <img src={p.image_url} alt={p.name} className="w-full h-20 object-contain rounded-lg mb-2" />}
                  <p className="text-xs font-semibold" style={{ color: 'var(--color-text)' }}>{p.name}</p>
                  <p className="text-xs" style={{ color: 'var(--neon)' }}>EGP {p.selling_price}</p>
                </button>
              ))}
              {products.length === 0 && <p className="col-span-2 text-center py-8 text-sm" style={{ color: 'var(--color-text-muted)' }}>No products available</p>}
            </div>
          </div>

          {/* Cart */}
          <div className="flex flex-col">
            <p className="label mb-3">{isAr ? 'السلة' : 'Cart'} ({cart.length})</p>
            <div className="flex-1 space-y-2 max-h-60 overflow-y-auto mb-4">
              {cart.length === 0
                ? <p className="text-center py-8 text-sm" style={{ color: 'var(--color-text-muted)' }}>{isAr ? 'السلة فارغة' : 'Cart is empty'}</p>
                : cart.map(item => (
                    <div key={item.p.id} className="flex items-center gap-3 p-3 rounded-xl"
                      style={{ background: 'var(--color-bg-surface)', border: '1px solid var(--color-border)' }}>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold truncate" style={{ color: 'var(--color-text)' }}>{item.p.name}</p>
                        <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>EGP {item.p.selling_price} each</p>
                      </div>
                      <div className="flex items-center gap-1">
                        <button onClick={() => changeQty(item.p.id, -1)} className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold" style={{ background: 'var(--color-card)', color: 'var(--color-text)' }}>−</button>
                        <span className="w-6 text-center text-xs font-bold" style={{ color: 'var(--color-text)' }}>{item.qty}</span>
                        <button onClick={() => changeQty(item.p.id, 1)} className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold" style={{ background: 'var(--color-card)', color: 'var(--color-text)' }}>+</button>
                      </div>
                      <span className="text-xs font-bold w-16 text-end" style={{ color: 'var(--neon)' }}>EGP {((item.p.selling_price || 0) * item.qty).toFixed(2)}</span>
                      <button onClick={() => removeFromCart(item.p.id)} style={{ color: 'var(--color-danger)' }}><Trash2 size={14}/></button>
                    </div>
                  ))
              }
            </div>

            {/* Payment method */}
            <div className="mb-4">
              <p className="label">{isAr ? 'طريقة الدفع' : 'Payment Method'}</p>
              <div className="flex gap-2">
                {['cash','card','transfer'].map(m => (
                  <button key={m} onClick={() => setPayMethod(m)}
                    className="flex-1 py-2 rounded-xl text-xs font-bold capitalize transition"
                    style={{
                      background: payMethod === m ? 'linear-gradient(135deg,#0099BB,#00D4FF)' : 'var(--color-card)',
                      color: payMethod === m ? '#050A14' : 'var(--color-text-secondary)',
                      border: '1px solid var(--color-border)',
                    }}>
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Total */}
            <div className="p-4 rounded-xl mb-4" style={{ background: 'rgba(0,212,255,0.08)', border: '1px solid rgba(0,212,255,0.2)' }}>
              <div className="flex justify-between items-center">
                <span className="font-bold" style={{ color: 'var(--color-text)' }}>{isAr ? 'الإجمالي' : 'Total'}</span>
                <span className="text-2xl font-extrabold neon-text">EGP {total.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="secondary" className="flex-1" onClick={() => { setCart([]); setPosOpen(false); }}>Cancel</Button>
              <Button className="flex-1" icon={Receipt} onClick={checkout} loading={saving} disabled={!cart.length}>
                {isAr ? 'إتمام البيع' : 'Checkout'}
              </Button>
            </div>
          </div>
        </div>
      </Modal>

      {/* Receipt modal */}
      <Modal open={!!viewSale} onClose={() => setViewSale(null)} title={isAr ? 'الإيصال' : 'Receipt'} size="sm">
        {viewSale && (
          <div className="space-y-3">
            <div className="text-center pb-3" style={{ borderBottom: '1px solid var(--color-border)' }}>
              <h2 className="logo-text text-xl">REFORM FITNESS</h2>
              <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>{new Date(viewSale.sale_date).toLocaleString()}</p>
            </div>
            {[['Sale #', viewSale.sale_number],['Total', `EGP ${viewSale.total}`],['Payment', viewSale.payment_method],['Status', viewSale.status]].map(([l,v])=>(
              <div key={l as string} className="flex justify-between py-1.5" style={{borderBottom:'1px solid var(--color-border)'}}>
                <span className="text-xs" style={{color:'var(--color-text-muted)'}}>{l}</span>
                <span className="text-xs font-bold" style={{color:'var(--color-text)'}}>{v}</span>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
